extends Node
## Глобальное состояние сессии + сигналы для HUD.

const MAX_PLAYERS := 5
const KILL_TARGET := 5
const GAME_SCENE := "res://scenes/game/arena.tscn"
const MENU_SCENE := "res://scenes/ui/menu.tscn"
const LOBBY_SCENE := "res://scenes/ui/lobby.tscn"
## Видимый маркер версии — первая строка в консоли при запуске.
## Если в логе другой номер, значит запущены старые файлы.
const BUILD_TAG := "BUILD-30: турели (2 шт.) — посадка клавишей F, два ствола по очереди, магазин 30, перезарядка"

## Оружие: индекс = слот (1/2/3 на клавиатуре).
## Урон, дальность, кулдаун и патроны проверяются СЕРВЕРОМ — клиент не
## может стрелять оружием, которое не выбрано, или без патронов.
## Нож: ЛКМ — быстрый удар, ПКМ — сильный удар с замахом (задержка).
## Снайперка: ПКМ — прицеливание (уменьшает FOV и замедляет ходьбу).
const WEAPONS := {
	0: {
		"name": "Нож", "damage": 25.0, "heavy_damage": 60.0,
		"cooldown_ms": 400, "heavy_cooldown_ms": 900,
		"range": 1.3, "heavy_range": 1.7, "windup_ms": 450,
		"tracer": false, "magazine": -1, "reserve": 0, "reload_ms": 0,
	},
	1: {
		"name": "Пистолет", "damage": 25.0,
		"cooldown_ms": 250, "range": 60.0,
		"tracer": true, "magazine": 12, "reserve": 48, "reload_ms": 1200,
	},
	2: {
		"name": "Снайперская винтовка", "damage": 100.0,
		"cooldown_ms": 1300, "range": 200.0,
		"tracer": true, "magazine": 5, "reserve": 15, "reload_ms": 2600,
		"ads_fov": 22.0,
	},
}

## BUILD-30: турель — «оружие» индекса 3. Стреляет только сидящий в ней
## игрок; ствол выбирает сервер (левый/правый по очереди). Запас бесконечный
## (999) — турель не может остаться без боезапаса.
const TURRET_IDX := 3
const TURRET := {
	"name": "Турель", "damage": 25.0,
	"cooldown_ms": 110, "range": 120.0,
	"tracer": true, "magazine": 30, "reserve": 999, "reload_ms": 1600,
}

enum Mode { NONE, LAN, STEAM }

var mode: Mode = Mode.NONE


func weapon_label(idx: int) -> String:
	if WEAPONS.has(idx):
		return "[%d] %s" % [idx + 1, str(WEAPONS[idx]["name"])]
	return ""


func _ready() -> void:
	print("[BUILD] %s" % BUILD_TAG)

## Автотест в безголовом режиме (аргументы командной строки: -- host-lan smoke / -- join-lan 127.0.0.1 smoke)
var smoke_test := false
## Расширенный автотест: выстрелы имитируются настоящими событиями ввода
## через полный конвейер (аргументы командной строки: -- host-lan inputtest).
var input_test := false
## Автостарт матча из лобби (только для headless-проверок).
var autostart := false
## FFA-тест: хост набирает 5 фрагов, все ноды проверяют счёт и финал.
var ffa_test := false
## BUILD-30: тест турели — посадка/выход, очередь стволов, перезарядка,
## урон от сидящего, занятость. (аргумент командной строки: -- turrett)
var turret_test := false

@warning_ignore("unused_signal")
signal health_changed(value: float)
@warning_ignore("unused_signal")
signal scores_changed(scores: Dictionary, my_id: int)
@warning_ignore("unused_signal")
signal got_hit
@warning_ignore("unused_signal")
signal dealt_hit
@warning_ignore("unused_signal")
signal died(killer_label: String)
@warning_ignore("unused_signal")
signal respawned
@warning_ignore("unused_signal")
signal match_over(winner_label: String)
@warning_ignore("unused_signal")
signal player_spawned_local(player: Node)
@warning_ignore("unused_signal")
signal weapon_changed(label: String)


func goto_scene(path: String) -> void:
	call_deferred("_change_scene", path)


func _change_scene(path: String) -> void:
	get_tree().change_scene_to_file(path)


func my_id() -> int:
	return multiplayer.get_unique_id()


func is_headless() -> bool:
	return DisplayServer.get_name() == "headless"
