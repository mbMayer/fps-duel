extends Node
## Транспорт (LAN/Steam) и жизненный цикл матча.
##
## Оптимизация под 2 игроков: максимум один клиент у сервера,
## никаких списков комнат и лишнего трафика — только лобби-экран и бой.

signal lobby_updated
signal status_changed(text: String)

const PORT := 27015

var is_host := false
var _autostarted := false


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	_parse_cli.call_deferred()


# ---------------------------------------------------------------- LAN

func host_lan() -> void:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, Game.MAX_PLAYERS - 1)
	if err != OK:
		status_changed.emit("Не удалось создать сервер (код %d). Порт занят?" % err)
		return
	_go_online(peer, true, Game.Mode.LAN)
	status_changed.emit("LAN-сервер создан, ждём игрока…")
	if not Game.is_headless():
		Game.goto_scene(Game.LOBBY_SCENE)


func join_lan(ip: String) -> void:
	ip = ip.strip_edges()
	if ip.is_empty():
		ip = "127.0.0.1"
	status_changed.emit("Подключение к %s…" % ip)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		status_changed.emit("Не удалось подключиться (код %d)" % err)
		return
	_go_online(peer, false, Game.Mode.LAN)


func _go_online(peer: MultiplayerPeer, host: bool, mode: Game.Mode) -> void:
	multiplayer.multiplayer_peer = peer
	is_host = host
	Game.mode = mode


# ---------------------------------------------------------------- сигналы сети

func _on_peer_connected(_id: int) -> void:
	status_changed.emit("Игрок подключился")
	lobby_updated.emit()
	if Game.smoke_test and is_host:
		start_match.call_deferred()
	elif Game.autostart and is_host and multiplayer.get_peers().size() >= 2 and not _autostarted:
		# Headless-проверка: стартуем матч, когда собралось 3 игрока (хост + 2 клиента).
		_autostarted = true
		start_match.call_deferred()


func _on_peer_disconnected(_id: int) -> void:
	status_changed.emit("Игрок отключился")
	lobby_updated.emit()


func _on_connected_to_server() -> void:
	if Game.is_headless():
		print("[NET] подключены к серверу")
		return
	Game.goto_scene(Game.LOBBY_SCENE)


func _on_connection_failed() -> void:
	multiplayer.multiplayer_peer = null
	is_host = false
	status_changed.emit("Не удалось подключиться")
	if not Game.is_headless():
		Game.goto_scene(Game.MENU_SCENE)


func _on_server_disconnected() -> void:
	shutdown()
	status_changed.emit("Хост покинул игру")
	if Game.smoke_test:
		print("[SMOKE] сервер потерян до завершения теста")
		get_tree().quit(2)
		return
	if not Game.is_headless():
		Game.goto_scene(Game.MENU_SCENE)


# ---------------------------------------------------------------- матч

func start_match() -> void:
	if not is_host or not multiplayer.is_server():
		return
	SteamManager.on_match_started()
	_start_match_remote.rpc()
	Game.goto_scene(Game.GAME_SCENE)


@rpc("authority", "call_remote", "reliable")
func _start_match_remote() -> void:
	Game.goto_scene(Game.GAME_SCENE)


func return_to_lobby() -> void:
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		SteamManager.on_match_ended()
	if multiplayer.multiplayer_peer != null and not Game.is_headless():
		Game.goto_scene(Game.LOBBY_SCENE)
	elif not Game.is_headless():
		Game.goto_scene(Game.MENU_SCENE)


func leave_to_menu() -> void:
	shutdown()
	if not Game.is_headless():
		Game.goto_scene(Game.MENU_SCENE)


func shutdown() -> void:
	SteamManager.leave_lobby()
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	is_host = false
	Game.mode = Game.Mode.NONE


# ---------------------------------------------------------------- CLI-автотест

func _parse_cli() -> void:
	var args := OS.get_cmdline_user_args()
	var i := 0
	while i < args.size():
		match args[i]:
			"host-lan":
				host_lan()
			"join-lan":
				var ip := "127.0.0.1"
				if i + 1 < args.size() and not args[i + 1].begins_with("smoke"):
					ip = args[i + 1]
					i += 1
				join_lan(ip)
			"smoke":
				Game.smoke_test = true
			"inputtest":
				Game.smoke_test = true
				Game.input_test = true
			"autostart":
				Game.autostart = true
			"ffatest":
				Game.ffa_test = true
				Game.autostart = true
			"turrett":
				# BUILD-30: сценарий турели (посадка/огонь/перезарядка/выход).
				Game.turret_test = true
				Game.autostart = true
		i += 1
