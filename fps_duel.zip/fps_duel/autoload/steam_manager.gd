extends Node
## Интеграция со Steam через аддон GodotSteam (классы Steam и SteamMultiplayerPeer).
##
## Все обращения к Steam идут ДИНАМИЧЕСКИ (через Engine.get_singleton и ClassDB),
## поэтому без аддона проект спокойно работает в LAN-режиме и не падает.
##
## Сетевой транспорт — официальный лобби-пар от GodotSteam
## (godotsteam.com/tutorials/multiplayer_peer/): лобби создаётся через
## Steam.createLobby/joinLobby, затем SteamMultiplayerPeer.create_host(0)
## или create_client(steam_id_хоста, 0) с server_relay = true.
## Дальше работает обычный высокоуровневый мультиплеер Godot
## (те же RPC и спавн, что и в LAN).
##
## Источники:
##   - лобби:          godotsteam.com/tutorials/lobbies/
##   - авто-матчмейкинг: godotsteam.com/tutorials/auto_matchmaking/
##   - multiplayer peer: godotsteam.com/tutorials/multiplayer_peer/

const TAG_KEY := "game"
const TAG_VALUE := "fps_duel_proto"   # уникальный тег: по нему ищем ТОЛЬКО свои лобби

# Числовые константы Steamworks (k_E...), чтобы не зависеть от наличия аддона
# при разборе скрипта. Сверяются с: partner.steamgames.com/docs/api/ISteamMatchmaking
const LOBBY_TYPE_PUBLIC := 2          # k_ELobbyTypePublic
const LOBBY_COMPARISON_EQUAL := 0     # k_ELobbyComparisonEqual
const RESULT_OK := 1                  # k_EResultOK
const ENTER_OK := 1                   # k_EChatRoomEnterResponseSuccess

var available := false      # аддон установлен (классы существуют)
var initialized := false    # Steam запущен и инициализирован
var persona_name := "Игрок"
var steam_id: int = 0
var current_lobby_id: int = 0

signal status_changed(text: String)
signal lobby_members_changed

var steam: Object = null    # синглтон Steam (появляется только с аддоном)
var _peer = null            # SteamMultiplayerPeer
var _qm_active := false     # идёт быстрый матч
var _qm_phase := 0          # 0=рядом … 3=весь мир


func _process(_delta: float) -> void:
	# ОБЯЗАТЕЛЬНО: без вызова run_callbacks() сигналы Steam (lobby_created,
	# lobby_joined, lobby_match_list, приглашения и т.д.) не срабатывают.
	# Автозагрузчик всегда активен и не ставится на паузу — правильное место.
	if initialized:
		steam.run_callbacks()


func _ready() -> void:
	# Колбэки должны приходить даже если сцена на паузе.
	process_mode = Node.PROCESS_MODE_ALWAYS
	if not ClassDB.class_exists("Steam") or not ClassDB.class_exists("SteamMultiplayerPeer"):
		print("[Steam] аддон GodotSteam не найден — доступен только LAN-режим")
		return
	steam = Engine.get_singleton("Steam")
	if steam == null:
		# Запасной вариант для модульных сборок движка: компилируем мини-скрипт,
		# обращающийся к классу Steam напрямую.
		var helper := GDScript.new()
		helper.source_code = "extends RefCounted\nfunc get_steam():\n\treturn Steam\n"
		if helper.reload() == OK:
			steam = helper.new().get_steam()
	if steam == null:
		print("[Steam] класс найден, но синглтон не зарегистрирован")
		return
	available = true
	var init: Dictionary = steam.steamInitEx()
	print("[Steam] steamInitEx: ", init)
	if int(init.get("status", 1)) != 0:
		status_changed.emit("Steam не инициализирован: %s" % str(init.get("verbal", "?")))
		return
	initialized = true
	steam_id = steam.getSteamID()
	persona_name = steam.getPersonaName()
	steam.lobby_match_list.connect(_on_lobby_match_list)
	steam.lobby_created.connect(_on_lobby_created)
	steam.lobby_joined.connect(_on_lobby_joined)
	steam.lobby_chat_update.connect(_on_lobby_chat_update)
	if steam.has_signal("lobby_invite"):
		steam.lobby_invite.connect(_on_lobby_invite)
	if steam.has_signal("game_lobby_join_requested"):
		steam.game_lobby_join_requested.connect(_on_game_lobby_join_requested)


# ---------------------------------------------------------------- создание / вход
# Схема по официальному туториалу godotsteam.com/tutorials/multiplayer_peer/:
# 1) лобби создаётся/покидается через обычный Steam-матчмейкинг
#    (createLobby / joinLobby);
# 2) ПОСЛЕ колбэков создаётся SteamMultiplayerPeer:
#    хост -> create_host(0), клиент -> create_client(steam_id_хоста, 0);
# 3) только потом пир назначается в multiplayer (к этому моменту он уже
#    в состоянии connecting/connected).

func host_lobby() -> void:
	if not initialized:
		return
	if current_lobby_id != 0:
		status_changed.emit("Вы уже в лобби")
		return
	_ensure_no_peer()
	steam.createLobby(LOBBY_TYPE_PUBLIC, Game.MAX_PLAYERS)
	status_changed.emit("Создаём лобби…")


func join_lobby(lobby_id: int) -> void:
	if not initialized or lobby_id == 0:
		return
	if lobby_id == current_lobby_id:
		status_changed.emit("Вы уже в этом лобби")
		return
	_ensure_no_peer()
	steam.joinLobby(lobby_id)
	status_changed.emit("Подключаемся к лобби…")


func _host_peer() -> void:
	var peer = ClassDB.instantiate("SteamMultiplayerPeer")
	peer.create_host(0)
	peer.server_relay = true
	multiplayer.multiplayer_peer = peer
	_peer = peer


func _client_peer(host_steam_id: int) -> void:
	var peer = ClassDB.instantiate("SteamMultiplayerPeer")
	peer.create_client(host_steam_id, 0)
	peer.server_relay = true
	multiplayer.multiplayer_peer = peer
	_peer = peer


func _ensure_no_peer() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null


# ---------------------------------------------------------------- колбэки лобби

func _on_lobby_created(result: int, lobby_id: int) -> void:
	if result != RESULT_OK:
		status_changed.emit("Ошибка создания лобби (%d)" % result)
		_ensure_no_peer()
		return
	current_lobby_id = lobby_id
	NetworkManager.is_host = true
	Game.mode = Game.Mode.STEAM
	# Метаданные: по ним нас найдёт быстрый матч другого игрока.
	steam.setLobbyData(lobby_id, TAG_KEY, TAG_VALUE)
	steam.setLobbyData(lobby_id, "status", "waiting")
	steam.setLobbyData(lobby_id, "name", "%s — дуэль" % persona_name)
	steam.setLobbyJoinable(lobby_id, true)
	_host_peer()  # теперь пир можно назначить: он создан и подключается
	status_changed.emit("Лобби создано (код %d)" % lobby_id)
	lobby_members_changed.emit()
	if not Game.is_headless():
		Game.goto_scene(Game.LOBBY_SCENE)


func _on_lobby_joined(lobby_id: int, _permissions: int, _locked: bool, response: int) -> void:
	if response != ENTER_OK:
		status_changed.emit("Не удалось войти в лобби (%d)" % response)
		_ensure_no_peer()
		return
	current_lobby_id = lobby_id
	var owner_id: int = int(steam.getLobbyOwner(lobby_id))
	NetworkManager.is_host = (owner_id == steam_id)
	Game.mode = Game.Mode.STEAM
	if _peer == null:
		if NetworkManager.is_host:
			_host_peer()  # напр., вошли в собственное лобби по коду
		else:
			_client_peer(owner_id)
	status_changed.emit("Вы в лобби")
	lobby_members_changed.emit()
	# Дальше сработает multiplayer.connected_to_server -> переход в лобби-экран.


func _on_lobby_chat_update(_lobby_id: int, _who: int, _changed: int, _state: int) -> void:
	lobby_members_changed.emit()


# ---------------------------------------------------------------- быстрый матч

func quick_match() -> void:
	if not initialized:
		return
	if current_lobby_id != 0:
		status_changed.emit("Вы уже в лобби")
		return
	_qm_active = true
	_qm_phase = 0
	status_changed.emit("Поиск игры…")
	_qm_step()


func _qm_step() -> void:
	if not _qm_active:
		return
	if _qm_phase > 3:
		# Никого не нашли во всём мире — создаём своё лобби и ждём.
		_qm_active = false
		status_changed.emit("Свободных игр нет — создаём вашу, ожидаем соперника…")
		host_lobby()
		return
	# Фильтры сбрасываются после каждого requestLobbyList — ставим заново.
	steam.addRequestLobbyListStringFilter(TAG_KEY, TAG_VALUE, LOBBY_COMPARISON_EQUAL)
	steam.addRequestLobbyListFilterSlotsAvailable(1)
	steam.addRequestLobbyListDistanceFilter(_qm_phase)
	steam.requestLobbyList()


func _on_lobby_match_list(lobbies: Array) -> void:
	if not _qm_active:
		return
	for lobby_id in lobbies:
		var st: String = str(steam.getLobbyData(int(lobby_id), "status"))
		var members: int = int(steam.getNumLobbyMembers(int(lobby_id)))
		if st == "waiting" and members < Game.MAX_PLAYERS:
			_qm_active = false
			status_changed.emit("Игра найдена — подключаемся…")
			join_lobby(int(lobby_id))
			return
	_qm_phase += 1
	_qm_step()


# ---------------------------------------------------------------- приглашения

func invite_friend() -> void:
	if not initialized or current_lobby_id == 0:
		return
	if steam.has_method("activateGameOverlayInviteDialog"):
		steam.activateGameOverlayInviteDialog(current_lobby_id)
		status_changed.emit("Окно приглашений открыто")
	else:
		status_changed.emit("Оверлей недоступен — передайте другу код лобби: %d" % current_lobby_id)


func _on_lobby_invite(lobby_id: int, _friend_id: int, _game_id: int) -> void:
	status_changed.emit("Получено приглашение — подключаемся…")
	join_lobby(int(lobby_id))


func _on_game_lobby_join_requested(lobby_id: int, _friend_id: int) -> void:
	join_lobby(int(lobby_id))


# ---------------------------------------------------------------- служебное

func on_match_started() -> void:
	if initialized and current_lobby_id != 0:
		steam.setLobbyData(current_lobby_id, "status", "playing")
		steam.setLobbyJoinable(current_lobby_id, false)


func on_match_ended() -> void:
	if initialized and current_lobby_id != 0:
		steam.setLobbyData(current_lobby_id, "status", "waiting")
		steam.setLobbyJoinable(current_lobby_id, true)


func leave_lobby() -> void:
	if initialized and current_lobby_id != 0:
		steam.leaveLobby(current_lobby_id)
	if _peer != null and multiplayer.multiplayer_peer == _peer:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	current_lobby_id = 0
	_qm_active = false
	_peer = null


func lobby_member_count() -> int:
	if initialized and current_lobby_id != 0:
		return steam.getNumLobbyMembers(current_lobby_id)
	return 0
