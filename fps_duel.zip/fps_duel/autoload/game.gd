extends Node
## Глобальное состояние сессии + сигналы для HUD.

const MAX_PLAYERS := 4  # BUILD-34: четверо в кооп-обороне — по двое на пост
const GAME_SCENE := "res://scenes/game/arena.tscn"
const MENU_SCENE := "res://scenes/ui/menu.tscn"
const LOBBY_SCENE := "res://scenes/ui/lobby.tscn"
## Видимый маркер версии — первая строка в консоли при запуске.
## Если в логе другой номер, значит запущены старые файлы.
## Метка сборки печатается первой строкой при запуске: по ней видно, что
## запущена именно свежая версия (фикс-итерация после плейтеста).
const BUILD_TAG := "BUILD-39: на карте только ущелье и турели у кромки — мины и лестницы убраны совсем"

## Оружие: индекс = слот (1/2/3 на клавиатуре).
## Урон, дальность, кулдаун и патроны проверяются СЕРВЕРОМ — клиент не
## может стрелять оружием, которое не выбрано, или без патронов.
## Нож: ЛКМ — быстрый удар, ПКМ — сильный удар с замахом (задержка).
## Снайперка: ПКМ — прицеливание (уменьшает FOV и замедляет ходьбу).
const WEAPONS := {
	0: {
		"name": "Нож", "damage": 25.0, "heavy_damage": 60.0,
		"cooldown_ms": 400, "heavy_cooldown_ms": 900,
		"range": 1.3, "heavy_range": 1.7, "windup_ms": 450,
		"tracer": false, "magazine": -1, "reserve": 0, "reload_ms": 0,
	},
	1: {
		"name": "Пистолет", "damage": 25.0,
		"cooldown_ms": 250, "range": 60.0,
		"tracer": true, "magazine": 12, "reserve": 48, "reload_ms": 1200,
	},
	2: {
		"name": "Снайперская винтовка", "damage": 100.0,
		"cooldown_ms": 1300, "range": 200.0,
		"tracer": true, "magazine": 5, "reserve": 15, "reload_ms": 2600,
		"ads_fov": 22.0,
	},
}

## BUILD-30: турель — «оружие» индекса 3. Стреляет только сидящий в ней
## игрок; ствол выбирает сервер (левый/правый по очереди). Запас бесконечный
## (999) — турель не может остаться без боезапаса.
const TURRET_IDX := 3
const TURRET := {
	"name": "Турель", "damage": 25.0,
	"cooldown_ms": 110, "range": 120.0,
	"tracer": true, "magazine": 30, "reserve": 999, "reload_ms": 1600,
	# BUILD-38: пределы наклона стволов турели (рад): вниз 26°, вверх 40°.
	"pitch_min": -0.45, "pitch_max": 0.70,
}

enum Mode { NONE, LAN, STEAM }

var mode: Mode = Mode.NONE


func weapon_label(idx: int) -> String:
	if WEAPONS.has(idx):
		return "[%d] %s" % [idx + 1, str(WEAPONS[idx]["name"])]
	return ""


func _ready() -> void:
	print("[BUILD] %s" % BUILD_TAG)

## Автотест в безголовом режиме (аргументы командной строки: -- host-lan smoke / -- join-lan 127.0.0.1 smoke)
var smoke_test := false
## Расширенный автотест: выстрелы имитируются настоящими событиями ввода
## через полный конвейер (аргументы командной строки: -- host-lan inputtest).
var input_test := false
## Автостарт матча из лобби (только для headless-проверок).
var autostart := false
## Сколько пиров должно собраться до автостарта (обычно 2; для 2x2-теста — 3).
var autostart_peers := 2
## BUILD-30: тест турели — посадка/выход, очередь стволов, перезарядка,
## урон от сидящего, занятость. (аргумент командной строки: -- turrett)
var turret_test := false
## BUILD-31: тест турели НАСТОЯЩЕЙ КЛАВИАТУРОЙ (Input.parse_input_event по
## клавише F) — проверка пользовательского сценария «сел — сижу — вышел».
## (аргумент командной строки: -- keytest)
var key_test := false
## BUILD-31: видна ли посадка/поворот купола СОПЕРНИКУ. (-- keysync)
var keysync_test := false
## BUILD-31: смерть сидящего освобождает турель. (-- deatht)
var death_test := false
## BUILD-32: проверка геометрии карты «Ущелье» лучами (-- maptest).
var map_test := false
## BUILD-33: сквозная проверка «меню -> хост -> матч».
var defmenu_test := false
## BUILD-34: проверка кооп-правил в интерфейсе (нет PvP, есть подсказка про E).
var coop_test := false
## BUILD-35: снять скриншоты карты (только с оконным рендером).
var shots_test := false
## BUILD-35: проверка проходимости карты «ногами» (капсула игрока).
var walk_test := false
## BUILD-34: проверка ранения и подъёма товарищем (-- revivet).
var revive_test := false
## BUILD-35: проверка бега (Shift) и его синхронизации в сети (-- sprinttest).
var sprint_test := false
## BUILD-36: проверка рук от первого лица при резком развороте камеры (-- armtest).
var arm_test := false
## BUILD-34: служебные headless-сценарии стрельбы/турели идут в одиночку на
## тестовой площадке, без волн: этот флаг включает такое «песочное» состояние.
var solo_test_mode := false
## BUILD-34: игра теперь ТОЛЬКО кооп — «Оборона»: до четырёх игроков держат
## два берега ущелья против волн «Полых людей» (по мотивам фильма «Ущелье»).
## Флаг остаётся: служебные headless-сценарии стрельбы его выключают.
var defense_mode := true
## BUILD-33: укороченный прогон обороны для headless-проверки (-- defenset).
var defense_test := false
## BUILD-34: подъём товарища (значения видят и арена, и подсказки HUD).
const REVIVE_RANGE := 2.6     # м — насколько близко нужно подойти
const REVIVE_TIME := 1.6      # с — сколько длится подъём
const REVIVE_HP := 60.0       # сколько HP возвращает подъём
const BLEEDOUT_TIME := 25.0   # с — через столько раненый сам вернётся на пост

@warning_ignore("unused_signal")
signal health_changed(value: float)
@warning_ignore("unused_signal")
signal scores_changed(scores: Dictionary, my_id: int)
@warning_ignore("unused_signal")
signal got_hit
@warning_ignore("unused_signal")
signal dealt_hit
@warning_ignore("unused_signal")
signal died(killer_label: String)
@warning_ignore("unused_signal")
signal respawned
@warning_ignore("unused_signal")
signal match_over(winner_label: String)
@warning_ignore("unused_signal")
signal player_spawned_local(player: Node)
@warning_ignore("unused_signal")
signal weapon_changed(label: String)
@warning_ignore("unused_signal")
signal announce(text: String)
# BUILD-33: кооп-оборона — состояние волны и периметра.
@warning_ignore("unused_signal")
signal defense_changed(wave: int, waves_total: int, alive: int, kills: int, perimeter: float)
@warning_ignore("unused_signal")
# BUILD-34: кооп-отряд — состав, посты, здоровье и кто ранен.
@warning_ignore("unused_signal")
signal squad_changed(members: Array)
# BUILD-34: ранение и подъём товарищем.
@warning_ignore("unused_signal")
signal downed(bleedout: float)
@warning_ignore("unused_signal")
signal revived()
@warning_ignore("unused_signal")
signal revive_progress(value: float, label: String)


func goto_scene(path: String) -> void:
	call_deferred("_change_scene", path)


func _change_scene(path: String) -> void:
	get_tree().change_scene_to_file(path)


func my_id() -> int:
	return multiplayer.get_unique_id()


func is_headless() -> bool:
	return DisplayServer.get_name() == "headless"
