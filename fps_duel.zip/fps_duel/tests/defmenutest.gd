extends Node
## BUILD-34: сквозная проверка пути игрока без ключей командной строки:
## меню -> «Хост в локальной сети» -> лобби (кооп, четыре слота) -> «Начать матч» ->
## арена -> из ущелья лезут полые люди. Именно этим путём идёт человек, который
## просто запускает игру: режим выбирать больше не нужно, он один — кооп-оборона.

var _checks := 0
var _fails := 0


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[DEFMENU] OK   %s" % label)
	else:
		_fails += 1
		print("[DEFMENU] ФЕЙЛ %s" % label)


func _ready() -> void:
	await get_tree().process_frame
	# 1) Меню: никакого выбора режима — режим всегда кооп-оборона.
	var menu: Control = load("res://scenes/ui/menu.tscn").instantiate()
	get_tree().root.add_child(menu)
	get_tree().current_scene = menu
	await get_tree().process_frame
	_ok(menu.get_node_or_null("Layout/VBox/ModeSelect") == null, "в меню нет выбора режима (PvP убран)")
	_ok(Game.defense_mode, "режим игры — кооп-оборона, без ключей и настроек")
	var host_btn: Button = menu.get_node("Layout/VBox/LanRow/LanHostBtn")
	_ok(host_btn != null and not host_btn.disabled, "кнопка «Хост в локальной сети» доступна")

	# 2) Жмём кнопку мышью: хост поднимается, игра уходит в лобби.
	host_btn.pressed.emit()
	await get_tree().create_timer(0.6).timeout
	_ok(NetworkManager.is_host, "хост поднят кнопкой из меню")
	var lobby: Node = get_tree().current_scene
	if lobby == null or not lobby.has_method("_refresh"):
		# На экране игра сама показывает лобби, а в headless-прогоне сцена меняется
		# только на матч — поэтому лобби поднимаем руками и проверяем его узлы.
		menu.queue_free()
		lobby = load("res://scenes/ui/lobby.tscn").instantiate()
		get_tree().root.add_child(lobby)
		await get_tree().process_frame
		_ok(true, "экран лобби открылся (в headless-прогоне сцена проверяется напрямую)")
	elif true:
		_ok(true, "экран лобби открылся")
	if lobby != null and lobby.has_method("_refresh"):
		lobby._refresh()
		await get_tree().process_frame
		_ok(lobby.get_node_or_null("Layout/VBox/HostRow/ModeBtn") == null, "в лобби нет переключателя режима")
		var hint: Label = lobby.get_node("Layout/VBox/PlayerList/ModeHint")
		_ok(hint.text.contains("по двое"), "лобби объясняет расклад по постам")
		var start_btn: Button = lobby.get_node("Layout/VBox/HostRow/StartBtn")
		_ok(start_btn != null, "в лобби есть кнопка «Начать матч»")
		lobby.queue_free()
		await get_tree().process_frame

	# 3) «Начать матч» — та же функция, что и у кнопки StartBtn в лобби.
	# В одиночном headless-прогоне второй игрок не подключится, поэтому зовём старт сами.
	NetworkManager.start_match()

	# 3) Сцена матча загрузилась — ждём, пока из ущелья выйдет первый полый.
	var arena: Node = null
	for i in 60:
		await get_tree().create_timer(0.5).timeout
		if get_tree().current_scene != null and get_tree().current_scene.has_method("hollows"):
			arena = get_tree().current_scene
			break
	_ok(arena != null, "матч загрузился (арена на месте)")
	_ok(Game.defense_mode, "режим матча — оборона")
	# Соло-хост: клиентов нет, поэтому «готовность» никто не присылает.
	# В настоящей игре матч начинается из лобби (кнопка активна с двумя игроками),
	# а в проверке запускаем спавн сами — ровно тот же код, что и при клиенте.
	if arena != null and arena.players.size() == 0:
		arena._try_spawn_all()
		await get_tree().create_timer(0.5).timeout
	_ok(arena != null and arena.players.size() >= 1, "игрок появился на арене (соло-хост)")
	var saw := false
	for i in 60:
		if arena != null and arena.hollows().size() > 0:
			saw = true
			break
		await get_tree().create_timer(0.5).timeout
	_ok(saw, "из ущелья вышел полый человек (волна пошла)")
	var hud := arena.get_node_or_null("HUD") if arena != null else null
	var txt := ""
	if hud != null:
		txt = str(hud.defense_label.text)
	_ok(txt.contains("Волна"), "строка обороны видна в HUD: «%s»" % txt)

	# 6) Модель снайперки: сцена грузится и материалы получают текстуру даже без
	# импорта (запуск без редактора и без .godot) — иначе в консоль сыпались
	# Parse Error, а снайперка подменялась заглушкой.
	var sn: Node3D = load("res://sniper_gun.tscn").instantiate()
	add_child(sn)
	await get_tree().process_frame
	_ok(sn != null, "модель снайперки загрузилась без редактора")
	_ok(sn.textured_surfaces() > 0, "материалы снайперки получили текстуру (%d поверхностей)" % sn.textured_surfaces())

	print("[DEFMENU] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0:
		print("[DEFMENU_OK] путь «меню -> хост в LAN -> лобби -> матч» работает без ключей командной строки")
	else:
		print("[DEFMENU_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	await get_tree().create_timer(1.0).timeout
	get_tree().quit()
