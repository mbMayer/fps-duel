extends Node
## BUILD-34: проверка кооп-правил в интерфейсе и в геймплее (без сети).
## Главное, что проверяем: PvP-режима больше нет ни в меню, ни в лобби, а правила
## кооператива (один отряд, подъём товарища) объяснены игроку прямо на экранах.

var _checks := 0
var _fails := 0


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[COOPTEST] OK   %s" % label)
	else:
		_fails += 1
		print("[COOPTEST] ФЕЙЛ %s" % label)


func _ready() -> void:
	await get_tree().process_frame
	# 1) Игра всегда кооперативная: режим включён по умолчанию.
	_ok(Game.defense_mode, "режим обороны включён без ключей и настроек")
	_ok(not Game.solo_test_mode, "обычная игра — не песочница тестов")

	# 2) Меню: нет выбора режима, но есть правила кооператива.
	var menu: Control = load("res://scenes/ui/menu.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	_ok(menu.get_node_or_null("Layout/VBox/ModeSelect") == null, "в меню нет выбора «PvP / Оборона»")
	var mhint: Label = menu.get_node("Layout/VBox/ModeHint")
	_ok(mhint.text.contains("Кооп"), "меню объясняет, что игра кооперативная")
	_ok(mhint.text.contains("E"), "меню подсказывает про клавишу E (подъём товарища)")
	_ok(not mhint.text.contains("мин"), "в меню нет подсказки про мины (G убран)")

	# 3) Лобби: нет кнопки режима, четыре слота, правила про посты и подъём.
	var lobby: Control = load("res://scenes/ui/lobby.tscn").instantiate()
	add_child(lobby)
	await get_tree().process_frame
	_ok(lobby.get_node_or_null("Layout/VBox/HostRow/ModeBtn") == null, "в лобби нет переключателя PvP")
	var lhint: Label = lobby.get_node("Layout/VBox/PlayerList/ModeHint")
	_ok(lhint.text.contains("по двое"), "лобби объясняет расклад по постам")
	_ok(lhint.text.contains("поднимает"), "лобби объясняет подъём раненого")
	_ok(lobby.get_node_or_null("Layout/VBox/PlayerList/P4Label") != null, "четыре слота (по двое на пост)")

	# 4) HUD: нет командных строк и счёта «Синие : Красные».
	var arena: Node = load("res://scenes/game/arena.tscn").instantiate()
	add_child(arena)
	await get_tree().process_frame
	var hud: Node = arena.get_node_or_null("HUD")
	_ok(hud != null, "HUD на месте")
	if hud != null:
		_ok(hud.get_node_or_null("TeamLabel") == null, "в HUD нет строки «СИНИЕ : КРАСНЫЕ»")
		_ok(hud.get_node_or_null("RoundLabel") == null, "в HUD нет строки раунда")
		_ok(hud.get_node_or_null("TeamBadge") == null, "в HUD нет бейджа команды")
		_ok(hud.get_node_or_null("SquadLabel") != null, "в HUD есть сводка отряда")
		_ok(hud.get_node_or_null("ReviveHint") != null, "в HUD есть подсказка про подъём (E)")
		_ok(hud.get_node_or_null("MinesLabel") == null, "счётчика мин в HUD больше нет")
		_ok(hud.get_node_or_null("DefenseLabel") != null, "в HUD есть строка волны и периметра")

	# 5) Геймплей: по товарищу урон не проходит, а от «Полого» — проходит.
	var ids := [11, 22]
	for pid in ids:
		var p: Node3D = load("res://scenes/game/player.tscn").instantiate()
		p.name = str(pid)
		arena.players_root.add_child(p)
		arena.players[pid] = p
	arena.sides[11] = 1
	arena.sides[22] = -1
	var a: Node = arena.players[11]
	var b: Node = arena.players[22]
	a.health = 100.0
	b.health = 100.0
	arena._apply_damage(b, a, 40.0)
	_ok(b.health >= 99.0, "выстрел по товарищу урона не наносит (hp=%.0f)" % b.health)
	arena.hurt_player_by_env(b, 30.0, 0)
	_ok(b.health <= 70.5, "«Полый человек» урон наносит (hp=%.0f)" % b.health)
	# 6) Добивание: игрок падает раненым, а не «умирает».
	arena.hurt_player_by_env(b, 500.0, 0)
	await get_tree().process_frame
	_ok(b.downed and not b.dead, "на нуле HP игрок становится раненым (не выбывает из игры)")
	_ok(arena.nearest_downed_within(a.global_position + Vector3(0.5, 0, 0), Game.REVIVE_RANGE) == b,
		"раненый находится поиском для подъёма")

	print("[COOPTEST] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0:
		print("[COOPTEST_OK] кооп-правила: без PvP, с отрядом, прорывом периметра и подъёмом товарища")
	else:
		print("[COOPTEST_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	await get_tree().create_timer(1.0).timeout
	get_tree().quit()
