extends Node
## BUILD-35: инструмент скриншотов карты — чтобы проверять геометрию глазами,
## а не догадками. Запускается из арены по ключу `shots` с ОКОННЫМ рендером
## (см. run_shots.sh: Xvfb + программный Vulkan), потому что headless-драйвер
## картинку не отдаёт.
##
## Кадры сохраняются в user://shots/, отчёт — в консоль. Каждый кадр — это
## отдельная точка обзора (обрыв, ущелье, точка прорыва, тропа, карта целиком).
## BUILD-38: башен и тумана нет. BUILD-39: нет и лестниц-серпантинов на дно —
## проверяем это и по узлам карты, и глазами (кадры у кромки и у стены ущелья).

var _pub := ""      # куда дополнительно копировать кадры (пусто — только user://)
var _checks := 0
var _fails := 0


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[SHOTS] OK   %s" % label)
	else:
		_fails += 1
		print("[SHOTS] ФЕЙЛ %s" % label)


func _ready() -> void:
	_pub = OS.get_environment("SHOTS_DIR")
	call_deferred("_run")


func _run() -> void:
	# Арена — это текущая сцена (наш узел живёт под автозагрузкой NetworkManager).
	var arena: Node = get_tree().current_scene
	print("[SHOTS] сцена: %s" % str(arena))
	# Страховка от зависания: снимки не должны держать прогон дольше двух минут.
	get_tree().create_timer(120.0).timeout.connect(func() -> void:
		print("[SHOTS_FAIL] не успели снять кадры за 120 с")
		get_tree().quit()
	)
	# Ждём, пока арена построит карту и включит окружение.
	for i in 10:
		await get_tree().process_frame

	# BUILD-38: туман убран — объёмный туман окружения выключен, объёмов нет.
	var we: WorldEnvironment = arena.get_node_or_null("WorldEnvironment")
	var env: Environment = we.environment if we != null else get_viewport().world_3d.environment
	_ok(env != null and not env.volumetric_fog_enabled, "объёмный туман окружения выключен (BUILD-38: тумана нет)")
	var fogs := 0
	var towers := 0
	var ladders := 0
	for child in arena.get_node("Map").get_children():
		var nm := str(child.name)
		if child is FogVolume:
			fogs += 1
		if nm.begins_with("Tower"):
			towers += 1
		# BUILD-39: настилов и ограждений серпантина на карте быть не должно.
		if nm.begins_with("Ramp") or nm.begins_with("Path") or nm.begins_with("Rail"):
			ladders += 1
	print("[SHOTS] объёмов тумана: %d, узлов башни: %d, узлов лестниц: %d" % [fogs, towers, ladders])
	_ok(fogs == 0 and towers == 0 and ladders == 0,
		"на карте только ущелье и турели: ни тумана, ни башен, ни лестниц")

	var shots := [
		# [имя, позиция камеры, цель взгляда, что проверяем глазами]
		["01_spawn_north", Vector3(-14.0, 1.7, 38.0), Vector3(0.0, 2.0, 10.0)],
		["02_gorge_open", Vector3(0.0, 9.0, 16.0), Vector3(0.0, -40.0, -10.0)],
		["03_rim_north", Vector3(-30.0, 4.0, 26.5), Vector3(20.0, 1.0, 24.0)],
		["04_breach_north", Vector3(0.0, 3.0, 34.0), Vector3(0.0, 0.5, 23.0)],
		["05_turret_north", Vector3(-4.5, 2.6, 28.0), Vector3(-7.0, 0.6, 22.6)],
		["06_gorge_bottom", Vector3(-13.0, -57.0, 18.0), Vector3(-6.0, -45.0, 0.0)],
		["07_map_top", Vector3(52.0, 46.0, 62.0), Vector3(0.0, -10.0, 0.0)],
		["08_west_wall", Vector3(-18.0, 2.4, 23.0), Vector3(-16.0, -34.0, 18.0)],
	]
	# HUD в кадры не нужен: он перекрывает карту.
	var hud := arena.get_node_or_null("HUD")
	if hud != null:
		hud.visible = false
	var frame_colors: Array[Color] = []
	var dir := "user://shots"
	DirAccess.make_dir_recursive_absolute(dir)
	var saved := 0
	for sh in shots:
		var cam := Camera3D.new()
		arena.add_child(cam)
		cam.fov = 70.0
		cam.look_at_from_position(sh[1], sh[2], Vector3.UP)
		cam.current = true
		# Программный рендер медленный: даём ему несколько кадров на кадр.
		for i in 4:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var img: Image = get_viewport().get_texture().get_image()
		# Средний цвет кадра — быстрый способ заметить «серый экран без геометрии».
		var sum := Color(0.0, 0.0, 0.0)
		var n := 0
		for sx in 8:
			for sy in 6:
				sum += img.get_pixel(int(img.get_width() * (sx + 0.5) / 8.0), int(img.get_height() * (sy + 0.5) / 6.0))
				n += 1
		var avg: Color = sum / float(n)
		frame_colors.append(avg)
		print("[SHOTS] кадр %s: средний цвет %.2f,%.2f,%.2f" % [sh[0], avg.r, avg.g, avg.b])
		var path := "%s/%s.png" % [dir, sh[0]]
		var err := img.save_png(path)
		if err == OK:
			saved += 1
			print("[SHOTS] кадр %s → %s" % [sh[0], ProjectSettings.globalize_path(path)])
			if _pub != "":
				img.save_png("%s/%s.png" % [_pub, sh[0]])
		else:
			print("[SHOTS] ФЕЙЛ не сохранился кадр %s (код %d)" % [sh[0], err])
		cam.queue_free()
	_ok(saved >= shots.size() - 1, "кадры сохранены (%d из %d)" % [saved, shots.size()])

	# --- BUILD-38: кадр с ПОДНЯТЫМИ стволами турели --------------------------
	# Числа проверяют turrett/keysync, а этот кадр — доказательство глазами:
	# стволы обязаны уйти вверх, а не остаться в горизонте.
	if arena.turrets.size() > 0:
		var t: Node3D = arena.turrets[0]
		var cam2 := Camera3D.new()
		arena.add_child(cam2)
		cam2.fov = 60.0
		cam2.look_at_from_position(t.position + Vector3(2.6, 1.6, 2.2), t.position + Vector3(0.0, 0.55, 0.0), Vector3.UP)
		cam2.current = true
		for i in 4:
			await get_tree().process_frame
		# Наклон ставим ПОСЛЕ ожиданий и снимаем сразу: автотурель арены каждый
		# кадр возвращает стволы в горизонт, поэтому «подождать и посмотреть» нельзя.
		var up_set := 0.6
		t._pitch = up_set
		t._pitch_target = up_set
		t.pitch_node.rotation.x = up_set
		# Замер ДО снятия: после кадра автотурель успевает опустить стволы.
		var up_now := rad_to_deg(float(t.pitch_node.rotation.x))
		await RenderingServer.frame_post_draw
		var im: Image = get_viewport().get_texture().get_image()
		var nm := 0
		if _pub != "":
			nm = im.save_png("%s/11_turret_pitch.png" % _pub)
		im.save_png("user://shots/11_turret_pitch.png")
		saved += 1 if nm == OK or _pub == "" else 0
		print("[SHOTS] стволы турели стояли поднятыми на %.1f° в момент снимка: кадр 11_turret_pitch" % up_now)
		_ok(absf(up_now) > 30.0, "стволы турели на кадре подняты (%.1f°, ждали ~34°)" % up_now)
		cam2.queue_free()
		t._pitch = 0.0
		t._pitch_target = 0.0
		t.pitch_node.rotation.x = 0.0

	# --- BUILD-36: вид от первого лица — руки на оружии ---------------------
	# Отдельные кадры ставят в мир игрока и снимают из ЕГО камеры: так видно
	# позу рук. Второй кадр — сразу после резкого разворота на 180°: руки
	# обязаны идти вместе с камерой (иначе «проворот», см. тест armtest).
	var fp := await _fp_view_shots(arena)
	saved += int(fp[0])
	frame_colors.append(fp[1])
	frame_colors.append(fp[2])
	# Кадры должны отличаться: если все одинаковые — либо камера не переключается,
	# либо всё затянуто туманом (ровно та ошибка, ради которой снимки и делаются).
	var distinct := 0
	for i in frame_colors.size():
		var uniq := true
		for j in i:
			if frame_colors[i].is_equal_approx(frame_colors[j]):
				uniq = false
		if uniq:
			distinct += 1
	_ok(distinct >= frame_colors.size() - 1, "кадры различаются, а не «один серый экран» (%d уникальных из %d)" % [distinct, frame_colors.size()])


	print("[SHOTS] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0:
		print("[SHOTS_OK] скриншоты карты сняты: %s" % ProjectSettings.globalize_path(dir))
	else:
		print("[SHOTS_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	# Даём Xvfb-окну закрыться и выходим.
	await get_tree().create_timer(0.4).timeout
	get_tree().quit()

## Снимает вид от первого лица: обычная стойка и стойка сразу после разворота
## на 180°. Возвращает [сколько сохранилось, средний цвет, средний цвет].
func _fp_view_shots(arena: Node) -> Array:
	var p: Node3D = load("res://scenes/game/player.tscn").instantiate()
	p.name = "1"
	arena.add_child(p)
	p.global_position = Vector3(-14.0, 0.2, 32.0)
	p.rotation.y = 0.0          # лицом к ущелью (вперёд у Godot — -Z)
	for i in 4:
		await get_tree().process_frame
	var colors: Array[Color] = []
	var saved := 0
	var steps := [
		["09_fp_arms", 0.0],       # стойка: руки на оружии
		["10_fp_after_flick", PI], # +180°: руки идут за камерой, без проворота
	]
	for st in steps:
		p.rotation.y += float(st[1])
		p._update_body_pose(1.0 / 60.0, false, Vector3.ZERO, false, true, 0.0, 0.0, 0.0)
		p._update_fp_arms()
		var cam: Camera3D = p.camera
		cam.current = true
		for i in 4:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var img: Image = get_viewport().get_texture().get_image()
		var sum := Color(0.0, 0.0, 0.0)
		var n := 0
		for sx in 8:
			for sy in 6:
				sum += img.get_pixel(int(img.get_width() * (sx + 0.5) / 8.0), int(img.get_height() * (sy + 0.5) / 6.0))
				n += 1
		var avg: Color = sum / float(n)
		colors.append(avg)
		print("[SHOTS] вид от первого лица %s: средний цвет %.2f,%.2f,%.2f" % [st[0], avg.r, avg.g, avg.b])
		var path := "%s/%s.png" % ["user://shots", st[0]]
		if img.save_png(path) == OK:
			saved += 1
			print("[SHOTS] кадр %s → %s" % [st[0], ProjectSettings.globalize_path(path)])
			if _pub != "":
				img.save_png("%s/%s.png" % [_pub, st[0]])
	p.visible = false
	return [saved, colors[0], colors[1]]
