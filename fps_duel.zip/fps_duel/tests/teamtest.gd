# BUILD-32: headless-проверка командного режима «Ущелье».
#
# Сценарий (выполняет СЕРВЕР — хост, 2x2 = 1 хост + 3 клиента):
#   1) раунд 1: все четверо разложены по берегам согласно командам;
#   2) по своим стрелять нельзя — урон по союзнику не проходит;
#   3) фраг засчитывается КОМАНДЕ, по достижении лимита раунд закрывается;
#   4) после раунда стороны меняются — команда уходит на другой берег;
#   5) туман на дне ущелья отнимает здоровье, на плато — нет;
#   6) наверх (к башне) ведут настилы: спуск в туман — рискованный путь в тыл.
#
# Клиенты (2-й, 3-й инстансы) самостоятельно проверяют свои спавны по берегам.
extends Node

var _checks := 0
var _fails := 0
var _done := false

var _r1_north := -1
var _r1_side: Dictionary = {}       # id -> был ли север (для проверки смены сторон)
var _r2_checked := false
var _frag_team := -1

const Map := preload("res://scenes/game/gorge.gd")


func _ready() -> void:
	name = "TeamTest"
	# Параметры прогона: раунд до 2 фрагов, матч до 2 побед (нужен раунд 2).
	Game.round_frags = 2
	Game.rounds_to_win = 2
	Game.round_intermission = 3.0
	if multiplayer.is_server():
		_server_scenario()
	else:
		_client_scenario()


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[TT] OK   %s" % label)
	else:
		_fails += 1
		print("[TT] ФЕЙЛ %s" % label)


## Арена появляется только после старта матча (до этого в current_scene — меню).
func _arena() -> Node:
	var root := get_tree().root
	var a := root.get_node_or_null("Arena")
	if a == null:
		var cs := get_tree().current_scene
		if cs != null and cs.name == "Arena":
			a = cs
	return a


func _wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


## Ждём, пока арена объявит нужный раунд (с ограничением по времени).
func _wait_round(no: int, limit: float) -> bool:
	var t := 0.0
	while t < limit:
		var a := _arena()
		if a != null and a.get("round_no") != null and int(a.round_no) == no and bool(a._round_live):
			return true
		await _wait(0.2)
		t += 0.2
	return false


func _side_ids(north: bool) -> Array:
	var out: Array = []
	for id in _arena().teams.keys():
		if _arena().players.has(id):
			var pos: Vector3 = _arena().players[id].global_position
			if (pos.z > 0.0) == north:
				out.append(int(id))
	return out


func _team_ids(team: int) -> Array:
	var out: Array = []
	for id in _arena().teams.keys():
		if int(_arena().teams[id]) == team:
			out.append(int(id))
	out.sort()
	return out


func _foe_of(id: int) -> int:
	for other in _team_ids(1 - int(_arena().teams.get(id, 0))):
		return other
	return -1


func _kill(killer_id: int, victim_id: int) -> void:
	var a := _arena()
	var killer: Node = a.players.get(killer_id)
	var victim: Node = a.players.get(victim_id)
	a._apply_damage(victim, killer, 999.0)


# ------------------------------------------------------------------ сервер

func _server_scenario() -> void:
	print("[TT] --- серверный сценарий (2x2) ---")
	if not await _wait_round(1, 25.0):
		_ok(false, "раунд 1 начался")
		_finish()
		return
	await _wait(1.0)

	# 1) Расклад по берегам.
	_r1_north = int(_arena()._north_team())
	var north := _side_ids(true)
	var south := _side_ids(false)
	var teams_ok := true
	for id in north:
		teams_ok = teams_ok and int(_arena().teams[id]) == _r1_north
	for id in south:
		teams_ok = teams_ok and int(_arena().teams[id]) != _r1_north
	for id in north + south:
		_r1_side[int(id)] = north.has(int(id))
	_ok(north.size() == 2 and south.size() == 2, "по двое на каждом берегу (север=%s, юг=%s)" % [str(north), str(south)])
	_ok(teams_ok, "берег игрока совпадает с его командой (север = %s)" % _arena().team_name(_r1_north))

	# 2) Башня и её площадка есть на своём берегу (луч сверху вниз).
	var tower_ok := true
	var space: PhysicsDirectSpaceState3D = _arena().get_world_3d().direct_space_state
	for t in [0, 1]:
		var tower: Vector3 = Map.TOWER_POS_N if t == _r1_north else Map.TOWER_POS_S
		# Крыша башни выше площадки — проверяем уровень площадки лучом снизу крыши.
		var hit: Dictionary = _arena()._map_ray(space, tower + Vector3(0, 13.0, 0), tower)
		var top: float = float(hit.get("position", Vector3.ZERO).y) if not hit.is_empty() else -99.0
		var roof: Dictionary = _arena()._map_ray(space, tower + Vector3(0, 24.0, 0), tower)
		var roof_y: float = float(roof.get("position", Vector3.ZERO).y) if not roof.is_empty() else -99.0
		tower_ok = tower_ok and absf(top - Map.TOWER_TOP_Y) < 0.5 and roof_y > Map.TOWER_TOP_Y
	_ok(tower_ok, "на обоих берегах площадка башни на высоте %.0f м" % Map.TOWER_TOP_Y)

	# 3) Дружественный огонь выключен.
	var blue := _team_ids(0)
	var red := _team_ids(1)
	if blue.size() >= 2:
		var victim: Node = _arena().players[blue[1]]
		var hp_before: float = victim.health
		_arena()._apply_damage(victim, _arena().players[blue[0]], 40.0)
		_ok(is_equal_approx(victim.health, hp_before), "урон по своему не проходит (hp %.0f -> %.0f)" % [hp_before, victim.health])

	# 4) Фраги: первый фраг — команде, второй закрывает раунд.
	_frag_team = int(_arena().teams.get(blue[0], 0))
	var foe1 := _foe_of(blue[0])
	var foe2 := _foe_of(blue[1]) if not blue[1] == blue[0] else -1
	if foe1 == blue[1]:
		foe2 = _foe_of(red[0])
	if foe2 < 0 or foe2 == foe1:
		var enemies := _team_ids(1 - _frag_team)
		foe2 = enemies[0]
	_ok(_arena().team_of(blue[0]) == _frag_team and _arena().team_of(foe1) != _frag_team, "цели фрага — соперники (%d против %d)" % [blue[0], foe1])
	_kill(blue[0], foe1)
	await _wait(0.6)
	var frags1 := int(_arena().team_frags.get(_frag_team, 0))
	_ok(frags1 == 1, "фраг записан КОМАНДЕ %s (фраги=%s)" % [_arena().team_name(_frag_team), str(_arena().team_frags)])

	# 5) Туман на дне ущелья отнимает здоровье, на плато — нет.
	var bot: Vector3 = Map.PATH_BOTTOM_N
	_arena().test_set_pos(blue[0], Vector3(bot.x, bot.y + 1.2, bot.z), 0.0)
	var hp_top: float = _arena().players[blue[0]].health
	await _wait(0.3)
	_ok(is_equal_approx(_arena().players[blue[0]].health, hp_top), "на дне туман не бьёт мгновенно (копится порциями, %.0f)" % _arena().players[blue[0]].health)
	await _wait(7.0)
	var hp_bottom: float = _arena().players[blue[0]].health
	_ok(hp_bottom < hp_top - 10.0, "в тумане на дне ущелья здоровье падает (%.0f -> %.0f)" % [hp_top, hp_bottom])
	_arena().test_set_pos(blue[0], Map.SPAWN_NORTH[0] if _r1_north == _frag_team else Map.SPAWN_SOUTH[0], 0.0)
	await _wait(1.5)
	var hp_back: float = _arena().players[blue[0]].health
	await _wait(2.0)
	_ok(is_equal_approx(_arena().players[blue[0]].health, hp_back), "на плато туман не отнимает здоровье")

	# 6) Второй фраг закрывает раунд и начисляет победу в раунде.
	_kill(blue[1] if blue.size() > 1 and _arena().team_of(blue[1]) == _frag_team else blue[0], foe2)
	await _wait(1.0)
	var rounds1 := int(_arena().team_rounds.get(_frag_team, 0))
	_ok(rounds1 >= 1, "раунд 1 закрыт, победа в раунде у %s (раунды=%s)" % [_arena().team_name(_frag_team), str(_arena().team_rounds)])

	# 7) Смена сторон во втором раунде.
	if not await _wait_round(2, 25.0):
		_ok(false, "раунд 2 начался после перерыва")
		_finish()
		return
	await _wait(1.0)
	var north2 := int(_arena()._north_team())
	_ok(north2 != _r1_north, "стороны сменились (раунд 1: север=%s, раунд 2: север=%s)" % [_arena().team_name(_r1_north), _arena().team_name(north2)])
	var moved := true
	for id in _r1_side.keys():
		if not _arena().players.has(id):
			continue
		var was_north: bool = _r1_side[id]
		var now_north: bool = _arena().players[id].global_position.z > 0.0
		moved = moved and (was_north != now_north)
	_ok(moved, "все игроки перешли на другой берег")

	_finish()


func _finish() -> void:
	if _done:
		return
	_done = true
	print("[TT] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0 and _checks > 0:
		print("[TEAMTEST_OK] команды 2x2, берега, раунды со сменой сторон и туман ущелья проверены")
	else:
		print("[TEAMTEST_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	await _wait(3.0)  # даём клиентам время закончить свои проверки
	get_tree().quit()


# ------------------------------------------------------------------ клиент

func _client_scenario() -> void:
	var me := multiplayer.get_unique_id()
	print("[TT] --- клиент %d: проверяю свой берег ---" % me)
	await _wait(2.0)
	var fails := 0
	# Раунд 1: мой берег должен совпадать с командой.
	for attempt in 6:
		var a := _arena()
		if a != null and not _arena().teams.is_empty() and int(_arena().teams.get(me, -1)) >= 0:
			break
		await _wait(0.7)
	var a := _arena()
	if a == null or not _arena().teams.has(me):
		print("[TT] клиент %d: команды ещё не назначены" % me)
		return
	var my_team := int(_arena().teams[me])
	var north_team := int(a._north_team())
	var pos: Vector3 = a.players[me].global_position
	var side_ok := (pos.z > 0.0) == (my_team == north_team)
	if side_ok:
		print("[TT] OK   клиент %d: команда %s, спавн z=%.1f (север=%s)" % [me, _arena().team_name(my_team), pos.z, _arena().team_name(north_team)])
	else:
		fails += 1
		print("[TT] ФЕЙЛ клиент %d: команда %s, но спавн z=%.1f" % [me, _arena().team_name(my_team), pos.z])
	# Раунд 2: тот же игрок должен оказаться на другом берегу.
	var before_north := pos.z > 0.0
	for attempt in 60:
		await _wait(0.5)
		if a != null and a.get("round_no") != null and int(a.round_no) >= 2 and bool(a._round_live):
			break
	await _wait(0.4)
	if a == null or not a.players.has(me):
		print("[TT] клиент %d: арена закрылась до смены сторон" % me)
		return
	var pos2: Vector3 = a.players[me].global_position
	if (pos2.z > 0.0) != before_north:
		print("[TT] OK   клиент %d: после смены сторон оказался на другом берегу (z=%.1f)" % [me, pos2.z])
	else:
		fails += 1
		print("[TT] ФЕЙЛ клиент %d: берег не сменился (z=%.1f)" % [me, pos2.z])
	# HUD: бейдж своей команды и командный счёт должны быть заполнены.
	var hud := a.get_node_or_null("HUD")
	if hud != null:
		var badge: String = str(hud.team_badge.text)
		var teams_txt: String = str(hud.team_label.text)
		var round_txt: String = str(hud.round_label.text)
		if badge.contains("Вы —") and teams_txt.contains(":") and round_txt.contains("Раунд"):
			print("[TT] OK   клиент %d: HUD показывает «%s», «%s», «%s»" % [me, badge, teams_txt, round_txt])
		else:
			fails += 1
			print("[TT] ФЕЙЛ клиент %d: HUD пуст (бейдж=«%s», счёт=«%s», раунд=«%s»)" % [me, badge, teams_txt, round_txt])
	else:
		fails += 1
		print("[TT] ФЕЙЛ клиент %d: HUD не найден" % me)

	if fails == 0:
		print("[TEAMTEST_CLIENT_OK] клиент %d: берега и смена сторон видны верно" % me)
	else:
		print("[TEAMTEST_CLIENT_FAIL] клиент %d: провалов %d" % [me, fails])
