extends Node
## BUILD-33: проверка выбора режима — ровно тем путём, которым это делает игрок:
## переключаем пункт в меню, жмём кнопку режима в лобби и смотрим флаги игры.
## Главная задача — чтобы «Оборона» включалась мышью, а не только ключом -- defense.

var _checks := 0
var _fails := 0


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[MODETEST] OK   %s" % label)
	else:
		_fails += 1
		print("[MODETEST] ФЕЙЛ %s" % label)


func _ready() -> void:
	await get_tree().process_frame

	# 1) Меню: два режима, по умолчанию — PvP 2 x 2.
	Game.set_play_mode(false)
	var menu: Control = load("res://scenes/ui/menu.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	var sel: OptionButton = menu.get_node("Layout/VBox/ModeSelect")
	var hint: Label = menu.get_node("Layout/VBox/ModeHint")
	_ok(sel.item_count == 2, "в меню два режима (PvP 2 x 2 и Оборона)")
	_ok(sel.selected == 0 and not Game.is_defense(), "по умолчанию выбран PvP 2 x 2")

	# 2) Выбираем оборону — так же, как это делает мышь в настоящем меню.
	sel.select(1)
	sel.item_selected.emit(1)
	await get_tree().process_frame
	_ok(Game.is_defense(), "пункт «Оборона» включает режим обороны")
	_ok(Game.team_mode, "в обороне команды включены (по своим огня нет)")
	_ok(Game.play_mode_name().contains("Оборона"), "название режима — «Оборона»")
	_ok(hint.text.contains("мины") and hint.text.contains("G"), "меню объясняет мины (клавиша G)")

	# 3) Обратно в PvP.
	sel.select(0)
	sel.item_selected.emit(0)
	await get_tree().process_frame
	_ok(not Game.is_defense(), "возврат в PvP выключает оборону")

	# 4) Лобби: подсказка о правилах и кнопка режима (её видит только хост).
	var lobby: Control = load("res://scenes/ui/lobby.tscn").instantiate()
	add_child(lobby)
	await get_tree().process_frame
	var mbtn: Button = lobby.get_node("Layout/VBox/HostRow/ModeBtn")
	var lhint: Label = lobby.get_node("Layout/VBox/PlayerList/ModeHint")
	_ok(mbtn.text.contains("PvP"), "кнопка режима в лобби показывает PvP")
	mbtn.pressed.emit()
	await get_tree().process_frame
	_ok(not Game.is_defense(), "без сети кнопка режима ничего не переключает (нужен хост)")

	# 5) Хост переключил режим — лобби сразу объясняет новые правила.
	var host_ok := NetworkManager.is_host
	Game.set_play_mode(true)
	await get_tree().process_frame
	_ok(lhint.text.contains("Оборона") and lhint.text.contains("периметр"), "лобби объясняет правила обороны")
	_ok(mbtn.text.contains("Оборона"), "кнопка режима показывает «Оборона»")
	Game.set_play_mode(false)
	await get_tree().process_frame
	_ok(mbtn.text.contains("PvP"), "переключение обратно возвращает PvP")

	# 6) Путь игрока целиком: выбрал «Оборона» в меню -> нажал «Хост (LAN)» ->
	# флаги режима должны дожить до старта матча (арена читает их при загрузке).
	sel.select(1)
	sel.item_selected.emit(1)
	await get_tree().process_frame
	NetworkManager.host_lan()
	await get_tree().create_timer(0.5).timeout
	_ok(Game.mode == Game.Mode.LAN, "хост LAN поднялся из меню")
	_ok(Game.is_defense(), "выбранная в меню «Оборона» дожила до хоста")
	_ok(Game.team_mode, "команды включены и в лобби обороны")
	NetworkManager.shutdown()
	await get_tree().create_timer(0.3).timeout
	_ok(Game.is_defense(), "режим не сбрасывается при выходе из лобби")
	_ok(not host_ok, "в проверке нет сети — режим переключаем функциями игры (как это делает хост)")

	print("[MODETEST] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0:
		print("[MODETEST_OK] выбор режима в меню и лобби работает")
	else:
		print("[MODETEST_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	await get_tree().create_timer(1.0).timeout
	get_tree().quit()
