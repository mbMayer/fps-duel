extends Node
## BUILD-36: руки от первого лица при резком развороте камеры.
##
## Руки — часть вида от первого лица: кисти висят на оружии, которое идёт за
## камерой мгновенно, а плечи раньше считались в системе ТОРСА. Торс же
## доворачивается со скоростью TORSO_TURN_SPEED (7 рад/с) и зажат запасом
## TORSO_TWIST_MAX (0.7 рад) — на флиске плечи отставали и руки
## «проворачивались» вокруг корпуса, догоняя камеру ещё полсекунды после того,
## как мышь остановилась.
##
## Что меряем (все — в СИСТЕМЕ КАМЕРЫ, поэтому честное вращение всего вида
## не считается движением):
##  1) отставание плечевого пояса от камеры на развороте 180° за 9 кадров
##     (20°/кадр = 1200°/с — резкий флиск);
##  2) остаточный доворот рук ПОСЛЕ остановки камеры;
##  3) рывки локтя относительно корпуса (телепорты ИК и «выталкивания» локтя
##     из капсулы тела видны как скачки в системе камеры);
##  4) то же при медленном развороте и при развороте с наклоном головы вниз.

const FPS := 60.0
const STEP := 1.0 / FPS
const FLICK_PER_FRAME := 0.35   # 20° за кадр
const FLICK_FRAMES := 9         # 180° всего
const SETTLE_FRAMES := 40       # 0.66 с после остановки камеры
const SLOW_PER_FRAME := 0.087   # 5° за кадр — спокойный разворот
# BUILD-37: пределы СКРУТКИ сегментов руки (то, что видно как «руку выкручивает»).
const TWIST_RATE_MAX := 0.10    # рад/кадр (5.7°) — своя скрутка поверх поворота тела
const TWIST_PLANE_MAX := 0.12   # рад (6.9°) — уход бока коробки от плоскости сгиба
const ELBOW_TWIST_MAX := 0.09   # рад (5.2°) — взаимный перекрут плеча и предплечья
const WRIST_TWIST_T := 1.22     # рад (70°) — скрутка кисть↔предплечье (в игре предел 60°)
const BASIS_JUMP_MAX := 0.13    # рад/кадр (7.4°) — предел разгона скрутки

var _checks := 0
var _fails := 0


func _ok(cond: bool, label: String) -> void:
	_checks += 1
	if cond:
		print("[ARMTEST] OK   %s" % label)
	else:
		_fails += 1
		print("[ARMTEST] ФЕЙЛ %s" % label)


func _ready() -> void:
	await get_tree().process_frame
	var p: Node3D = load("res://scenes/game/player.tscn").instantiate()
	p.name = "1"
	add_child(p)
	await get_tree().process_frame
	await get_tree().process_frame
	if p._fp_arm_nodes.size() < 2:
		print("[ARMTEST_FAIL] руки не построены")
		get_tree().quit(1)
		return
	await _run_flick(p)
	await _run_slow(p)
	await _run_pitch(p)
	await _run_twist(p)
	print("[ARMTEST] итог: проверок=%d, провалов=%d" % [_checks, _fails])
	if _fails == 0:
		print("[ARMTEST_OK] руки идут за камерой без проворота и рывков локтя")
	else:
		print("[ARMTEST_FAIL] проверок=%d, провалов=%d" % [_checks, _fails])
	get_tree().quit(0 if _fails == 0 else 1)


# ---------------------------------------------------------------- прогоны

func _run_flick(p: Node3D) -> void:
	_step(p, 0.0, 0.0)
	var lag0 := _raw_lag(p)
	var max_lag := 0.0
	var max_elbow_move := 0.0
	var max_reach := 0.0
	var prev_elbow := _elbow_local(p)
	for i in FLICK_FRAMES:
		_step(p, FLICK_PER_FRAME, 0.0)
		max_lag = maxf(max_lag, absf(wrapf(_raw_lag(p) - lag0, -PI, PI)))
		var e := _elbow_local(p)
		max_elbow_move = maxf(max_elbow_move, e.distance_to(prev_elbow))
		prev_elbow = e
		max_reach = maxf(max_reach, _elbow_radius(p))
	print("[ARMTEST] флиск 180° за 0.15 с: отставание плеч до %.1f°, локоть сместился до %.3f м/кадр, вынос локтя до %.2f м" % [
		rad_to_deg(max_lag), max_elbow_move, max_reach])
	var drift := 0.0
	var prev := _elbow_local(p)
	for i in SETTLE_FRAMES:
		_step(p, 0.0, 0.0)
		var e := _elbow_local(p)
		max_elbow_move = maxf(max_elbow_move, e.distance_to(prev))
		drift = maxf(drift, e.distance_to(prev))
		prev = e
	_ok(max_lag < 0.10, "плечи идут за камерой на флиске (отставание %.1f°, порог 5.7°)" % rad_to_deg(max_lag))
	_ok(drift < 0.02, "после остановки камеры руки замерли (доворот %.3f м, порог 0.02 м)" % drift)
	_ok(max_elbow_move < 0.05, "локоть не телепортирует (макс. %.3f м за кадр, порог 0.05 м)" % max_elbow_move)


func _run_slow(p: Node3D) -> void:
	var lag0 := _raw_lag(p)
	var max_lag := 0.0
	var max_elbow_move := 0.0
	var prev := _elbow_local(p)
	for i in 20:
		_step(p, SLOW_PER_FRAME, 0.0)
		max_lag = maxf(max_lag, absf(wrapf(_raw_lag(p) - lag0, -PI, PI)))
		var e := _elbow_local(p)
		max_elbow_move = maxf(max_elbow_move, e.distance_to(prev))
		prev = e
	print("[ARMTEST] спокойный разворот 5°/кадр: отставание плеч до %.1f°, локоть до %.3f м/кадр" % [
		rad_to_deg(max_lag), max_elbow_move])
	_ok(max_lag < 0.06, "на спокойном развороте плечи тоже без отставания (%.1f°)" % rad_to_deg(max_lag))
	_ok(max_elbow_move < 0.03, "на спокойном развороте локоть идёт плавно (%.3f м/кадр)" % max_elbow_move)


func _run_pitch(p: Node3D) -> void:
	# Разворот вместе с наклоном головы вниз: раньше тут локти «выдёргивались»
	# из капсулы тела. Мерим рывки локтя в системе камеры.
	var max_elbow_move := 0.0
	var prev := _elbow_local(p)
	for i in 24:
		_step(p, 0.10, -0.030)   # ~1.7° вниз за кадр: наклон до -0.72 рад
		var e := _elbow_local(p)
		max_elbow_move = maxf(max_elbow_move, e.distance_to(prev))
		prev = e
	print("[ARMTEST] разворот с наклоном вниз: локоть до %.3f м/кадр" % max_elbow_move)
	_ok(max_elbow_move < 0.05, "при взгляде вниз на развороте локоть не дёргается (%.3f м/кадр)" % max_elbow_move)


## BUILD-37: скрутка рук. Бок коробки сегмента (его «крен» вокруг оси руки)
## раньше задавал look_at(b, Vector3.UP): бок стоял на 87° мимо плоскости сгиба
## локтя, а у почти вертикальных направлений ориентация скачком переключалась на
## Vector3.FORWARD (порог |dot|>0.98). Снаружи это и читается как «руку выкручивает
## в плече и локте», особенно когда мышью крутишь быстро.
## Мерим (все углы — в СИСТЕМЕ ТЕЛА, поэтому честный разворот вида не считается):
##  1) взаимный перекрут плеча и предплечья на стыке (локоть) — рука должна
##     лежать в одной системе, а не «винтом»;
##  2) скрутку кисти относительно предплечья (кисть жёстко на оружии);
##  3) свою скрутку сегмента поверх поворота тела и инерцию ПОСЛЕ остановки камеры;
##  4) рывки ориентации — раньше на почти вертикальных направлениях коробка
##     скачком переключалась на Vector3.FORWARD (порог |dot| > 0.98).
func _run_twist(p: Node3D) -> void:
	_step(p, 0.0, 0.0)
	var elbow_rel := 0.0          # взаимный перекрут плеча и предплечья (локоть)
	var wrist := 0.0              # скрутка кисти относительно предплечья
	var rate := 0.0               # своя скрутка (крен коробки) поверх поворота тела
	var jump := 0.0               # максимальная скрутка за кадр (в системе тела)
	var prev_up := _seg_up_body(p, 0, "fore")
	for i in FLICK_FRAMES:
		_step(p, FLICK_PER_FRAME, 0.0)
		var u := _seg_up_body(p, 0, "fore")
		if u != Vector3.ZERO and prev_up != Vector3.ZERO:
			rate = maxf(rate, u.angle_to(prev_up))
			jump = maxf(jump, rate)
		prev_up = u
		elbow_rel = maxf(elbow_rel, _elbow_twist(p, 0))
		wrist = maxf(wrist, _wrist_twist(p, 0))
	# После остановки камеры руки не должны доскручиваться сами.
	var settle := 0.0
	var settle_prev := _seg_up_body(p, 0, "fore")
	for i in SETTLE_FRAMES:
		_step(p, 0.0, 0.0)
		var u := _seg_up_body(p, 0, "fore")
		if u != Vector3.ZERO and settle_prev != Vector3.ZERO:
			settle = maxf(settle, u.angle_to(settle_prev))
		settle_prev = u
	var elbow_settled := _elbow_twist(p, 0)
	var wrist_settled := _wrist_twist(p, 0)
	# Разворот с наклоном вниз: тут раньше срабатывал порог |dot|>0.98 и коробка
	# переключалась на FORWARD — скачок ориентации виден как рывок.
	prev_up = _seg_up_body(p, 0, "upper")
	for i in 40:
		_step(p, 0.10, -0.030)
		var u := _seg_up_body(p, 0, "upper")
		if u != Vector3.ZERO and prev_up != Vector3.ZERO:
			jump = maxf(jump, u.angle_to(prev_up))
		prev_up = u
		elbow_rel = maxf(elbow_rel, _elbow_twist(p, 0))
		wrist = maxf(wrist, _wrist_twist(p, 0))
	print("[ARMTEST] скрутка: перекрут локтя до %.1f° (после остановки %.1f°), кисть до %.1f° (после %.1f°), своя скрутка %.1f°/кадр, рывок %.1f°/кадр, инерция после остановки %.1f°/кадр" % [
		rad_to_deg(elbow_rel), rad_to_deg(elbow_settled), rad_to_deg(wrist), rad_to_deg(wrist_settled),
		rad_to_deg(rate), rad_to_deg(jump), rad_to_deg(settle)])
	_ok(elbow_rel < ELBOW_TWIST_MAX, "в локте нет взаимного перекрута (до %.1f°, порог %.1f°)" % [
		rad_to_deg(elbow_rel), rad_to_deg(ELBOW_TWIST_MAX)])
	_ok(elbow_settled < ELBOW_TWIST_MAX, "локоть не доскручивается после остановки камеры (%.1f°)" % rad_to_deg(elbow_settled))
	_ok(wrist < WRIST_TWIST_T, "кисть не выкручивает руку (до %.1f°, порог %.1f°)" % [
		rad_to_deg(wrist), rad_to_deg(WRIST_TWIST_T)])
	_ok(rate < TWIST_RATE_MAX, "скрутка идёт вместе с рукой (%.1f°/кадр, порог %.1f°)" % [
		rad_to_deg(rate), rad_to_deg(TWIST_RATE_MAX)])
	_ok(settle < TWIST_RATE_MAX, "после остановки камеры рука замерла (%.1f°/кадр)" % rad_to_deg(settle))
	_ok(jump < BASIS_JUMP_MAX, "на развороте с наклоном скрутка не разгоняется (%.1f°/кадр, порог %.1f°)" % [
		rad_to_deg(jump), rad_to_deg(BASIS_JUMP_MAX)])


# ---------------------------------------------------------------- движок замера

func _step(p: Node3D, yaw_delta: float, pitch_delta: float) -> void:
	p.rotation.y += yaw_delta
	p.head.rotation.x = clampf(p.head.rotation.x + pitch_delta, -1.45, 1.45)
	# Ровно тот конвейер, что и в игре: поза тела -> оружие -> руки.
	p._update_body_pose(STEP, false, Vector3.ZERO, false, true, 0.0, 0.0, 0.0)
	p._update_fp_arms()


## Позиция в системе КАМЕРЫ (рыск игрока): честное вращение вида не считается
## смещением, а телепорты локтя — считаются.
func _to_view(p: Node3D, world: Vector3) -> Vector3:
	return Basis(Vector3.UP, -p.rotation.y) * (world - p.global_position)


func _elbow_local(p: Node3D) -> Vector3:
	return _to_view(p, _elbow(p, 0))


## «Сырое» отставание плечевого пояса от камеры (со сдвигом константы — им
## пользуемся только в разностях).
func _raw_lag(p: Node3D) -> float:
	var line := _shoulder(p, 0) - _shoulder(p, 1)
	if line.length() < 0.001:
		return 0.0
	var frame_yaw := atan2(line.x, line.z)
	return wrapf(frame_yaw - (p.rotation.y + PI * 0.5), -PI, PI)


## Насколько локоть вынесен от оси корпуса в плане.
func _elbow_radius(p: Node3D) -> float:
	var rel := _elbow(p, 0) - p.global_position
	return Vector2(rel.x, rel.z).length()


func _elbow(p: Node3D, arm_idx: int) -> Vector3:
	var u: MeshInstance3D = p._fp_arm_nodes[arm_idx]["upper"]
	var z: float = (u.mesh as BoxMesh).size.z
	return u.global_position - u.global_transform.basis.z * (z * 0.5)


## Ось сегмента (плечо->локоть или локоть->запястье) в мировых координатах.
func _seg_axis(p: Node3D, arm_idx: int, which: String) -> Vector3:
	var s: MeshInstance3D = p._fp_arm_nodes[arm_idx][which]
	return -s.global_transform.basis.z


## Бок коробки, приведённый к плоскости, перпендикулярной оси сегмента:
## именно он «крутится» вокруг руки и виден как выкручивание.
func _seg_up(p: Node3D, arm_idx: int, which: String) -> Vector3:
	var s: MeshInstance3D = p._fp_arm_nodes[arm_idx][which]
	var d := _seg_axis(p, arm_idx, which)
	var y := s.global_transform.basis.y
	y -= d * d.dot(y)
	if y.length_squared() < 1e-6:
		return Vector3.ZERO
	return y.normalized()


func _seg_basis(p: Node3D, arm_idx: int, which: String) -> Basis:
	var s: MeshInstance3D = p._fp_arm_nodes[arm_idx][which]
	return s.global_transform.basis


## Крен сегмента (бок коробки) в СИСТЕМЕ ТЕЛА: поворот на -рыск снимает честный
## разворот вида, остаётся только собственная скрутка руки.
func _seg_up_body(p: Node3D, arm_idx: int, which: String) -> Vector3:
	var u := _seg_up(p, arm_idx, which)
	if u == Vector3.ZERO:
		return Vector3.ZERO
	return Basis(Vector3.UP, -p.rotation.y) * u


## Базис сегмента в СИСТЕМЕ ТЕЛА (поворот на -рыск игрока): честный разворот
## вида не считается скруткой, а вот доворот коробки вокруг своей оси — считается.
func _body_basis(p: Node3D, arm_idx: int, which: String) -> Basis:
	return Basis(Vector3.UP, -p.rotation.y) * _seg_basis(p, arm_idx, which)


## Взаимный перекрут плеча и предплечья на стыке (локоть): угол между их «верхом»
## вокруг оси предплечья. У шарнира он должен быть почти нулевым.
func _elbow_twist(p: Node3D, arm_idx: int) -> float:
	var d := _seg_axis(p, arm_idx, "fore")
	var up := _seg_up(p, arm_idx, "upper")
	var fore := _seg_up(p, arm_idx, "fore")
	if up == Vector3.ZERO or fore == Vector3.ZERO:
		return 0.0
	var u := up - d * d.dot(up)
	if u.length_squared() < 1e-6:
		return 0.0
	return fore.angle_to(u.normalized())


## Скрутка кисть↔предплечье: кисть жёстко на оружии, предплечье — коробка.
## Угол между их «верхом» вокруг оси предплечья.
func _wrist_twist(p: Node3D, arm_idx: int) -> float:
	var d := _seg_axis(p, arm_idx, "fore")
	var fore := _seg_up(p, arm_idx, "fore")
	var hand: MeshInstance3D = p._fp_arm_nodes[arm_idx]["hand"]
	var hu := hand.global_transform.basis.y
	hu -= d * d.dot(hu)
	if fore == Vector3.ZERO or hu.length_squared() < 1e-6:
		return 0.0
	return fore.angle_to(hu.normalized())


func _shoulder(p: Node3D, arm_idx: int) -> Vector3:
	var u: MeshInstance3D = p._fp_arm_nodes[arm_idx]["upper"]
	var z: float = (u.mesh as BoxMesh).size.z
	return u.global_position + u.global_transform.basis.z * (z * 0.5)
