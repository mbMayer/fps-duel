#!/usr/bin/env bash
# Восстановление инструментов, которые НЕ попадают в снапшот воркспейса
# (тяжёлые бинарники лежат в /tmp, в проекте — только симлинки).
# Запускать, если /home/user/tools/godot или Xvfb пропали:
#   bash tools/ensure_tools.sh
set -eu
VER=4.7.2-stable
GBIN=/tmp/godot-bin
XR=/tmp/xvfb-root
DEBS=/tmp/xvfb-debs

# --- Godot ---------------------------------------------------------------
if [ ! -x "$GBIN" ]; then
  echo "[tools] скачиваю Godot $VER (~78 МБ)"
  curl -sL -o /tmp/godot.zip "https://github.com/godotengine/godot/releases/download/$VER/Godot_v${VER}_linux.x86_64.zip"
  cd /tmp && unzip -o -q godot.zip && mv -f "Godot_v${VER}_linux.x86_64" "$GBIN" && chmod +x "$GBIN"
fi
ln -sfn "$GBIN" /home/user/tools/godot
"$GBIN" --version

# --- Xvfb (для кадров: headless-драйвер картинку не отдаёт) --------------
if [ ! -x "$XR/usr/bin/Xvfb" ]; then
  echo "[tools] ставлю Xvfb в $XR"
  mkdir -p "$DEBS" "$XR" && cd "$DEBS"
  apt-get download xvfb xkb-data x11-xkb-utils libxfont2 libfontenc1 libunwind8 \
    libxkbfile1 libbsd0 libmd0 libxau6 libxdmcp6 libpixman-1-0 libselinux1 libpcre2-8-0 >/dev/null
  for d in *.deb; do dpkg-deb -x "$d" "$XR"; done
fi
ln -sfn "$XR" /home/user/tools/xvfb-root
bash /home/user/tools/setup_xvfb.sh

# --- дисплей :99 ---------------------------------------------------------
if [ ! -S /tmp/.X11-unix/X99 ]; then
  mkdir -p /tmp/.X11-unix
  nohup env LD_LIBRARY_PATH="$XR/usr/lib/x86_64-linux-gnu" /tmp/Xvfb-local :99 \
    -screen 0 1600x900x24 -nolisten tcp \
    -xkbdir /home/user/tools/xvfb-root/usr/share/X11/xkb >/tmp/xvfb.log 2>&1 &
  sleep 3
fi
[ -S /tmp/.X11-unix/X99 ] && echo "[tools] дисплей :99 готов, можно запускать run_shots.sh"
