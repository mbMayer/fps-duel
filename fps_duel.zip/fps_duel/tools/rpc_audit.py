#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Аудит RPC-аннотаций в проекте FPS DUEL.

Правило 1 (BUILD-35): у каждого метода, который где-то вызывается как
`.rpc(...)` или `.rpc_id(...)`, должна стоять аннотация `@rpc(...)`. Именно её
потеря ломала выстрел игрока и автотурель (ошибка «Unable to get the RPC
configuration for the function "_impact"»).

Правило 2 (BUILD-36): узел, чей скрипт объявляет `@rpc`, обязан получить имя
ДО `add_child`. RPC-пакет адресуется путём узла, поэтому автоимя
(`@Node3D@336`) у хоста и клиента не совпадает, и у товарища вылетает
«Node not found: Arena/@Node3D@336». Правило ловит это на этапе аудита.

Запуск: python3 tools/rpc_audit.py [папка проекта]   (из корня проекта)
Код возврата: 0 — всё в порядке, 1 — есть нарушения.
"""
import re
import sys
from pathlib import Path

CALL_RE = re.compile(r"\.(rpc|rpc_id)\s*\(")
# строковая форма: node.rpc_id(peer, "method", ...)
STR_CALL_RE = re.compile(r"\.rpc_id\s*\(\s*[^,]+,\s*\"([A-Za-z_][A-Za-z0-9_]*)\"")
FUNC_RE = re.compile(r"^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(")


def collect_rpc_methods(root: Path):
    """Все методы проекта, у которых стоит @rpc: имя -> файл."""
    marked = {}
    for path in sorted(root.rglob("*.gd")):
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for i, line in enumerate(lines):
            if line.lstrip().startswith("@rpc("):
                for j in range(i + 1, min(i + 4, len(lines))):
                    m = FUNC_RE.match(lines[j])
                    if m:
                        marked.setdefault(m.group(1), path)
                        break
    return marked


SCENE_SCRIPT_RE = re.compile(r'path="(res://[^"]+\.gd)"')
CONST_SCENE_RE = re.compile(r'^const\s+([A-Z_][A-Z0-9_]*)\s*:=\s*"(res://[^"]+\.tscn)"')
INSTANTIATE_RE = re.compile(r"var\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*[A-Za-z_][A-Za-z0-9_]*)?\s*=\s*(.*\.instantiate\(\))")


ROOT_NODE_RE = re.compile(r'^\[node\s+name="([^"]*)"', re.MULTILINE)


def audit_scene_names(root: Path):
    """Правило 2: у корня каждой сцены есть настоящее имя.

    Узел без имени получает автоимя (`@Node3D@336`), которое у хоста и клиента
    не совпадает: RPC-пакет адресуется путём узла, и у товарища вылетает
    «Node not found: Arena/@Node3D@336».
    """
    problems = []
    checked = 0
    for scn in sorted(root.rglob("*.tscn")):
        m = ROOT_NODE_RE.search(scn.read_text(encoding="utf-8", errors="ignore"))
        if not m:
            continue
        checked += 1
        name = m.group(1)
        if name == "" or name.startswith("@"):
            problems.append(
                f"{scn.relative_to(root)}: корень сцены без имени — узел получит "
                f"автоимя и RPC-пакеты к нему не найдут цель"
            )
    print(f"[RPC-AUDIT] сцен проверено: {checked}")
    return problems


def audit_name_before_add(root: Path):
    """Правило 3: если динамическому узлу задают имя, то ДО add_child.

    Имя, выставленное после добавления в дерево, не спасает: узел уже получил
    автоимя, а с ним — другой путь для RPC.
    """
    problems = []
    checked = 0
    for path in sorted(root.rglob("*.gd")):
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for i, line in enumerate(lines):
            m = re.match(r"\s*var\s+([A-Za-z_][A-Za-z0-9_]*)\b.*\.instantiate\(\)", line)
            if not m:
                continue
            var = m.group(1)
            added = named = None
            for j in range(i, min(i + 20, len(lines))):
                if added is None and re.search(rf"add_child\(\s*{var}\b", lines[j]):
                    added = j
                if named is None and re.search(rf"\b{var}\.name\s*=", lines[j]):
                    named = j
                if added is not None and named is not None:
                    break
            if added is None or named is None:
                continue
            checked += 1
            if named > added:
                problems.append(
                    f"{path.relative_to(root)}:{i + 1}: имя {var}.name задано после "
                    f"add_child — узел успеет получить автоимя"
                )
    print(f"[RPC-AUDIT] присвоений имён до add_child проверено: {checked}")
    return problems


def audit(root: Path) -> int:
    problems = []
    checked = 0
    marked = collect_rpc_methods(root)
    for path in sorted(root.rglob("*.gd")):
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        local = {m.group(1) for line in lines if (m := FUNC_RE.match(line))}
        called = set()
        for line in lines:
            # node.rpc_id(peer, "method", ...) — метод берём из строки, а не из
            # имени перед точкой (там стоит имя узла-владельца).
            str_calls = list(STR_CALL_RE.finditer(line))
            for m in str_calls:
                called.add(m.group(1))
            if str_calls:
                continue
            for m in CALL_RE.finditer(line):
                head = line[: m.start()].rstrip()
                name = re.split(r"[^A-Za-z0-9_]", head)[-1] if head else ""
                if name:
                    called.add(name)
        for name in sorted(called):
            checked += 1
            if name in local:
                # метод своего файла: аннотация должна быть в этом же файле
                if name not in marked:
                    problems.append(f"{path.relative_to(root)}: {name}.rpc(...) — нет @rpc")
            elif name not in marked:
                problems.append(f"{path.relative_to(root)}: {name}.rpc(...) — метод с @rpc не найден ни в одном файле")
    problems += audit_scene_names(root)
    problems += audit_name_before_add(root)
    print(f"[RPC-AUDIT] проверено вызовов: {checked}")
    if problems:
        for p in problems:
            print("[RPC-AUDIT_FAIL]", p)
        return 1
    print("[RPC-AUDIT_OK] у всех .rpc(...)/.rpc_id(...) есть аннотация @rpc")
    return 0


if __name__ == "__main__":
    # По умолчанию проверяем проект в текущей папке: запускать из корня проекта.
    sys.exit(audit(Path(sys.argv[1] if len(sys.argv) > 1 else ".")))
