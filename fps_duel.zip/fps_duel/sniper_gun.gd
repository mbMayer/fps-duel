extends Node3D
## BUILD-33: текстура материала Vertex берётся из файла проекта напрямую.
##
## Почему так: `SNIPER-VERTEX-TEST_Untitled-1.png` — обычная картинка, которую
## Godot импортирует только в редакторе (или при `--import`). Если запускать игру
## без редактора и без папки `.godot`, импорта нет, и материал со ссылкой на
## текстуру в файле ресурса не загружается — модель снайперки подменялась
## заглушкой, а в консоль сыпались Parse Error. Теперь материал собирается в
## рантайме: читаем PNG сами. Если файла нет (экспорт) — остаются vertex-цвета.

const TEX_PATH := "res://SNIPER-VERTEX-TEST_Untitled-1.png"

var _img: Image = null


func _ready() -> void:
	_apply_texture(self)


func _apply_texture(n: Node) -> void:
	var mi := n as MeshInstance3D
	if mi != null and mi.mesh != null:
		for s in mi.mesh.get_surface_count():
			var mat := mi.get_active_material(s)
			if mat is StandardMaterial3D and mat.albedo_texture == null:
				if _img == null:
					_img = Image.load_from_file(TEX_PATH)
				if _img != null:
					mat.albedo_texture = ImageTexture.create_from_image(_img)
	for c in n.get_children():
		_apply_texture(c)


## Для автотеста: сколько поверхностей получили текстуру.
func textured_surfaces() -> int:
	var n := 0
	for node in find_children("*", "MeshInstance3D", true, false):
		var mi := node as MeshInstance3D
		if mi == null or mi.mesh == null:
			continue
		for s in mi.mesh.get_surface_count():
			var mat := mi.get_active_material(s)
			if mat is StandardMaterial3D and mat.albedo_texture != null:
				n += 1
	return n
