extends Control

@onready var status_label: Label = $Layout/VBox/StatusLabel
@onready var steam_status: Label = $Layout/VBox/SteamStatus
@onready var lobby_id_edit: LineEdit = $Layout/VBox/JoinRow/LobbyIdEdit
@onready var lan_ip_edit: LineEdit = $Layout/VBox/LanRow/LanIpEdit
@onready var create_btn: Button = $Layout/VBox/CreateLobbyBtn
@onready var quick_btn: Button = $Layout/VBox/QuickMatchBtn
@onready var join_btn: Button = $Layout/VBox/JoinRow/JoinByIdBtn
## BUILD-34: игра только кооп — говорим об этом прямо на входе.
@onready var mode_hint: Label = $Layout/VBox/ModeHint


func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	# BUILD-34: игра только кооперативная — коротко объясняем правила на входе.
	mode_hint.text = ("Кооп-оборона: до четырёх игроков держат два берега ущелья. "
		+ "Из ущелья лезут Полые люди; помогают автотурели у кромки. "
		+ "Раненого поднимает товарищ — клавиша E.")
	SteamManager.status_changed.connect(_set_status)
	NetworkManager.status_changed.connect(_set_status)
	if SteamManager.available and SteamManager.initialized:
		steam_status.text = "Steam: %s (ID %d)" % [SteamManager.persona_name, SteamManager.steam_id]
		steam_status.modulate = Color(0.5, 0.9, 0.5)
	elif SteamManager.available:
		steam_status.text = "Адон установлен, но клиент не инициализирован: запускайте экспортированную сборку через Steam. Пока доступен LAN."
		steam_status.modulate = Color(0.9, 0.7, 0.4)
		_disable_steam_buttons()
	else:
		steam_status.text = "Адон GodotSteam не установлен: доступен только LAN. Установка — см. addons/README_INSTALL.txt"
		steam_status.modulate = Color(0.9, 0.5, 0.4)
		_disable_steam_buttons()


func _disable_steam_buttons() -> void:
	create_btn.disabled = true
	quick_btn.disabled = true
	join_btn.disabled = true


func _set_status(text: String) -> void:
	if text != "":
		status_label.text = text


func _on_create_lobby_pressed() -> void:
	SteamManager.host_lobby()


func _on_quick_match_pressed() -> void:
	SteamManager.quick_match()


func _on_join_by_id_pressed() -> void:
	var text := lobby_id_edit.text.strip_edges()
	if text.is_valid_int():
		SteamManager.join_lobby(text.to_int())
	else:
		_set_status("Введите числовой код лобби")


func _on_lan_host_pressed() -> void:
	NetworkManager.host_lan()


func _on_lan_join_pressed() -> void:
	NetworkManager.join_lan(lan_ip_edit.text)


func _on_quit_pressed() -> void:
	get_tree().quit()
