extends CanvasLayer

## Отдельно — ранение: «лежишь и ждёшь товарища» с клавишей E.

var _local_player: Node = null
var _bleedout_left := 0.0
var _downed := false
var _match_ended := false

@onready var health_bar: ProgressBar = $HealthBar
@onready var health_label: Label = $HealthLabel
@onready var score_label: Label = $ScoreLabel
@onready var hit_marker: Label = $HitMarker
@onready var damage_flash: ColorRect = $DamageFlash
@onready var respawn_label: Label = $RespawnLabel
@onready var died_overlay: ColorRect = $DiedOverlay
@onready var match_over_overlay: ColorRect = $MatchOverOverlay
@onready var winner_label: Label = $MatchOverOverlay/Box/WinnerLabel
@onready var weapon_label: Label = $WeaponLabel
@onready var turret_hint: Label = $TurretHint
@onready var announce_label: Label = $AnnounceLabel
# BUILD-34: кооп-отряд и подъём товарища.
@onready var squad_label: Label = $SquadLabel
@onready var wounded_label: Label = $DiedOverlay/WoundedLabel
@onready var revive_hint: Label = $ReviveHint
@onready var revive_bar: ProgressBar = $ReviveBar
# BUILD-33: кооп-оборона.
@onready var defense_label: Label = $DefenseLabel
@onready var hollow_warn: Label = $HollowWarn

const Map := preload("res://scenes/game/gorge.gd")
var _announce_left := 0.0
var _fog_shown := 0.0
var _squad: Array = []


func _ready() -> void:
	Game.health_changed.connect(_on_health)
	Game.scores_changed.connect(_on_scores)
	Game.got_hit.connect(_on_got_hit)
	Game.dealt_hit.connect(_on_dealt_hit)
	Game.died.connect(_on_died)
	Game.match_over.connect(_on_match_over)
	Game.player_spawned_local.connect(_on_local_spawned)
	Game.weapon_changed.connect(_on_weapon)
	Game.announce.connect(_on_announce)
	Game.defense_changed.connect(_on_defense_changed)
	# BUILD-34: отряд, ранение, подъём.
	Game.squad_changed.connect(_on_squad)
	Game.downed.connect(_on_downed)
	Game.revived.connect(_on_revived)
	Game.respawned.connect(_on_revived)
	Game.revive_progress.connect(_on_revive_progress)
	defense_label.visible = false
	revive_hint.visible = false
	revive_bar.visible = false
	wounded_label.text = ""
	hit_marker.modulate.a = 0.0
	weapon_label.text = Game.weapon_label(1)  # старт с пистолетом


func _on_weapon(label: String) -> void:
	weapon_label.text = label


func _process(delta: float) -> void:
	if _local_player == null:
		_find_local_player()
	if _downed and _bleedout_left > 0.0:
		_bleedout_left = maxf(_bleedout_left - delta, 0.0)
		wounded_label.text = "Вы ранены! Товарищ поднимет клавишей E · сам вернёшься через %d с" % ceili(_bleedout_left)
		respawn_label.text = "Ждём подъёма: %d с" % ceili(_bleedout_left)
		respawn_label.visible = true
	# BUILD-30: подсказка про турель (рядом — «сесть», в ней — «выйти»).
	_update_turret_hint()
	_update_revive_hint()
	if _announce_left > 0.0:
		_announce_left = maxf(_announce_left - delta, 0.0)
		announce_label.modulate.a = clampf(_announce_left / 1.2, 0.0, 1.0)
	_update_hollow_warn(delta)


func _find_local_player() -> void:
	var root := get_tree().current_scene
	if root == null:
		return
	var players := root.get_node_or_null("Players")
	if players == null:
		return
	_local_player = players.get_node_or_null(str(multiplayer.get_unique_id()))
	if _local_player != null:
		_on_health(_local_player.health)


func _on_local_spawned(p: Node) -> void:
	_local_player = p
	_on_health(p.health)


## BUILD-30: подсказка у турели. Видна, когда рядом свободная турель (и ты
## не сидишь) — «F — сесть в турель», или когда ты сидишь — «F — выйти из
## турели». Берём список тurrets с арены (текущей сцены).
func _on_announce(text: String) -> void:
	announce_label.text = text
	announce_label.modulate.a = 1.0
	_announce_left = 3.5


# ---------------------------------------------------------------- оборона (BUILD-33)

func _on_defense_changed(wave: int, waves_total: int, alive: int, kills: int, perimeter: float) -> void:
	defense_label.visible = true
	defense_label.text = "Волна %d/%d · полых на берегу: %d · уничтожено: %d · периметр: %d %%" % [
		maxi(wave, 1), waves_total, alive, kills, int(perimeter)]
	var col := Color(0.75, 0.95, 0.75)
	if perimeter < 60.0:
		col = Color(1.0, 0.75, 0.5)
	if perimeter < 30.0:
		col = Color(1.0, 0.5, 0.45)
	defense_label.add_theme_color_override("font_color", col)


func _update_turret_hint() -> void:
	if _local_player == null or _local_player.dead:
		turret_hint.visible = false
		return
	if _local_player.mounted_idx >= 0:
		turret_hint.text = "F — выйти из турели"
		turret_hint.visible = true
		return
	var root := get_tree().current_scene
	if root == null or not root.has_method("get_player_by_id"):
		turret_hint.visible = false
		return
	var arr: Array = root.turrets
	var range_m: float = float(root.MOUNT_RANGE)
	var nearest := 9999.0
	for t in arr:
		if t.is_occupied():
			continue
		var d: float = t.position.distance_to(_local_player.global_position)
		if d < nearest:
			nearest = d
	if nearest <= range_m:
		turret_hint.text = "F — сесть в турель"
		turret_hint.visible = true
	else:
		turret_hint.visible = false


## BUILD-33: предупреждение, когда «Полый человек» подошёл вплотную.
func _update_hollow_warn(delta: float) -> void:
	if _local_player == null or _local_player.dead or not Game.defense_mode:
		hollow_warn.modulate.a = 0.0
		return
	var near := false
	for h in get_tree().get_nodes_in_group("hollows"):
		var hn: Node3D = h
		if is_instance_valid(hn) and hn.global_position.distance_to(_local_player.global_position) < 7.0:
			near = true
			break
	if near:
		_fog_shown += delta
		hollow_warn.modulate.a = 0.8 + 0.2 * sin(_fog_shown * 7.0)
	else:
		hollow_warn.modulate.a = 0.0


func _on_health(value: float) -> void:
	health_bar.value = value
	health_label.text = "%d HP" % int(round(value))


func _on_scores(sc: Dictionary, my_id: int) -> void:
	# BUILD-34: таблицы игроков больше нет — показываем личный вклад в оборону.
	score_label.text = "Ваш вклад: уничтожено полых — %d" % int(sc.get(my_id, 0))


func _on_got_hit() -> void:
	damage_flash.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(damage_flash, "modulate:a", 0.0, 0.35)


func _on_dealt_hit() -> void:
	hit_marker.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(hit_marker, "modulate:a", 0.0, 0.2)


func _on_died(_killer: String) -> void:
	# Показываем оверлей; подпись и таймер появятся в _on_downed/тике.
	died_overlay.visible = true
	wounded_label.text = "Вы ранены! Ждём подъёма…"


func _on_downed(bleedout: float) -> void:
	_downed = true
	_bleedout_left = bleedout
	died_overlay.visible = true
	respawn_label.visible = true


func _on_revived() -> void:
	_downed = false
	_bleedout_left = 0.0
	died_overlay.visible = false
	wounded_label.text = ""
	respawn_label.visible = false
	revive_bar.visible = false


# ---------------------------------------------------------------- отряд и подъём (BUILD-34)

## Сводка отряда: кто где стоит, у кого сколько здоровья, кто ранен.
func _on_squad(members: Array) -> void:
	_squad = members
	if members.is_empty():
		squad_label.text = ""
		_refresh_squad_label()
		return
	_refresh_squad_label()


func _refresh_squad_label() -> void:
	var lines: Array[String] = []
	var my := multiplayer.get_unique_id()
	var downed_n := 0
	for m in _squad:
		var mark := " ← вы" if int(m.get("id", 0)) == my else ""
		var post := "Север" if int(m.get("side", 1)) > 0 else "Юг"
		var state := ""
		if bool(m.get("downed", false)):
			state = " · РАНЕН"
			downed_n += 1
		elif int(m.get("mounted", -1)) >= 0:
			state = " · в турели"
		lines.append("Игрок %d · %s · %d HP%s%s" % [int(m.get("num", 0)), post, int(m.get("hp", 0)), state, mark])
	squad_label.text = "\n".join(lines)
	if downed_n > 0:
		squad_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.6))
	else:
		squad_label.add_theme_color_override("font_color", Color(0.75, 0.9, 0.78))


## Подсказка «E — поднять товарища», когда рядом лежит раненый союзник.
func _update_revive_hint() -> void:
	if _downed or _local_player == null or _local_player.dead:
		revive_hint.visible = false
		return
	var arena := get_tree().current_scene
	if arena == null or not arena.has_method("nearest_downed_within"):
		revive_hint.visible = false
		return
	var target: Node = arena.nearest_downed_within(_local_player.global_position, Game.REVIVE_RANGE)
	if target == null:
		revive_hint.visible = false
		return
	revive_hint.text = "E (удерживать) — поднять %s" % arena.player_label(str(target.name).to_int())
	revive_hint.visible = true


func _on_revive_progress(value: float, label: String) -> void:
	if value <= 0.0:
		revive_bar.visible = false
		return
	revive_bar.visible = true
	revive_bar.value = value
	revive_hint.text = "Поднимаем %s… %d %%" % [label, int(value * 100.0)]


func _on_match_over(label: String) -> void:
	_match_ended = true
	winner_label.text = label
	match_over_overlay.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if _match_ended:
		return
	if event.is_action_pressed("ui_cancel"):
		$ConfirmDialog.popup_centered()
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func _on_confirm_confirmed() -> void:
	NetworkManager.leave_to_menu()


func _on_confirm_canceled() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
