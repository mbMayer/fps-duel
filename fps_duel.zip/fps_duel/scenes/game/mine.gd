extends Node3D
## BUILD-33: мина — инженерная оборона берега (по мотивам минных полей фильма).
##
## Игрок ставит мину клавишей G (не больше MINE_LIMIT активных). Мина
## взводится за ARM_TIME, затем реагирует на ВРАГА или «Полого человека»:
## поджиг FUSE секунд — и взрыв с уроном по площади. По своим не срабатывает.
##
## Вся логика — только на сервере; клиентские копии рисуют индикатор.

const GROUP := "mines"

const TRIGGER_R := 2.4      # м — радиус датчика
const BLAST_R := 5.0        # м — радиус взрыва
const ARM_TIME := 1.0       # с — время взведения
const FUSE := 0.35          # с — задержка от срабатывания до взрыва
const DMG_PLAYER := 85.0
const DMG_HOLLOW := 170.0
const LIFE := 75.0          # с — самоуничтожение, чтобы мины не копились

var mine_id := 0            # BUILD-33: сквозной номер для сетевой синхронизации
var owner_id := 0
var team := 0
var armed := false
var fuse := -1.0

var _t := 0.0
var _life := LIFE
var _arena: Node = null
var _lamp_mat: StandardMaterial3D = null
var _blinked := false


func _ready() -> void:
	add_to_group(GROUP)
	_arena = get_tree().current_scene
	_build_mesh()
	# BUILD-35: узел с RPC обязан иметь ОДИНАКОВОЕ имя у всех нод. Без имени
	# Godot строит путь вида «Arena/@Node3D@336», и у товарища пакет не находит
	# цель — в логе появлялись «Node not found» и «Invalid packet received».
	if name.begins_with("@"):
		push_error("[RPC] мина добавлена под автоименем %s — у товарищей путь не совпадёт" % name)


func is_server() -> bool:
	return multiplayer.multiplayer_peer != null and multiplayer.is_server()


func _build_mesh() -> void:
	var mat_body := StandardMaterial3D.new()
	mat_body.albedo_color = Color(0.13, 0.16, 0.12)
	var mat_top := StandardMaterial3D.new()
	mat_top.albedo_color = Color(0.20, 0.22, 0.18)
	var hull := MeshInstance3D.new()
	hull.name = "Hull"
	var bm := BoxMesh.new()
	bm.size = Vector3(0.36, 0.08, 0.26)
	hull.mesh = bm
	hull.position = Vector3(0.0, 0.04, 0.0)
	hull.material_override = mat_body
	add_child(hull)
	var lid := MeshInstance3D.new()
	lid.name = "Lid"
	var lm := BoxMesh.new()
	lm.size = Vector3(0.22, 0.05, 0.16)
	lid.mesh = lm
	lid.position = Vector3(0.0, 0.10, 0.0)
	lid.material_override = mat_top
	add_child(lid)
	# Индикатор: мигает — мина взведена и ждёт.
	_lamp_mat = StandardMaterial3D.new()
	_lamp_mat.albedo_color = Color(0.85, 0.25, 0.2)
	_lamp_mat.emission_enabled = true
	_lamp_mat.emission = Color(0.9, 0.2, 0.15)
	_lamp_mat.emission_energy_multiplier = 2.5
	var lamp := MeshInstance3D.new()
	lamp.name = "Lamp"
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.07
	lamp.mesh = sm
	lamp.position = Vector3(0.0, 0.14, 0.0)
	lamp.material_override = _lamp_mat
	add_child(lamp)


func _process(delta: float) -> void:
	# Индикатор: пока не взведена — тускло, взведена — ровно, поджиг — часто.
	if _lamp_mat == null:
		return
	var rate := 1.2
	if armed:
		rate = 3.0
	if fuse >= 0.0:
		rate = 18.0
	_blinked = fmod(Time.get_ticks_msec() / 1000.0, 1.0 / rate) < 0.5 / rate
	_lamp_mat.emission_energy_multiplier = 2.5 if _blinked else 0.15


func _physics_process(delta: float) -> void:
	if not is_server():
		return
	if _arena == null:
		_arena = get_tree().current_scene
	_life -= delta
	if _life <= 0.0:
		_request_despawn(mine_id)
		_arena.forget_mine(mine_id)
		_arena.mine_removed(owner_id)
		queue_free()
		return
	if not armed:
		_t += delta
		if _t >= ARM_TIME:
			armed = true
		return
	if fuse >= 0.0:
		fuse -= delta
		if fuse <= 0.0:
			explode()
		return
	if _has_trigger_target():
		fuse = FUSE


## BUILD-35: сообщить всем нодам, что этой мины больше нет. Событие уходит на
## АРЕНУ (стабильный путь), а мина у товарища ищется по сетевому номеру — так
## путь «Arena/Mine7» не зависит от порядка создания динамических узлов.
func _request_despawn(mid: int) -> void:
	if _arena == null:
		_arena = get_tree().current_scene
	if _arena != null and _arena.has_method("_event_mine_removed"):
		_arena._event_mine_removed.rpc(mid)


## Локальная уборка копии (зовёт арена — и у себя, и по событию у клиентов).
func despawn_locally() -> void:
	if _arena == null:
		_arena = get_tree().current_scene
	if _arena != null:
		if _arena.has_method("mine_removed"):
			_arena.mine_removed(owner_id)
		if _arena.has_method("forget_mine"):
			_arena.forget_mine(mine_id)
	queue_free()


## Есть ли в радиусе датчика враг (игрок другой команды) или «Полый человек».


func _has_trigger_target() -> bool:
	if _arena == null:
		return false
	for h in _arena.hollows():
		var hn: Node3D = h
		if is_instance_valid(hn) and hn.global_position.distance_to(global_position) <= TRIGGER_R + 0.6:
			return true
	for id in _arena.players.keys():
		var p: Node = _arena.players[id]
		if p == null or p.dead:
			continue
		if int(id) == owner_id:
			continue
		if _arena.side_of(int(id)) == team:
			continue   # по своим не срабатываем
		if p.global_position.distance_to(global_position) <= TRIGGER_R:
			return true
	return false


func explode() -> void:
	if not is_server():
		return
	if _arena == null:
		return
	var pos := global_position
	# Игроки: урон падает с расстоянием, по своим — ничего.
	for id in _arena.players.keys():
		var p: Node = _arena.players[id]
		if p == null or p.dead:
			continue
		if int(id) == owner_id or _arena.side_of(int(id)) == team:
			continue
		var d: float = p.global_position.distance_to(pos)
		if d > BLAST_R:
			continue
		var dmg := DMG_PLAYER * (1.0 - 0.6 * (d / BLAST_R))
		_arena.mine_hit_player(p, dmg, owner_id)
	# «Полые люди» — тут урон максимальный: взрыв и есть главный убийца толпы.
	for h in _arena.hollows():
		var hn: Node3D = h
		if not is_instance_valid(hn):
			continue
		var dh: float = hn.global_position.distance_to(pos)
		if dh > BLAST_R + 0.8:
			continue
		var dmg_h := DMG_HOLLOW * (1.0 - 0.5 * (dh / BLAST_R))
		hn.take_damage(dmg_h, owner_id)
	_arena._blast_fx.rpc(pos)
	_arena._spawn_blast(pos)
	_arena.mine_removed(owner_id)
	_arena.forget_mine(mine_id)
	_request_despawn(mine_id)   # копии у клиентов (через арену)
	queue_free()
