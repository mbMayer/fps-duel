extends Node3D
## Сервер-авторитарная логика матча: спавн, попадания, урон, счёт, респаун.
## Все решения принимает хост (сервер); клиенты шлют только запросы.

const RESPAWN_TIME := 3.0
const READY_RETRY := 0.4
const SMOKE_SHOTS := 3

# BUILD-30: две турели на противоположных сторонах арены (север/юг),
# каждая смотрит в центр.
const TURRET_SCENE := "res://scenes/game/turret.tscn"
# BUILD-33: геометрия карты берётся ИЗ СКРИПТА КАРТЫ через preload (работает и
# при первом запуске из архива, в отличие от ссылок на class_name, которые
# требуют просканированного проекта).
const Map := preload("res://scenes/game/gorge.gd")

# BUILD-33: автотурели стоят у самой кромки обрыва (по флангу берега).
const TURRET_SPAWNS := [Map.TURRET_POS_N, Map.TURRET_POS_S]
const MOUNT_RANGE := 2.6

# BUILD-32: точки спавна берём с карты ущелья. В командном режиме команды
# расходятся по берегам; в тестовых режимах все спавнятся на северном плато
# (headless-сценарии стреляют друг в друга прямо со спавна).
# ---------------------------------------------------------------- проверка обороны (defenset)

var _dt_started := false
var _dt_checks := 0
var _dt_fails := 0


func _dt_ok(cond: bool, label: String) -> void:
	_dt_checks += 1
	if cond:
		print("[DEFTEST] OK   %s" % label)
	else:
		_dt_fails += 1
		print("[DEFTEST] ФЕЙЛ %s" % label)


func _dt_wait_hollow(limit: float) -> Node:
	var t := 0.0
	while t < limit:
		var hs := hollows()
		if hs.size() > 0:
			return hs[0]
		await get_tree().create_timer(0.2).timeout
		t += 0.2
	return null


## Сценарий хоста: расклад по берегам, подъём полого из ущелья, прорыв
## периметра, автотурель и победа по итогам единственной волны.
func _defense_test_host() -> void:
	print("[DEFTEST] --- серверный сценарий обороны ---")
	await get_tree().create_timer(1.5).timeout
	# 1) Игроки разложены по двум берегам (лицом к ущелью).
	var north := 0
	var south := 0
	for id in players.keys():
		if players[id].global_position.z > 0.0:
			north += 1
		else:
			south += 1
	_dt_ok(north >= 1 and south >= 1, "игроки держат оба берега (север=%d, юг=%d)" % [north, south])
	_turret_auto_enabled = false   # на время проверок автотурель не стреляет
	# 2) Полый появляется на дне ущелья и лезет по стене вверх.
	var h := await _dt_wait_hollow(20.0)
	if h == null:
		_dt_ok(false, "полый человек появился из ущелья")
		_dt_finish()
		return
	_dt_ok(true, "полый человек появился из ущелья (%s)" % h.name)
	var y0: float = h.global_position.y
	_dt_ok(y0 < Map.DEEP_Y, "он ещё на дне ущелья (y=%.1f, граница глубины %.0f)" % [y0, Map.DEEP_Y])
	await get_tree().create_timer(1.6).timeout
	var y1: float = h.global_position.y if is_instance_valid(h) else 999.0
	_dt_ok(y1 > y0 + 2.0, "он карабкается по стене вверх (%.1f → %.1f)" % [y0, y1])
	# 3) Дожидаемся кромки — он вылезает на плато и бежит к точке прорыва.
	var climbed := false
	for i in 200:
		if not is_instance_valid(h):
			break
		if h.phase >= 1:
			climbed = true
			break
		await get_tree().create_timer(0.25).timeout
	_dt_ok(climbed, "полый вылез на кромку и побежал к прорыву периметра")
	# 4) Прорыв: подводим его к точке прорыва — целостность периметра падает.
	var per0 := _perimeter
	if climbed:
		var breach: Vector3 = Map.BREACH_N if h.side > 0.0 else Map.BREACH_S
		var inland := 1.0 if breach.z > 0.0 else -1.0
		h.position = breach + Vector3(0.0, 0.2, 2.2 * inland)
		h.velocity = Vector3.ZERO
		await get_tree().create_timer(2.0).timeout
		_dt_ok(_perimeter < per0, "прорыв периметра снял прочность (%.0f → %.0f)" % [per0, _perimeter])
	else:
		_dt_ok(false, "прорыв периметра снял прочность")
	# 5) Автотурель у кромки сама бьёт по полому — подводим свежего к северной турели.
	var h2 := _dt_spawn_at(-7.0, 1.0)
	await get_tree().create_timer(0.4).timeout
	var hp0: float = h2.hp if h2 != null else 0.0
	if h2 != null:
		h2.position = Map.TURRET_POS_N + Vector3(0.0, 0.2, 2.6)
		h2.velocity = Vector3.ZERO
	_turret_auto_enabled = true
	await get_tree().create_timer(1.2).timeout
	var hp1: float = h2.hp if is_instance_valid(h2) else 0.0
	_dt_ok(hp1 < hp0 or not is_instance_valid(h2), "автотурель нанесла урон (hp %.0f → %.0f)" % [hp0, hp1])
	_turret_auto_enabled = false
	# 6) Победа: добиваем оставшихся — волна отбита, матч завершён.
	for cand in hollows():
		cand.take_damage(9999.0, 0)
	for i in 160:
		if _match_over:
			break
		await get_tree().create_timer(0.25).timeout
	_dt_ok(_match_over, "волна отбита, матч завершён (периметр %d %%)" % int(_perimeter))
	_dt_finish()


## Ставит «Полого человека» прямо у кромки (для проверки автотурели):
## он сразу оказывается на плато своего берега, а не лезет 17 секунд.
func _dt_spawn_at(x: float, side: float) -> Node:
	_hollow_seed += 1
	var h: Node3D = load(HOLLOW_SCENE).instantiate()
	h.name = "Hollow%d" % _hollow_seed
	add_child(h)
	var start := Vector3(x, 0.2, side * (Map.RIM_Z - 0.6))
	var aim: Vector3 = Map.BREACH_N if side > 0.0 else Map.BREACH_S
	h.setup(start, aim, _hollow_seed + 991)
	_event_hollow.rpc(_hollow_seed, start, aim)
	_wave_alive += 1
	return h


func _dt_finish() -> void:
	print("[DEFTEST] итог: проверок=%d, провалов=%d" % [_dt_checks, _dt_fails])
	if _dt_fails == 0 and _dt_checks > 0:
		print("[DEFTEST_OK] оборона ущелья: волны, полые люди, прорыв и автотурель проверены")
	else:
		print("[DEFTEST_FAIL] проверок=%d, провалов=%d" % [_dt_checks, _dt_fails])
	await get_tree().create_timer(2.0).timeout
	get_tree().quit()


## Клиент: видит полых людей и строку обороны в HUD.
func _defense_test_client() -> void:
	var me := multiplayer.get_unique_id()
	print("[DEFTEST] --- клиент %d: смотрю оборону ---" % me)
	var saw := false
	for i in 120:
		if get_tree().get_nodes_in_group("hollows").size() > 0:
			saw = true
			break
		await get_tree().create_timer(0.25).timeout
	var hud_txt := ""
	for i in 40:
		var hud := get_node_or_null("HUD")
		if hud != null and str(hud.defense_label.text).contains("Волна"):
			hud_txt = str(hud.defense_label.text)
			break
		await get_tree().create_timer(0.25).timeout
	print("[DEFTEST] клиент %d: полых видно=%s, HUD=«%s»" % [me, str(saw), hud_txt])
	if saw and hud_txt.contains("Волна"):
		print("[DEFTEST_CLIENT_OK] клиент %d: волна и полые люди видны" % me)
	else:
		print("[DEFTEST_CLIENT_FAIL] клиент %d: полых=%s, HUD=«%s»" % [me, str(saw), hud_txt])


# ---------------------------------------------------------------- кооп-оборона (BUILD-33)

## По мотивам фильма «Ущелье»: из тумана на дне лезут «Полые люди». Четыре
## игрока держат оба берега — двое на северном, двое на южном. Помогают
## автотурели у кромки (BUILD-39: мины убраны совсем).
const HOLLOW_SCENE := "res://scenes/game/hollow.tscn"
const TURRET_AUTO_RANGE := 46.0  # м — дальность автотурели
const TURRET_AUTO_SHOT_MS := 230 # темп автоматического огня
const TURRET_AUTO_DAMAGE := 14.0
const BREACH_DAMAGE := 12.0      # сколько снимает полый, дошедший до башни
const WAVE_PAUSE := 12.0         # пауза между волнами
const WAVE_SPAWN_GAP := 1.1      # интервал между появлениями внутри волны
const DEFENSE_WAVES := [4, 6, 8, 10, 12, 14]   # волны: сколько полых в каждой

var _wave := 0
var _wave_alive := 0             # сколько полых ещё не убито/не прорвалось
var _wave_pending := 0           # сколько ещё не появилось в текущей волне
var _kills := 0
var _perimeter := 100.0
var _defense_running := false
var _hollow_seed := 0
# BUILD-36: сквозной счётчик эффектов — у КАЖДОГО узла, который создаётся в бою,
# есть детерминированное имя. Автоимена (@Node3D@336) у хоста и клиента не
# совпадают: если у такого узла когда-нибудь появится RPC, пакеты не найдут цель.
var _fx_seq := 0
var _def_test_stage := 0         # этапы сценария headless-проверки
## BUILD-35/36: у каждого узла, созданного в бою, детерминированное имя, а
## события идут через арену: путь «Arena/@Node3D@N» у клиента не находился —
## отсюда были «Node not found» и «Invalid packet received» при отдаче автотурели.
var _auto_kick_seen := 0         # BUILD-35: сколько отдач автотурели пришло событием
var _game_waves_total := 1       # сколько волн в текущем матче
var _turret_auto_enabled := true  # выключается в сценарии проверки


# ---------------------------------------------------------------- команды и раунды

@export var player_scene: PackedScene

var players := {}   # peer_id -> Player
var _spawn_idx := {}  # peer_id -> индекс точки спавна (для респауна)
var scores := {}    # peer_id -> личный вклад: сколько «Полых людей» положил
var turrets: Array[Node3D] = []  # BUILD-30

# BUILD-32: команды и раунды (значимо на сервере; клиентам приходит событиями).
## BUILD-34: берег игрока. +1 — северный пост, -1 — южный.
var sides := {}                    # peer_id -> +1 / -1
## BUILD-34: раненые: peer_id -> сколько секунд осталось до возврата на пост.
var _downed := {}
## BUILD-34: идущий подъём (сервер): {reviver, target} и таймер.
var _revive_job := {}
var _revive_job_left := 0.0
var _rt_started := false           # сценарий проверки подъёма уже запущен
var _st_started := false           # BUILD-35: сценарий проверки бега запущен


func get_player_by_id(id: int) -> Node:
	return players.get(id)

var _ready_clients: Array[int] = []
var _match_over := false
var _smoke_hits := 0
var _smoke_client_hits := 0
var _smoke_client_got_hits := 0
var _smoke_fired := false

@onready var players_root: Node3D = $Players


var _arena_t := 0.0
var _crouch_seen := false
var _jump_seen := false
var _pose_poll_done := false
var _breath_h0 := 0.0
var _breath_c0 := 0.0


# BUILD-27: присед/прыжок хоста ловим СОБЫТИЙНО (опрос флагов), а не по
# таймерам — часы хоста и клиента могут слегка расходиться.
var _dbg_t2 := 0.0


func _process(delta: float) -> void:
	# Без назначенного peer (одиночный запуск, разрыв соединения) multiplayer-запросы
	# ниже засоряли лог «No multiplayer peer is assigned».
	if multiplayer.multiplayer_peer == null:
		return
	if multiplayer.is_server() and OS.get_cmdline_user_args().has("inputtest"):
		_dbg_t2 += delta
		if _dbg_t2 > 2.0:
			_dbg_t2 = 0.0
			var ps := ""
			for k in players.keys():
				ps += "%d:y=%.1f " % [int(k), players[k].global_position.y]
			print("[DBG-SRV] %s" % ps)
	_arena_t += delta
	# BUILD-30: авторитетное завершение перезарядки турели (сервер):
	# патроны доходят до полного магазина.
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		var now := Time.get_ticks_msec()
		for t in turrets:
			if t.reload_end_ms > 0 and now >= t.reload_end_ms:
				t.reload_end_ms = 0
				t.mag = int(Game.TURRET["magazine"])
	if Game.key_test and multiplayer.multiplayer_peer != null and multiplayer.is_server():
		_keytest_poll()  # BUILD-31: ловим каждое изменение mounted_idx по кадрам
	# BUILD-34: серверный тик боя — автотурели, раненые и подъём.
	if multiplayer.multiplayer_peer != null and multiplayer.is_server() and not _match_over:
		if Game.defense_mode:
			_auto_turrets_tick(delta)
		_tick_downed(delta)
		_tick_revive(delta)
	if not Game.input_test or multiplayer.multiplayer_peer == null or multiplayer.is_server():
		return
	if _arena_t < 13.0 or _arena_t > 24.5:
		return
	var host_node: Node = players.get(1)
	if host_node == null:
		return
	if not _crouch_seen and host_node._remote_crouch:
		_crouch_seen = true
		# поза разгоняется ~0.4 с — ассерт чуть позже.
		get_tree().create_timer(0.5).timeout.connect(func() -> void:
			var hm: float = host_node._head_mesh.global_position.y
			if host_node.head.position.y < 1.35 and hm < 1.4:
				print("[CLIENTANIM] присед соперника синхронизирован (голова %.2f м, голова-меш %.2f м)" % [host_node.head.position.y, hm])
			else:
				print("[CLIENTANIM_FAIL] присед соперника: голова=%.2f, меш=%.2f" % [host_node.head.position.y, hm])
		)
	if not _jump_seen and _arena_t > 15.0 and not host_node._remote_grounded:
		_jump_seen = true
		get_tree().create_timer(0.3).timeout.connect(func() -> void:
			var foot_y: float = host_node._leg_rig_r["foot"].global_position.y
			if foot_y > 0.2:
				print("[CLIENTANIM] прыжок соперника синхронизирован (ноги поджаты, стопа %.2f м)" % foot_y)
			else:
				print("[CLIENTANIM_FAIL] прыжок соперника: стопа=%.2f" % foot_y)
		)
	if _arena_t > 24.0 and not _pose_poll_done:
		_pose_poll_done = true
		if not _crouch_seen:
			print("[CLIENTANIM_FAIL] присед соперника не пришёл")
		if not _jump_seen:
			print("[CLIENTANIM_FAIL] прыжок соперника не пришёл")


func _ready() -> void:
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	if Game.smoke_test and not multiplayer.is_server():
		Game.dealt_hit.connect(_smoke_on_dealt_hit)
		Game.got_hit.connect(_smoke_on_got_hit)
	if Game.turret_test and not multiplayer.is_server():
		_turret_client_monitor()
	if Game.key_test and not multiplayer.is_server():
		_keytest_client_monitor()
	if Game.keysync_test and not multiplayer.is_server():
		_keytest_sync_client()
	if Game.death_test and not multiplayer.is_server():
		_keytest_death_client()
	# BUILD-32: проверка геометрии карты (одним инстансом, без сети). Флаги CLI
	# выставляются отложенно, поэтому проверяем их не в _ready, а по таймеру.
	get_tree().create_timer(0.6).timeout.connect(func() -> void:
		if Game.map_test:
			_map_test_run()
		if Game.walk_test:
			_walk_test_run()
		if Game.shots_test:
			_defense_running = false   # снимки карты снимаем без волн
			# Страховка от зависания: снимки не должны висеть дольше 3 минут.
			get_tree().create_timer(180.0).timeout.connect(func() -> void:
				print("[SHOTS_FAIL] прогон снимков не завершился за 180 с")
				get_tree().quit(1)
			)
	)
	if Game.autostart:
		# Headless-проверки: дублируем финал в лог.
		Game.match_over.connect(func(label: String) -> void:
			print("[AUTOSTART] матч завершён:\n" + label)
		)
	if multiplayer.multiplayer_peer == null:
		return  # одиночный просмотр сцены в редакторе
	_setup_turrets()
	if multiplayer.is_server():
		scores[1] = 0
		for id in multiplayer.get_peers():
			scores[int(id)] = 0
	else:
		_start_ready_retry()


# ---------------------------------------------------------------- турели (BUILD-30)

func _setup_turrets() -> void:
	var scene := load(TURRET_SCENE)
	for i in TURRET_SPAWNS.size():
		var t: Node3D = scene.instantiate()
		t.turret_idx = i
		# BUILD-35: имя задаём ДО add_child — иначе Godot выдаёт автоимя
		# (@Node3D@N), которое на хосте и клиенте не совпадает, и RPC-пакеты
		# к турели у клиента не находят цель.
		t.name = "Turret%d" % i
		t.position = TURRET_SPAWNS[i]
		t.rotation.y = atan2(TURRET_SPAWNS[i].x, TURRET_SPAWNS[i].z)  # смотрит в центр
		add_child(t)
		turrets.append(t)


## Посадка в турель: запрос (клиент) / прямое действие (хост) -> проверка на
## сервере -> авторитетное событие всем нодам.
@rpc("any_peer", "call_remote", "reliable")
func request_mount(turret_idx: int) -> void:
	try_mount_player(multiplayer.get_remote_sender_id(), turret_idx)


@rpc("any_peer", "call_remote", "reliable")
func request_dismount() -> void:
	try_dismount_player(multiplayer.get_remote_sender_id())


func try_mount_player(id: int, turret_idx: int) -> void:
	if not multiplayer.is_server() or _match_over:
		return
	if turret_idx < 0 or turret_idx >= turrets.size():
		return
	var t: Node3D = turrets[turret_idx]
	var p: Node = players.get(id)
	if p == null or p.dead or p.mounted_idx >= 0 or t.is_occupied():
		return
	if t.position.distance_to(p.position) > MOUNT_RANGE:
		return
	t.occupant_id = id
	p._apply_mount_event(turret_idx)  # на серверной ноде
	_event_mount.rpc(id, turret_idx, id)
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d сел в турель %d" % [id, turret_idx])


func try_dismount_player(id: int) -> void:
	if not multiplayer.is_server() or _match_over:
		return
	var p: Node = players.get(id)
	if p == null or p.mounted_idx < 0:
		return
	var t: Node3D = turrets[p.mounted_idx]
	var tidx := int(p.mounted_idx)
	t.occupant_id = -1
	# Выходим вбок от турели (на «правую» сторону от её носа), внутрь арены.
	var yaw: float = float(p.rotation.y)
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var pos := t.position + right * 1.7
	# BUILD-39: турели стоят вплотную к обрыву, поэтому прежний зажим z ≤ 19
	# выкидывал вышедшего игрока в ущелье. Теперь зажим держит его на плато:
	# по x — внутри стен периметра, по z — не ближе метра к кромке своего берега.
	pos.x = clampf(pos.x, -Map.MAP_HALF_X + 2.0, Map.MAP_HALF_X - 2.0)
	var side_sign := 1.0 if t.position.z > 0.0 else -1.0
	var min_z: float = Map.RIM_EDGE_Z + 1.0   # не ближе метра к падению
	if absf(pos.z) < min_z:
		pos.z = min_z * side_sign
	elif pos.z * side_sign < 0.0:
		pos.z = min_z * side_sign
	p._apply_dismount_event(pos, yaw)  # на серверной ноде
	_event_dismount.rpc(id, pos, yaw)
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d вышел из турели %d (pos=%s)" % [id, tidx, str(pos)])


@rpc("authority", "call_remote", "reliable")
func _event_mount(id: int, turret_idx: int, occupant: int) -> void:
	# BUILD-31: occupant едет вместе с событием — без него у клиента сиденье
	# оставалось «свободным» (occupant_id = -1): соперник видел подсказку
	# «F — сесть в турель» у занятой установки, а купол не следил за сидящим.
	if turret_idx >= 0 and turret_idx < turrets.size():
		turrets[turret_idx].occupant_id = occupant
	var p: Node = players.get(id)
	if p != null:
		p._apply_mount_event(turret_idx)


@rpc("authority", "call_remote", "reliable")
func _event_dismount(id: int, pos: Vector3, yaw: float) -> void:
	var p: Node = players.get(id)
	if p != null:
		# BUILD-31: сиденье освобождается на ВСЕХ нодах, а не только на сервере.
		if p.mounted_idx >= 0 and p.mounted_idx < turrets.size():
			turrets[p.mounted_idx].occupant_id = -1
		p._apply_dismount_event(pos, yaw)


## Перезарядка турели: клиент просит, сервер подтверждает (и держит свой
## авторитетный таймер; завершение — в _process).
@rpc("any_peer", "call_remote", "reliable")
func request_turret_reload() -> void:
	var sender := multiplayer.get_remote_sender_id()
	var p: Node = players.get(sender)
	if p == null or p.mounted_idx < 0:
		return
	var t: Node3D = turrets[p.mounted_idx]
	if t.reload_end_ms > 0 or t.mag >= int(Game.TURRET["magazine"]):
		return
	t.reload_end_ms = Time.get_ticks_msec() + int(Game.TURRET["reload_ms"])
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d начал перезарядку турели %d" % [sender, p.mounted_idx])


## Выстрел из турели дошёл до остальных: отдача ствола + трассер.
## Шлёт СТРЕЛЯЮЩИЙ (any_peer) — сервер и другие клиенты не видят собственного
## RPC, поэтому двойного эффекта у стрелка нет (у него — локальный).
@rpc("any_peer", "call_remote", "unreliable")
func _turret_fx(turret_idx: int, barrel_idx: int, end: Vector3) -> void:
	if turret_idx < 0 or turret_idx >= turrets.size():
		return
	var t: Node3D = turrets[turret_idx]
	t.fx_seen += 1
	t.fire_kick(barrel_idx)
	_spawn_tracer_scene(t.world_muzzle(barrel_idx), end)


func _spawn_tracer_scene(from: Vector3, to: Vector3) -> void:
	var tracer: Node3D = preload("res://scenes/fx/tracer.tscn").instantiate()
	_fx_seq += 1
	tracer.name = "TracerFX%d" % _fx_seq       # BUILD-36: имя вместо автоимени
	add_child(tracer)
	tracer.setup(from, to)


## Тест-телепорт (только для headless-автотеста турели): сервер сдвигает ноду
## ЧУЖОГО игрока на его клиенте — авторитет движения остаётся у клиента.
@rpc("authority", "call_remote", "reliable")
func test_set_pos(id: int, pos: Vector3, yaw: float) -> void:
	if not (Game.turret_test or Game.key_test or Game.death_test or Game.revive_test):
		return
	var p: Node = players.get(id)
	if p == null:
		return
	p.position = pos
	p.rotation.y = yaw
	p.reset_net_targets()


## Тест: клиент выполняет реальную команду «сесть» (полный any_peer-путь).
@rpc("authority", "call_remote", "reliable")
func test_client_do_mount(turret_idx: int) -> void:
	if not Game.turret_test:
		return
	request_mount.rpc(turret_idx)


## Тест: клиент выполняет реальную команду «выйти».
@rpc("authority", "call_remote", "reliable")
func test_client_dismount() -> void:
	if not Game.turret_test:
		return
	request_dismount.rpc()


## BUILD-31: клиент жмёт F настоящим событием клавиатуры (весь конвейер ввода).
@rpc("authority", "call_remote", "reliable")
func test_keypress(id: int, keycode: int = KEY_F) -> void:
	if not (Game.key_test or Game.death_test):
		return
	if id != multiplayer.get_unique_id():
		return
	var down := InputEventKey.new()
	down.physical_keycode = keycode
	down.pressed = true
	down.echo = false
	Input.parse_input_event(down)
	var up := InputEventKey.new()
	up.physical_keycode = keycode
	up.pressed = false
	up.echo = false
	Input.parse_input_event(up)
	print("[KEYTEST] клиент %d: нажата клавиша %s" % [id, OS.get_keycode_string(keycode)])


# ---------------------------------------------------------------- готовность и спавн

func _start_ready_retry() -> void:
	var t := Timer.new()
	t.wait_time = READY_RETRY
	t.autostart = true
	add_child(t)
	t.timeout.connect(func() -> void:
		if players.has(multiplayer.get_unique_id()) or multiplayer.multiplayer_peer == null:
			t.queue_free()
			return
		_notify_ready.rpc_id(1)
	)


@rpc("any_peer", "call_remote", "reliable")
func _notify_ready() -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender > 1 and not _ready_clients.has(sender):
		_ready_clients.append(sender)
		_try_spawn_all()


func _try_spawn_all() -> void:
	if players.size() > 0 or _match_over:
		return
	var expected: Array[int] = [1]
	for id in multiplayer.get_peers():
		expected.append(int(id))
	for id in expected:
		if id != 1 and not _ready_clients.has(id):
			return  # ждём, пока все клиенты загрузят сцену
	for i in expected.size():
		_spawn_player(expected[i], i)
	# BUILD-34: единственный режим — кооп-оборона: она стартует волнами.
	if Game.defense_mode:
		_start_defense()
		if Game.defense_test and not _dt_started:
			# Сценарий проверки запускаем, когда все игроки на карте — иначе первая
			# же проверка («оба берега») гоняется с подключением.
			_dt_started = true
			_defense_test_host()
		if Game.revive_test and not _rt_started:
			_rt_started = true
			_revive_test_host()
	if Game.input_test:
		print("[INPUTTEST] сервер: спавн готов — имитирую клики ЛКМ через полный конвейер ввода")
		for i in SMOKE_SHOTS:
			get_tree().create_timer(0.5 + 0.3 * i).timeout.connect(_synthetic_click)
		get_tree().create_timer(16.0).timeout.connect(_input_test_weapons)
		get_tree().create_timer(35.0).timeout.connect(_smoke_host_finish)
		# BUILD-27: присед (14.6..15.8) и прыжок (15.8) — АБСОЛЮТНАЯ шкала,
		# клиент ловит события опросом в _process.
		get_tree().create_timer(14.6).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me != null:
				me.dbg_crouch = true
		)
		get_tree().create_timer(15.2).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			var ok := bool(me._crouch_w > 0.7 and me.head.position.y < 1.35)
			if ok:
				print("[WEAPONTEST] присед: голова %.2f м, колени согнуты (вес %.2f)" % [me.head.position.y, me._crouch_w])
			else:
				print("[WEAPONTEST_FAIL] присед: голова=%.2f, вес=%.2f" % [me.head.position.y, me._crouch_w])
		)
		get_tree().create_timer(15.8).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			me.dbg_crouch = false
			me.velocity.y = me.JUMP_VELOCITY  # сразу за приседом — прыжок
		)
		get_tree().create_timer(16.1).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			var foot_y: float = me._leg_rig_r["foot"].global_position.y
			var ok := bool(me._air_w > 0.5 and foot_y > 0.2)
			if ok:
				print("[WEAPONTEST] прыжок: в воздухе ноги поджаты (стопа %.2f м)" % foot_y)
			else:
				print("[WEAPONTEST_FAIL] прыжок: air=%.2f, стопа=%.2f" % [me._air_w, foot_y])
		)
		# BUILD-28: idle-дыхание оружия в покое (два замера — фаза идёт).
		get_tree().create_timer(20.5).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me != null:
				_breath_h0 = me._fp_breath
		)
		get_tree().create_timer(20.9).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			if absf(me._fp_breath - _breath_h0) > 0.001:
				print("[WEAPONTEST] idle-дыхание: оружие живёт в покое (%.4f м)" % me._fp_breath)
			else:
				print("[WEAPONTEST_FAIL] idle-дыхание отсутствует")
		)
	elif Game.key_test:
		# BUILD-31: турель через НАСТОЯЩУЮ клавишу F (репродукция жалобы игрока).
		print("[KEYTEST] сервер: игроки заспавнены (ключи=%s) — жму F по-настоящему" % str(players.keys()))
		_keytest_host()
	elif Game.death_test:
		print("[DEATHT] сервер: игроки заспавнены — раняю сидящего в турели")
		_keytest_death_host()
	elif Game.keysync_test:
		print("[KEYSYNC] сервер: игроки заспавнены — проверяю видимость турели у соперника")
		_keytest_sync_host()
	elif Game.sprint_test:
		print("[SPRINTTEST] сервер: игроки заспавнены — ждём бега клиента")
		_sprint_test_host()
	elif Game.turret_test:
		# BUILD-30: сценарий турели — хост-оркестрация, клиент-монитор.
		print("[TURRET] сервер: игроки заспавнены (ключи=%s) — начинаю сценарий турели" % str(players.keys()))
		_turret_test_host()
	elif Game.smoke_test:
		print("[SMOKE] сервер: игроки заспавнены (арена #%d, ключи=%s)" % [get_instance_id(), str(players.keys())])
		get_tree().create_timer(0.5).timeout.connect(_smoke_host_shoots_client)
		get_tree().create_timer(6.0).timeout.connect(_smoke_host_finish)


func _spawn_player(id: int, index: int) -> void:
	if players.has(id):
		return
	var side := _assign_side(id)
	var pos: Vector3
	var yaw: float
	var spot: int
	if Game.defense_mode:
		# BUILD-34: все заодно; по двое на пост, лицом к ущелью.
		var d := _defense_spawn_point(index)
		pos = d[0]
		yaw = d[1]
		spot = int(index / 2)
	else:
		# Служебные headless-сценарии: общая площадка на плато.
		spot = index
		pos = Map.SPAWN_TEST[spot % Map.SPAWN_TEST.size()]
		yaw = Map.SPAWN_TEST_YAW[spot % Map.SPAWN_TEST_YAW.size()]
	var p := _make_player(id, pos, yaw)
	p.set_side(side)
	scores[id] = 0
	_spawn_idx[id] = spot
	_sync_spawn.rpc(id, pos, yaw, side)
	_push_squad()
	if id == multiplayer.get_unique_id():
		Game.player_spawned_local.emit(players[id])
		Game.scores_changed.emit(scores.duplicate(), id)


func _make_player(id: int, pos: Vector3, yaw: float) -> CharacterBody3D:
	var p: CharacterBody3D = player_scene.instantiate()
	p.name = str(id)
	p.position = pos
	p.rotation.y = yaw
	p.set_multiplayer_authority(id)
	if OS.is_debug_build():
		print("[AUTH] создан игрок %d (авторитет=%d, мой_id=%d, сервер=%s)" % [id, p.get_multiplayer_authority(), multiplayer.get_unique_id(), str(multiplayer.is_server())])
	players_root.add_child(p)
	players[id] = p
	return p


@rpc("authority", "call_remote", "reliable")
func _sync_spawn(id: int, pos: Vector3, yaw: float, side: int) -> void:
	if players.has(id):
		return
	var p := _make_player(id, pos, yaw)
	sides[id] = side
	p.set_side(side)
	scores[id] = 0
	if id == multiplayer.get_unique_id():
		_spawn_idx[id] = players.size() - 1
		Game.player_spawned_local.emit(players[id])
		Game.scores_changed.emit(scores.duplicate(), id)
		if Game.input_test and not multiplayer.is_server():
			_input_test_client_checks()
		if Game.defense_test and not multiplayer.is_server() and not _dt_started:
			_dt_started = true   # клиентская проверка — когда игрок на карте
			_defense_test_client()
		if Game.revive_test and not multiplayer.is_server() and not _rt_started:
			_rt_started = true
			_revive_test_client()
		if Game.sprint_test and not multiplayer.is_server() and not _st_started:
			_st_started = true
			_sprint_test_client()


# ---------------------------------------------------------------- стрельба (только сервер)

func handle_shoot_request(sender_id: int, origin: Vector3, dir: Vector3, weapon_idx: int, attack_type: int) -> void:
	if OS.is_debug_build():
		print("[SHOT] сервер получил запрос от %d (оружие=%d, атака=%d)" % [sender_id, weapon_idx, attack_type])
	if not multiplayer.is_server():
		return
	if _match_over:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — матч завершён" % sender_id)
		return
	var shooter: Node = players.get(sender_id)
	if shooter == null or shooter.dead or shooter.downed:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — стрелок не найден, мёртв или ранен" % sender_id)
		return
	# BUILD-30: турель — отдельная ветка валидации (оружие индекса 3).
	if weapon_idx == Game.TURRET_IDX:
		_handle_turret_shot(sender_id, shooter, dir)
		return
	# Античит: стрелять можно только тем оружием, что реально выбрано.
	if not Game.WEAPONS.has(weapon_idx) or weapon_idx != shooter.current_weapon:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — оружие не совпадает (запрошено %d, в руках %d)" % [sender_id, weapon_idx, shooter.current_weapon])
		return
	# Тяжёлая атака есть только у ножа.
	if weapon_idx != 0:
		attack_type = 0
	var w: Dictionary = Game.WEAPONS[weapon_idx]
	var now := Time.get_ticks_msec()
	if now < shooter.reload_end_ms:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — идёт перезарядка" % sender_id)
		return
	# Патроны: у ножа их нет, остальное оружие требует наличия в магазине.
	# Хост уже списал патрон локально в _fire() — сервер списывает только клиентам.
	var is_heavy := weapon_idx == 0 and attack_type == 1
	if sender_id != multiplayer.get_unique_id() and int(w.get("magazine", -1)) >= 0:
		if int(shooter.ammo_mag.get(weapon_idx, 0)) <= 0:
			if OS.is_debug_build():
				print("[SHOT] игрок %d: отклонено — нет патронов" % sender_id)
			return
		shooter.ammo_mag[weapon_idx] = int(shooter.ammo_mag[weapon_idx]) - 1
	if sender_id != multiplayer.get_unique_id():
		# Кулдаун проверяется только для КЛИЕНТОВ (античит против спам-выстрелов).
		# Хост уже прошёл проверку кулдауна в _fire(); повторная проверка здесь
		# отбрасывала ВСЕ выстрелы хоста — это и был баг «хост не наносит урон».
		var bypass := Game.smoke_test and not Game.input_test
		if not bypass and now < shooter.next_allowed_shot_ms:
			if OS.is_debug_build():
				print("[SHOT] игрок %d: отклонено — кулдаун оружия" % sender_id)
			return
		var cd := int(w["heavy_cooldown_ms"]) if is_heavy else int(w["cooldown_ms"])
		shooter.next_allowed_shot_ms = now + cd
	dir = dir.normalized()
	# Античит: клиент должен стрелять примерно из своей серверной позиции.
	var head_pos: Vector3 = shooter.get_head_world_position()
	if origin.distance_to(head_pos) > 2.5:
		origin = head_pos
	var weapon_range: float = float(w["heavy_range"]) if is_heavy else float(w["range"])
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * weapon_range)
	query.collision_mask = 3  # мир (1) + хитбоксы (2)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	# Выстрел «по стволу» у стены: дуло может стоять вплотную к поверхности.
	query.hit_from_inside = true
	query.exclude = [
		shooter.get_rid(),                    # RID самого тела (CollisionObject3D)
		shooter.get_node("Hitbox").get_rid(), # RID Area3D-хитбокса
	]
	var hit := space.intersect_ray(query)
	var end := origin + dir * weapon_range
	var victim: Node = null
	if hit:
		end = hit.position
		victim = _resolve_victim(hit.collider, shooter)
	var damage: float = float(w["heavy_damage"]) if is_heavy else float(w["damage"])
	if victim != null:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: ПОПАЛ по игроку %d (%s, урон %.0f)" % [sender_id, str(victim.name).to_int(), str(w["name"]), damage])
		_apply_damage(victim, shooter, damage)
	elif OS.is_debug_build():
		# Диагностика для отладки «не наносится урон»: видно, куда ушёл луч.
		print("[SHOT] игрок %d: мимо (луч остановлен: %s)" % [sender_id, str(hit.collider if hit else "ничего")])
	_impact.rpc(end, victim != null)
	_spawn_impact(end)  # сервер не получает собственный call_remote — спавним искры локально


# BUILD-30: выстрел из турели. Авторитетно на сервере: ствол и точка вылета
# считаются из состояния СЕРВЕРНОЙ турели (клиентский origin игнорируется),
# направление зажимается к оси ствола — турель бьёт только «вперёд по курсу».
# Стволы стреляют по очереди: серверный счётчик t.barrel.
func _handle_turret_shot(sender_id: int, shooter: Node, dir: Vector3) -> void:
	if shooter.mounted_idx < 0 or shooter.mounted_idx >= turrets.size():
		if OS.is_debug_build():
			print("[TURRET] игрок %d: отклонено — не сидит в турели" % sender_id)
		return
	var t: Node3D = turrets[shooter.mounted_idx]
	var w: Dictionary = Game.TURRET
	var now := Time.get_ticks_msec()
	if now < t.reload_end_ms:
		if OS.is_debug_build():
			print("[TURRET] игрок %d: отклонено — идёт перезарядка" % sender_id)
		return
	if sender_id != multiplayer.get_unique_id():
		# Кулдаун и патроны — только для клиентов (хост уже прошёл эти
		# проверки локально в _turret_fire; его копия турели и есть серверная).
		if now < shooter.next_allowed_shot_ms:
			if OS.is_debug_build():
				print("[TURRET] игрок %d: отклонено — кулдаун" % sender_id)
			return
		if t.mag <= 0:
			if OS.is_debug_build():
				print("[TURRET] игрок %d: отклонено — нет патронов (сервер)" % sender_id)
			return
		t.mag -= 1
		t.barrel = int(t.barrel) ^ 1
		shooter.next_allowed_shot_ms = now + int(w["cooldown_ms"])
	var barrel: int = int(t.barrel)
	var muzzle: Vector3 = t.world_muzzle(barrel)
	# Зажим направления: рыск ≤ 0.25 рад от оси купола, тангаж — в конусе вокруг
	# ФАКТИЧЕСКОГО наклона стволов (BUILD-38: стволы поднимаются и опускаются).
	var t_yaw: float = float(t.aim_yaw())
	var t_pitch: float = float(t.aim_pitch())
	var d: Vector3 = dir.normalized()
	var dyaw: float = atan2(-d.x, -d.z)
	var dev: float = wrapf(dyaw - t_yaw, -PI, PI)
	var ny: float = t_yaw + clampf(dev, -0.25, 0.25)
	var pitch: float = clampf(asin(clampf(d.y, -1.0, 1.0)), t_pitch - 0.12, t_pitch + 0.12)
	d = Vector3(-sin(ny) * cos(pitch), sin(pitch), -cos(ny) * cos(pitch)).normalized()
	var range_m := float(w["range"])
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(muzzle, muzzle + d * range_m)
	query.collision_mask = 3  # мир (1) + хитбоксы (2)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	query.hit_from_inside = true
	query.exclude = [
		shooter.get_rid(),
		shooter.get_node("Hitbox").get_rid(),
	]
	var hit := space.intersect_ray(query)
	var end := muzzle + d * range_m
	var victim: Node = null
	if hit:
		end = hit.position
		victim = _resolve_victim(hit.collider, shooter)
	if victim != null:
		if OS.is_debug_build():
			print("[TURRET] сервер: игрок %d (турель %d, ствол %d) попал по игроку %d" % [sender_id, shooter.mounted_idx, barrel, str(victim.name).to_int()])
		_apply_damage(victim, shooter, float(w["damage"]))
	elif OS.is_debug_build():
		print("[TURRET] сервер: игрок %d (турель %d): мимо (луч: %s)" % [sender_id, shooter.mounted_idx, str(hit.collider if hit else "ничего")])
	_impact.rpc(end, victim != null)
	_spawn_impact(end)


func _spawn_impact(point: Vector3) -> void:
	var spark: Node3D = preload("res://scenes/fx/spark.tscn").instantiate()
	_fx_seq += 1
	spark.name = "SparkFX%d" % _fx_seq          # BUILD-36: имя вместо автоимени
	spark.position = point
	add_child(spark)


func _resolve_victim(collider: Object, shooter: Node) -> Node:
	var node := collider as Node
	if node == null:
		return null
	var candidate: Node = node
	if not candidate is CharacterBody3D:
		candidate = node.get_parent()
	if candidate == null or candidate == shooter:
		return null
	if candidate.is_in_group("hollows"):
		return candidate   # BUILD-33: пули бьют и «Полых людей»
	if players.values().has(candidate) and not candidate.dead:
		return candidate
	return null


## Урон игроку от «неигрового» источника — от «Полого человека» (BUILD-39).
## attacker_id = 0 — подпись «Полый человек».
func hurt_player_by_env(victim: Node, damage: float, attacker_id: int) -> void:
	if not multiplayer.is_server() or victim == null or victim.dead or victim.downed:
		return
	var vid := str(victim.name).to_int()
	victim.health -= damage
	if victim.health > 0.0:
		_event_damage.rpc(vid, damage, attacker_id, victim.health)
		_local_damage_feedback(vid, attacker_id, victim.health)
		_push_squad()
		return
	_down_player(vid, attacker_id)
func _apply_damage(victim: Node, attacker: Node, damage: float) -> void:
	var victim_id := str(victim.name).to_int()
	var attacker_id := str(attacker.name).to_int()
	# BUILD-33: «Полые люди» получают урон тем же путём, что и игроки.
	if victim.is_in_group("hollows"):
		victim.take_damage(damage, attacker_id)
		return
	if victim.downed:
		return
	# BUILD-34: игра кооперативная — по товарищу урон не проходит никогда.
	# (В служебных стрелковых сценариях стреляют друг в друга специально.)
	if not Game.solo_test_mode and victim_id != attacker_id:
		if OS.is_debug_build():
			print("[COOP] урон по товарищу (%d -> %d) отменён" % [attacker_id, victim_id])
		return
	victim.health -= damage
	if Game.smoke_test:
		_smoke_hits += 1
		print("[SMOKE] сервер: попадание #%d по игроку %d (урон %.0f, hp=%.0f)" % [_smoke_hits, victim_id, damage, victim.health])
	if victim.health <= 0.0:
		_down_player(victim_id, attacker_id)
	else:
		_event_damage.rpc(victim_id, damage, attacker_id, victim.health)
		if Game.smoke_test:
			print("[SMOKE][DBG] сервер отправил _event_damage жертве %d" % victim_id)
		_local_damage_feedback(victim_id, attacker_id, victim.health)
		_push_squad()
func _local_damage_feedback(victim_id: int, attacker_id: int, hp: float) -> void:
	var mine := multiplayer.get_unique_id()
	if victim_id == mine:
		Game.got_hit.emit()
		Game.health_changed.emit(hp)
	if attacker_id == mine:
		Game.dealt_hit.emit()


func _local_death_feedback(victim_id: int, attacker_id: int) -> void:
	var mine := multiplayer.get_unique_id()
	Game.scores_changed.emit(scores.duplicate(), mine)
	if victim_id == mine:
		# BUILD-29/32: показываем, кто убил.
		Game.died.emit(player_label(attacker_id))


# ---------------------------------------------------------------- события для клиентов

@rpc("authority", "call_remote", "reliable")
func _event_damage(victim_id: int, _damage: float, attacker_id: int, health_left: float) -> void:
	if Game.smoke_test:
		print("[SMOKE][DBG] получен _event_damage: жертва=%d, я=%d, коннектов got_hit=%d, арена #%d" % [victim_id, multiplayer.get_unique_id(), Game.got_hit.get_connections().size(), get_instance_id()])
	var p: Node = players.get(victim_id)
	if p != null:
		p.health = health_left
	var mine := multiplayer.get_unique_id()
	if victim_id == mine:
		Game.got_hit.emit()
		Game.health_changed.emit(health_left)
	if attacker_id == mine:
		Game.dealt_hit.emit()


@rpc("authority", "call_remote", "reliable")
func _event_downed(victim_id: int, attacker_id: int, bleedout: float) -> void:
	var p: Node = players.get(victim_id)
	if p != null:
		p.health = 0.0
		p.downed = true
		# Раненый вываливается из турели (сиденье освобождается у всех нод).
		if p.mounted_idx >= 0 and p.mounted_idx < turrets.size():
			turrets[p.mounted_idx].occupant_id = -1
		if p.has_method("_apply_unmount_cleanup"):
			p._apply_unmount_cleanup()
	var mine := multiplayer.get_unique_id()
	if victim_id == mine:
		Game.died.emit(player_label(attacker_id))
		Game.downed.emit(bleedout)


@rpc("authority", "call_remote", "unreliable")
func _impact(point: Vector3, _hit_something: bool) -> void:
	_spawn_impact(point)




# ---------------------------------------------------------------- проверка бега (sprinttest, BUILD-35)


## Удержать/отпустить клавишу на ЭТОЙ ноде — событие идёт через полный
## конвейер ввода (как keytest для F).
func _hold_key(keycode: int, pressed: bool) -> void:
	var ev := InputEventKey.new()
	ev.keycode = keycode
	ev.physical_keycode = keycode
	ev.pressed = pressed
	ev.echo = false
	Input.parse_input_event(ev)


## Пик горизонтальной скорости за четверть секунды (замер не зависит от того,
## успел ли игрок куда-то добежать).
func _peak_speed(p: Node) -> float:
	var peak := 0.0
	for i in 8:
		var v: Vector3 = p.velocity
		peak = maxf(peak, Vector2(v.x, v.z).length())
		await get_tree().create_timer(0.04).timeout
	return peak


## Сценарий клиента: шаг без Shift, затем бег с Shift — настоящими клавишами.
func _sprint_test_client() -> void:
	print("[SPRINTTEST] клиент: меряю скорость шага и бега настоящими клавишами")
	_defense_running = false
	var me: Node = players.get(multiplayer.get_unique_id())
	if me == null:
		print("[SPRINTTEST_CLIENT_FAIL] клиент: мой игрок не найден")
		get_tree().quit(1)
		return
	# Чистая полоса западного плато: бежим на восток вдоль z=34.
	me.global_position = Vector3(-28.0, 1.2, 34.0)
	me.rotation.y = -PI / 2.0
	me.reset_net_targets()
	await get_tree().create_timer(1.2).timeout          # приземлиться и устояться
	_hold_key(KEY_W, true)
	await get_tree().create_timer(0.6).timeout
	var walk: float = await _peak_speed(me)
	_hold_key(KEY_SHIFT, true)
	await get_tree().create_timer(0.2).timeout
	print("[SPRINTTEST] клиент: клавиши shift=%s w=%s, на полу=%s, вектор=%s, прицел=%s, присед=%s" % [
		str(Input.is_key_pressed(KEY_SHIFT)), str(Input.is_key_pressed(KEY_W)),
		str(me.is_on_floor()), str(Input.get_vector("move_left", "move_right", "move_forward", "move_back")),
		str(me._ads), str(Input.is_key_pressed(KEY_CTRL))])
	await get_tree().create_timer(0.6).timeout
	var run: float = await _peak_speed(me)
	var sprint_w: float = float(me._sprint_w)
	var fov: float = float(me.camera.fov)
	_hold_key(KEY_SHIFT, false)
	_hold_key(KEY_W, false)
	print("[SPRINTTEST] клиент: шаг=%.2f м/с, бег=%.2f м/с, вес бега=%.2f, FOV=%.1f°" % [walk, run, sprint_w, fov])
	var ok: bool = run > 8.5 and run > walk + 2.5 and sprint_w > 0.8 and fov > 82.0
	if ok:
		print("[SPRINTTEST_CLIENT_OK] бег по Shift: %.2f м/с против шага %.2f м/с" % [run, walk])
	else:
		print("[SPRINTTEST_CLIENT_FAIL] шаг=%.2f, бег=%.2f, вес=%.2f, FOV=%.1f" % [walk, run, sprint_w, fov])
	await get_tree().create_timer(1.5).timeout
	get_tree().quit(0 if ok else 1)


## Сценарий хоста: признак бега должен доехать в пакетах состояния клиента.
func _sprint_test_host() -> void:
	_defense_running = false
	var t := 0.0
	while t < 25.0 and players.size() < Game.autostart_peers + 1:
		await get_tree().create_timer(0.5).timeout
		t += 0.5
	var ids := players.keys()
	ids.sort()
	var cid := int(ids[1]) if ids.size() > 1 else 0
	var seen_walk := false
	var seen_run := false
	var run_w := 0.0
	for i in 300:
		var p: Node = players.get(cid)
		if p != null:
			if bool(p._remote_moving):
				seen_walk = true
			if bool(p._remote_run):
				seen_run = true
				run_w = maxf(run_w, float(p._remote_run_w))
		if seen_run and seen_walk:
			break
		await get_tree().create_timer(0.1).timeout
	print("[SPRINTTEST] сервер: шаг клиента виден=%s, бег виден=%s (вес бега у товарища %.2f)" % [str(seen_walk), str(seen_run), run_w])
	if seen_walk and seen_run:
		print("[SPRINTTEST_OK] бег синхронизирован: товарищ видит и шаг, и бег")
	else:
		print("[SPRINTTEST_FAIL] шаг=%s, бег=%s" % [str(seen_walk), str(seen_run)])
	await get_tree().create_timer(1.0).timeout
	get_tree().quit(0 if (seen_walk and seen_run) else 1)


func _spawn_hollow_for_test(pos: Vector3) -> Node3D:
	_hollow_seed += 1
	var h: Node3D = load(HOLLOW_SCENE).instantiate()
	h.name = "Hollow%d" % _hollow_seed     # имя+рассылка как у боевого спавна:
	add_child(h)                            # иначе клиент сыпал «Node not found»
	var aim: Vector3 = Map.BREACH_N if pos.z > 0.0 else Map.BREACH_S
	h.setup(pos, aim, _hollow_seed + 4242)
	_event_hollow.rpc(_hollow_seed, pos, aim)
	_wave_alive += 1
	return h


# ---------------------------------------------------------------- проверка подъёма (revivet, BUILD-34)

var _rt_checks := 0
var _rt_fails := 0


func _rt_ok(cond: bool, label: String) -> void:
	_rt_checks += 1
	if cond:
		print("[REVIVE] OK   %s" % label)
	else:
		_rt_fails += 1
		print("[REVIVE] ФЕЙЛ %s" % label)


## Сценарий хоста: ранение от «Полого человека», беспомощность, подъём
## товарищем клавишей E и (второй случай) самостоятельный возврат по таймауту.
func _revive_test_host() -> void:
	print("[REVIVE] --- серверный сценарий: ранение и подъём ---")
	# Ждём, пока соберутся все игроки (в тесте — хост и двое клиентов).
	var t := 0.0
	while t < 25.0 and players.size() < Game.autostart_peers + 1:
		await get_tree().create_timer(0.5).timeout
		t += 0.5
	_rt_ok(players.size() >= 3, "все игроки на карте (%d)" % players.size())
	# Волны в этом сценарии не нужны: проверяем именно раненых.
	_defense_running = false
	var ids := players.keys()
	ids.sort()
	var victim: Node = players[int(ids[1])]
	var medic: Node = players[int(ids[2])]
	var victim_id := int(victim.name)
	# 1) Ранение: урон от «Полого человека» (attacker_id = 0).
	hurt_player_by_env(victim, 200.0, 0)
	await get_tree().create_timer(0.4).timeout
	_rt_ok(victim.downed and victim.health <= 0.0, "игрок %d ранен и лежит (hp=%.0f)" % [victim_id, victim.health])
	_rt_ok(not victim.dead, "после ранения он не «умер» — его можно поднять")
	_rt_ok(int(_squad_size_downed()) == 1, "раненый виден в сводке отряда")
	# 2) Раненый беспомощен: ходьба и стрельба отсекаются на сервере.
	var moved_before: Vector3 = victim.global_position
	victim.velocity = Vector3(0, 0, 0)
	get_tree().create_timer(0.6).timeout.connect(func() -> void:
		victim.velocity = Vector3(6, 0, 6)
	)
	await get_tree().create_timer(1.2).timeout
	_rt_ok(victim.global_position.distance_to(moved_before) < 0.5, "раненый не может уйти с места")
	# 3) Подъём товарищем: клиент-«медик» подходит и жмёт E (настоящий RPC!).
	var t_rev := 0.0
	while t_rev < 18.0 and victim.downed:
		await get_tree().create_timer(0.4).timeout
		t_rev += 0.4
	_rt_ok(not victim.downed and victim.health >= Game.REVIVE_HP - 1.0,
		"товарищ поднял раненого клавишей E (hp=%.0f за %.1f с)" % [victim.health, t_rev])
	# 4) Второй случай: никто не подошёл — раненый сам возвращается на пост.
	hurt_player_by_env(victim, 200.0, 0)
	await get_tree().create_timer(0.4).timeout
	_rt_ok(victim.downed, "игрок снова ранен (проверяем авто-возврат)")
	var post_before: float = victim.global_position.y
	# Ускоряем ожидание: подкручиваем таймер раненого (в бою это 25 с).
	_downed[victim_id] = 1.2
	await get_tree().create_timer(2.0).timeout
	if is_instance_valid(victim):
		_rt_ok(not victim.downed and victim.health >= 99.0,
			"без помощи он сам вернулся на пост (hp=%.0f, y было %.1f)" % [victim.health, post_before])
	else:
		# Клиент вышел из матча — но сервер уже поднял его бойца на пост.
		print("[REVIVE] игрок %d вернулся на пост сам (связь с клиентом закрылась)" % victim_id)
	# 5) Товарища поднимать нельзя: подъём только для раненых.
	var r: Node = players[int(ids[2])]
	request_revive(int(r.name))
	await get_tree().create_timer(0.4).timeout
	_rt_ok(not r.downed and r.health >= 99.0, "здорового игрока поднять нельзя (он и так в строю)")
	print("[REVIVE] итог: проверок=%d, провалов=%d" % [_rt_checks, _rt_fails])
	if _rt_fails == 0:
		print("[REVIVE_OK] ранение и подъём товарищем работают, авто-возврат на пост работает")
	else:
		print("[REVIVE_FAIL] проверок=%d, провалов=%d" % [_rt_checks, _rt_fails])
	# Даём клиентам время дописать их отчёты, и только потом закрываем матч.
	await get_tree().create_timer(8.0).timeout
	get_tree().quit()


func _squad_size_downed() -> int:
	var n := 0
	for m in squad_state():
		if bool(m.get("downed", false)):
			n += 1
	return n


## Клиент: видит ранение в сводке и получает событие «поднят». А если сам не ранен —
## идёт к раненому товарищу и держит E (реальный запрос request_revive на сервер).
func _revive_test_client() -> void:
	print("[REVIVE] --- клиент %d: смотрю сводку отряда ---" % multiplayer.get_unique_id())
	var me := multiplayer.get_unique_id()
	# Внимание: лямбды в GDScript захватывают локальные переменные ПО ЗНАЧЕНИЮ,
	# поэтому наблюдаем через словарь (ссылочный тип) — иначе флаги не сохранятся.
	var seen := {"downed": false, "revived": false, "requested": false}
	Game.squad_changed.connect(func(members: Array) -> void:
		var any_down := false
		for m in members:
			if bool(m.get("downed", false)):
				seen["downed"] = true
				any_down = true
		# Сводка приходит и без раненых: если раненый был, а теперь все на ногах — подъём.
		if bool(seen["downed"]) and not any_down:
			seen["revived"] = true
	)
	Game.revived.connect(func() -> void:
		seen["revived"] = true
	)
	Game.downed.connect(func(_b: float) -> void:
		seen["downed"] = true
	)
	var t := 0.0
	while t < 30.0 and not (bool(seen["downed"]) and bool(seen["revived"])):
		await get_tree().create_timer(0.5).timeout
		t += 0.5
		# Если я на ногах, а кто-то рядом лежит — подхожу и держу E (реальный RPC).
		var my_node: Node = players.get(me)
		if my_node == null or my_node.downed:
			continue
		for m in squad_state():
			if not bool(m.get("downed", false)):
				continue
			var target: Node = players.get(int(m.get("id", 0)))
			if target == null:
				continue
			my_node.global_position = target.global_position + Vector3(1.0, 0.0, 0.0)
			my_node.velocity = Vector3.ZERO
			request_revive.rpc_id(1, int(m.get("id", 0)))
			seen["requested"] = true
			break
	print("[REVIVE] клиент %d: ранение видел=%s, подъём видел=%s" % [me, str(seen["downed"]), str(seen["revived"])])
	if bool(seen["downed"]) and bool(seen["revived"]):
		if bool(seen["requested"]):
			print("[REVIVE_MEDIC_OK] клиент %d: сам поднял товарища клавишей E (реальный RPC)" % me)
		print("[REVIVE_CLIENT_OK] клиент %d: ранение и подъём дошли до клиента" % me)
	else:
		print("[REVIVE_CLIENT_FAIL] клиент %d: ранение=%s, подъём=%s" % [me, str(seen["downed"]), str(seen["revived"])])
	# Отчёт дописан, но из матча не выходим: серверный сценарий ещё проверяет
	# возврат на пост, и боец этого клиента должен оставаться на карте.
	await get_tree().create_timer(20.0).timeout
	get_tree().quit()



# ---------------------------------------------------------------- берега (BUILD-34)

## Берег игрока: +1 — северный пост, -1 — южный. Раскладываем по двое:
## одна половина карты на одну пару глаз — как в ущелье из фильма.
func _assign_side(id: int) -> int:
	if sides.has(id):
		return int(sides[id])
	var north := 0
	var south := 0
	for other in sides.keys():
		if int(sides[other]) > 0:
			north += 1
		else:
			south += 1
	var side := 1 if north <= south else -1
	sides[id] = side
	return side


func side_of(id: int) -> int:
	return int(sides.get(id, 1))


## Название поста — для объявлений и подписей в HUD.
func side_name(side: int) -> String:
	return "Северный пост" if side > 0 else "Южный пост"


## Точки берега: для возврата на пост и подъёма.
func _side_spawn_points(side: int) -> Array:
	if Game.solo_test_mode:
		return Map.SPAWN_TEST      # служебные сценарии — общая площадка
	return Map.SPAWN_NORTH if side > 0 else Map.SPAWN_SOUTH


## Имя игрока для экранов: нумерация по возрастанию peer id.
func player_label(id: int) -> String:
	if id <= 0:
		return "Полый человек"
	return "Игрок %d" % _player_num(id)


func _player_num(id: int) -> int:
	var ids := players.keys()
	ids.sort()
	for i in ids.size():
		if int(ids[i]) == id:
			return i + 1
	return 0


# ---------------------------------------------------------------- раненые и подъём (BUILD-34)

## Игрок падает раненым: он не может ходить и стрелять; товарищ поднимает
## клавишей E (держится REVIVE_TIME), иначе через BLEEDOUT_TIME раненый сам
## возвращается на свой пост.
func _down_player(victim_id: int, attacker_id: int) -> void:
	var victim: Node = players.get(victim_id)
	if victim == null:
		return
	victim.health = 0.0
	victim.downed = true
	if victim.mounted_idx >= 0 and victim.mounted_idx < turrets.size():
		turrets[victim.mounted_idx].occupant_id = -1
	if victim.has_method("_apply_unmount_cleanup"):
		victim._apply_unmount_cleanup()
	_downed[victim_id] = Game.BLEEDOUT_TIME
	if attacker_id > 0 and attacker_id != victim_id:
		scores[attacker_id] = int(scores.get(attacker_id, 0)) + 1
	_event_downed.rpc(victim_id, attacker_id, Game.BLEEDOUT_TIME)
	if victim_id == multiplayer.get_unique_id():
		Game.died.emit(player_label(attacker_id))
		Game.downed.emit(Game.BLEEDOUT_TIME)
	Game.announce.emit("%s ранен — поднимите товарища (E)!" % player_label(victim_id))
	_push_squad()
	if OS.is_debug_build():
		print("[COOP] игрок %d ранен (источник %d), %s" % [victim_id, attacker_id, side_name(side_of(victim_id))])


## Тик раненых (только сервер): время вышло — игрок сам возвращается на пост.
func _tick_downed(delta: float) -> void:
	if _downed.is_empty():
		return
	for key in _downed.keys():
		var id := int(key)
		_downed[key] = float(_downed[key]) - delta
		if float(_downed[key]) <= 0.0:
			_downed.erase(key)
			if OS.is_debug_build():
				print("[COOP] игрок %d не дождался подъёма — возвращается на пост" % id)
			Game.announce.emit("%s очнулся на посту" % player_label(id))
			_respawn(id)
	_push_squad()


## Запрос подъёма (клиент -> сервер): клавиша E рядом с раненым товарищем.
@rpc("any_peer", "call_remote", "reliable")
func request_revive(target_id: int) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender == 0:
		sender = multiplayer.get_unique_id()
	_try_start_revive(sender, target_id)


## Проверка «можно ли начать подъём»: кто поднимает, кого, на каком расстоянии.
## Отдельная функция — чтобы её же дёргал headless-сценарий (-- revivet).
func _try_start_revive(sender: int, target_id: int) -> void:
	var reviver: Node = players.get(sender)
	var target: Node = players.get(target_id)
	if reviver == null or target == null:
		return
	if reviver.dead or reviver.downed or not target.downed:
		return
	if reviver.global_position.distance_to(target.global_position) > Game.REVIVE_RANGE:
		return
	if not _revive_job.is_empty():
		return
	_revive_job = {"reviver": sender, "target": target_id}
	_revive_job_left = Game.REVIVE_TIME
	if OS.is_debug_build():
		print("[COOP] игрок %d поднимает игрока %d (%.1f с)" % [sender, target_id, Game.REVIVE_TIME])


## Тик подъёма (только сервер): держимся рядом — поднимаем, разошлись — отмена.
func _tick_revive(delta: float) -> void:
	if _revive_job.is_empty():
		return
	var reviver: Node = players.get(int(_revive_job["reviver"]))
	var target: Node = players.get(int(_revive_job["target"]))
	var ok: bool = reviver != null and target != null and not reviver.downed and target.downed \
		and not reviver.dead and reviver.global_position.distance_to(target.global_position) <= Game.REVIVE_RANGE + 0.6
	if not ok:
		_revive_job = {}
		_revive_job_left = 0.0
		_push_revive_progress(0.0, "")
		return
	_revive_job_left -= delta
	var k := clampf(1.0 - _revive_job_left / Game.REVIVE_TIME, 0.0, 1.0)
	_push_revive_progress(k, player_label(int(_revive_job["reviver"])))
	if _revive_job_left <= 0.0:
		var t := int(_revive_job["target"])
		var r := int(_revive_job["reviver"])
		_revive_job = {}
		_revive_job_left = 0.0
		_revive(t, r)


## Подъём состоялся: товарищ снова в строю.
func _revive(target_id: int, reviver_id: int) -> void:
	var target: Node = players.get(target_id)
	if target == null:
		return
	_downed.erase(target_id)
	target.health = Game.REVIVE_HP
	target.downed = false
	target.dead = false
	target.reset_net_targets()
	_event_revived.rpc(target_id, reviver_id, Game.REVIVE_HP)
	_push_squad()
	if target_id == multiplayer.get_unique_id():
		Game.revived.emit()
		Game.health_changed.emit(Game.REVIVE_HP)
	Game.announce.emit("%s поднят (%s)" % [player_label(target_id), player_label(reviver_id)])
	_push_revive_progress(0.0, "")
	_push_squad()
	if OS.is_debug_build():
		print("[COOP] игрок %d поднят игроком %d (hp %.0f)" % [target_id, reviver_id, Game.REVIVE_HP])


@rpc("authority", "call_remote", "reliable")
func _event_revived(target_id: int, _reviver_id: int, hp: float) -> void:
	var p: Node = players.get(target_id)
	if p == null:
		return
	p.health = hp
	p.downed = false
	p.dead = false
	p.reset_net_targets()
	if target_id == multiplayer.get_unique_id():
		Game.revived.emit()
		Game.health_changed.emit(hp)


@rpc("authority", "call_remote", "unreliable")
func _event_revive_progress(value: float, label: String) -> void:
	Game.revive_progress.emit(value, label)


func _push_revive_progress(value: float, label: String) -> void:
	_event_revive_progress.rpc(value, label)
	Game.revive_progress.emit(value, label)


# ---------------------------------------------------------------- отряд (BUILD-34)

## Состояние отряда для HUD: кто на каком посту, у кого сколько HP, кто ранен.
func squad_state() -> Array:
	var ids := players.keys()
	ids.sort()
	var out: Array = []
	for i in ids.size():
		var id := int(ids[i])
		var p: Node = players[id]
		if p == null:
			continue
		out.append({
			"id": id, "num": i + 1, "side": side_of(id),
			"hp": float(p.health), "downed": bool(p.downed), "mounted": int(p.mounted_idx),
		})
	return out


func _push_squad() -> void:
	var st := squad_state()
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		_event_squad.rpc(st)
	Game.squad_changed.emit(st)


@rpc("authority", "call_remote", "reliable")
func _event_squad(state: Array) -> void:
	Game.squad_changed.emit(state)


# ---------------------------------------------------------------- кооп-оборона

## Точка спавна в обороне: index 0,2 — север, 1,3 — юг; лицом к ущелью.
func _defense_spawn_point(index: int) -> Array:
	var north := index % 2 == 0
	var row := int(index / 2)
	var pts: Array = Map.SPAWN_NORTH if north else Map.SPAWN_SOUTH
	var p: Vector3 = pts[row % pts.size()]
	var yaw := 0.0 if north else PI   # смотрим в сторону обрыва
	return [p, yaw]


func _start_defense() -> void:
	_defense_running = true
	_wave = 0
	_kills = 0
	_perimeter = 100.0
	_wave_alive = 0
	_wave_pending = 0
	Game.announce.emit("ОБОРОНА ПЕРИМЕТРА: из ущелья лезут Полые люди. Держим кромку!")
	_push_defense_hud()
	get_tree().create_timer(6.0).timeout.connect(_next_wave)


func _defense_wave_total() -> int:
	return 1 if Game.defense_test else DEFENSE_WAVES.size()


func _next_wave() -> void:
	if not multiplayer.is_server() or _match_over or not _defense_running:
		return
	_wave += 1
	if _wave > _defense_wave_total():
		_end_defense(true)
		return
	var count := 2 if Game.defense_test else int(DEFENSE_WAVES[_wave - 1])
	_wave_pending = count
	_wave_alive = 0
	Game.announce.emit("Волна %d из %d — полых: %d" % [_wave, _defense_wave_total(), count])
	_push_defense_hud()
	for i in count:
		get_tree().create_timer(WAVE_SPAWN_GAP * float(i)).timeout.connect(_spawn_wave_hollow.bind(i))


## Появление полого: он лезет из тумана у стены ущелья своего берега.
func _spawn_wave_hollow(idx: int) -> void:
	if not multiplayer.is_server() or _match_over or not _defense_running or _wave_pending <= 0:
		return
	_wave_pending -= 1
	_hollow_seed += 1
	var side := 1.0 if idx % 2 == 0 else -1.0
	var r := RandomNumberGenerator.new()
	r.seed = _hollow_seed * 7919 + Time.get_ticks_msec()
	var x := r.randf_range(-22.0, 22.0)
	var start := Vector3(x, Map.GORGE_FLOOR_Y + 0.9, side * (Map.RIM_Z - 0.9))
	var aim: Vector3 = Map.BREACH_N if side > 0.0 else Map.BREACH_S
	var h: Node3D = load(HOLLOW_SCENE).instantiate()
	h.name = "Hollow%d" % _hollow_seed
	add_child(h)
	h.setup(start, aim, _hollow_seed)
	_event_hollow.rpc(_hollow_seed, start, aim)
	_wave_alive += 1
	_push_defense_hud()
	if OS.is_debug_build():
		print("[DEFENSE] полый %s вышел из ущелья в %s (цель %s)" % [h.name, str(start), str(aim)])


## Клиент создаёт свою копию существа: дальше позиции идут 15 Гц из hollow.gd.
@rpc("authority", "call_remote", "reliable")
func _event_hollow(hid: int, start: Vector3, aim: Vector3) -> void:
	if multiplayer.is_server():
		return
	var h: Node3D = load(HOLLOW_SCENE).instantiate()
	h.name = "Hollow%d" % hid
	add_child(h)
	h.setup(start, aim, hid)


func hollows() -> Array:
	return get_tree().get_nodes_in_group("hollows")


func hollow_died(h: Node) -> void:
	if not multiplayer.is_server():
		return
	_kills += 1
	if h != null and is_instance_valid(h) and h.phase != 2:
		_wave_alive = maxi(_wave_alive - 1, 0)
	_push_defense_hud()
	_check_wave_cleared()


## Полый дошёл до точки прорыва: периметр теряет прочность.
func hollow_breach(h: Node) -> void:
	if not multiplayer.is_server():
		return
	_wave_alive = maxi(_wave_alive - 1, 0)
	_perimeter = maxf(_perimeter - BREACH_DAMAGE, 0.0)
	Game.announce.emit("Полый человек прорвался через периметр! Прочность: %d %%" % int(_perimeter))
	_push_defense_hud()
	if _perimeter <= 0.0:
		_end_defense(false)
		return
	_check_wave_cleared()


func _check_wave_cleared() -> void:
	if not _defense_running or _match_over:
		return
	if _wave_alive > 0 or _wave_pending > 0:
		return
	Game.announce.emit("Волна %d отбита!" % _wave)
	get_tree().create_timer(2.0 if Game.defense_test else WAVE_PAUSE).timeout.connect(_next_wave)


## Удар полого по игроку (вызывает монстр на сервере).
func hollow_hit_player(p: Node, dmg: float, _h: Node) -> void:
	hurt_player_by_env(p, dmg, 0)


## BUILD-34: ближайший раненый в радиусе — для подсказки «E — поднять» и подъёма.
func nearest_downed_within(pos: Vector3, radius: float) -> Node:
	var best: Node = null
	var best_d := radius
	for id in players.keys():
		var p: Node = players[id]
		if p == null or not p.downed:
			continue
		var d: float = p.global_position.distance_to(pos)
		if d <= best_d:
			best_d = d
			best = p
	return best


func nearest_player_within(pos: Vector3, radius: float) -> Node:
	var best: Node = null
	var best_d := radius
	for id in players.keys():
		var p: Node = players[id]
		if p == null or p.dead:
			continue
		var d: float = p.global_position.distance_to(pos)
		if d <= best_d:
			best_d = d
			best = p
	return best


func _end_defense(win: bool) -> void:
	if _match_over:
		return
	_match_over = true
	_defense_running = false
	var label := "ПЕРИМЕТР УДЕРЖАН\nВсе волны отбиты. Полых уничтожено: %d. Периметр: %d %%" % [_kills, int(_perimeter)]
	if not win:
		label = "ПЕРИМЕТР ПРОРВАН\nПолые люди пробились к башне. Уничтожено: %d" % _kills
	Game.match_over.emit(label)
	_event_defense_over.rpc(win, _kills, int(_perimeter))


@rpc("authority", "call_remote", "reliable")
func _event_defense_over(win: bool, kills: int, perimeter: int) -> void:
	if win:
		Game.match_over.emit("ПЕРИМЕТР УДЕРЖАН\nВсе волны отбиты. Полых уничтожено: %d. Периметр: %d %%" % [kills, perimeter])
	else:
		Game.match_over.emit("ПЕРИМЕТР ПРОРВАН\nПолые люди пробились к башне. Уничтожено: %d" % kills)


func _push_defense_hud() -> void:
	var total := _defense_wave_total()
	var alive := _wave_alive + _wave_pending
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		_event_defense.rpc(_wave, total, alive, _kills, _perimeter)
	_defense_hud_local(_wave, total, alive, _kills, _perimeter)


@rpc("authority", "call_remote", "reliable")
func _event_defense(wave: int, total: int, alive: int, kills: int, perimeter: float) -> void:
	_defense_hud_local(wave, total, alive, kills, perimeter)


func _defense_hud_local(wave: int, total: int, alive: int, kills: int, perimeter: float) -> void:
	_wave = wave
	_game_waves_total = total
	_perimeter = perimeter
	Game.defense_changed.emit(wave, total, alive, kills, perimeter)


# ---------------------------------------------------------------- автотурели

func _nearest_hollow(pos: Vector3, radius: float) -> Node:
	var best: Node = null
	var best_d := radius
	for h in hollows():
		var hn: Node3D = h
		if not is_instance_valid(hn) or hn.dead:
			continue
		var d: float = hn.global_position.distance_to(pos)
		if d <= best_d:
			best_d = d
			best = hn
	return best


## Автотурель: сама доворачивает купол и бьёт по «Полым людям». Работает, когда
## в ней никто не сидит (за ручную установку отвечает игрок).
func _auto_turrets_tick(_delta: float) -> void:
	if not Game.defense_mode or not _turret_auto_enabled:
		return
	for t in turrets:
		if t == null or not is_instance_valid(t) or t.occupant_id != -1:
			continue
		var target := _nearest_hollow(t.global_position, TURRET_AUTO_RANGE)
		if target == null:
			t._pitch_target = 0.0     # BUILD-38: без цели стволы ложатся по нулю
			continue
		var to: Vector3 = target.global_position - t.global_position
		t._yaw_target = atan2(-to.x, -to.z)
		# BUILD-38: автотурель поднимает стволы на цель (вниз — в ущелье).
		var aim: Vector3 = target.global_position + Vector3(0.0, 1.1, 0.0) - t.global_position
		var horiz := Vector2(aim.x, aim.z).length()
		t._pitch_target = clampf(atan2(aim.y, maxf(horiz, 0.001)), t.pitch_min(), t.pitch_max())
		if absf(wrapf(t._yaw_target - t.aim_yaw(), -PI, PI)) > 0.14:
			continue   # купол ещё доворачивается
		var now := Time.get_ticks_msec()
		if now < int(t.auto_next_shot_ms) or now < int(t.reload_end_ms):
			continue
		if int(t.mag) <= 0:
			t.start_auto_reload()
			continue
		t.auto_next_shot_ms = now + TURRET_AUTO_SHOT_MS
		t.mag -= 1
		t.barrel = int(t.barrel) ^ 1
		_fire_auto_turret(t, target)


func _fire_auto_turret(t: Node3D, target: Node3D) -> void:
	var barrel: int = int(t.barrel)
	var muzzle: Vector3 = t.world_muzzle(barrel)
	var aim: Vector3 = target.global_position + Vector3(0.0, 1.1, 0.0)
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(muzzle, aim)
	query.collision_mask = 3
	query.collide_with_areas = true
	query.collide_with_bodies = true
	query.hit_from_inside = true
	var hit := space.intersect_ray(query)
	var end := aim
	var victim: Node = null
	if hit:
		end = hit.position
		victim = _resolve_victim(hit.collider, t)
	if victim != null and victim.is_in_group("hollows"):
		victim.take_damage(TURRET_AUTO_DAMAGE, 0)
	t.fire_kick_local(barrel)
	# BUILD-35: отдача ствола у остальных нод — через арену (у турели имя
	# динамическое и у клиента путь Arena/@Node3D@N не находился).
	_event_turret_kick.rpc(int(t.turret_idx), barrel)
	_impact.rpc(end, victim != null)
	_spawn_impact(end)


## Отдача ствола автотурели у всех, кроме сервера (сервер уже дёрнул локально).
@rpc("authority", "call_remote", "unreliable")
func _event_turret_kick(turret_idx: int, barrel_idx: int) -> void:
	if turret_idx < 0 or turret_idx >= turrets.size():
		return
	var t: Node3D = turrets[turret_idx]
	if t == null or not is_instance_valid(t):
		return
	t.fire_kick(barrel_idx)
	_auto_kick_seen += 1
	if _auto_kick_seen == 1:
		# Строка-маркер: событие автотурели дошло до этой ноды через АРЕНУ
		# (раньше путь «Arena/@Node3D@N» у клиента не находился).
		print("[TURRET] нода %d приняла отдачу автотурели %d по событию арены" % [multiplayer.get_unique_id(), turret_idx])


# ---------------------------------------------------------------- респаун

func _start_respawn(victim_id: int) -> void:
	get_tree().create_timer(RESPAWN_TIME).timeout.connect(func() -> void:
		_respawn(victim_id)
	)


func _respawn(victim_id: int) -> void:
	if _match_over or not multiplayer.is_server():
		return
	var p: Node = players.get(victim_id)
	if p == null:
		return
	var pts := _side_spawn_points(side_of(victim_id))
	var idx := int(_spawn_idx.get(victim_id, 0))
	p.position = pts[idx % pts.size()]
	p.velocity = Vector3.ZERO
	p.health = 100.0
	p.dead = false
	p.downed = false
	_downed.erase(victim_id)
	if p.has_method("_apply_unmount_cleanup"):
		p._apply_unmount_cleanup()
	p.reset_net_targets()
	_event_respawn.rpc(victim_id, p.position, p.rotation.y)
	if victim_id == multiplayer.get_unique_id():
		Game.respawned.emit()
		Game.health_changed.emit(100.0)
	_push_squad()


@rpc("authority", "call_remote", "reliable")
func _event_respawn(id: int, pos: Vector3, yaw: float) -> void:
	var p: Node = players.get(id)
	if p == null:
		return
	p.position = pos
	p.rotation.y = yaw
	p.health = 100.0
	p.dead = false
	p.downed = false
	if p.has_method("_apply_unmount_cleanup"):
		p._apply_unmount_cleanup()
	p.reset_net_targets()
	if id == multiplayer.get_unique_id():
		Game.respawned.emit()
		Game.health_changed.emit(100.0)
## Состояние сценария турели (BUILD-30): кто ведомый, чем закончилось.
var _turret_client_id := 0
var _turret_ok := true
var _turret_star_id := 0  # клиент, которого ведёт сценарий (знает сам сервер)
var _turret_mount_seen := false  # BUILD-39: клиент увидел своё монтирование


@rpc("authority", "call_remote", "reliable")
func test_turret_star(id: int) -> void:
	if not (Game.turret_test or Game.key_test or Game.death_test):
		return
	_turret_star_id = id


func _turret_fail(msg: String) -> void:
	_turret_ok = false
	print("[TURRET_FAIL] " + msg)


## Хост ведёт сценарий: посадка, чужая попытка сесть (занято), три выстрела по
## клиенту (чередование стволов, урон), выход, посадка клиента в освобождённую.
## Геометрия (BUILD-39): северная турель стоит вплотную к кромке (0.3 м до
## обрыва), поэтому и посадка, и огневая линия — на плато ВНУТРИ берега.
## Стволы стреляют с зажимом ±0.25 рад от оси купола: сидящий разворачивается
## внутрь (рыск PI), мишень встаёт в створе (0.35, 0, +3.0) от турели.
func _turret_test_host() -> void:
	for k in players.keys():
		if int(k) != 1:
			_turret_client_id = int(k)
			break
	if _turret_client_id == 0:
		_turret_fail("сервер: нет второго игрока (ключи=%s)" % str(players.keys()))
		return
	_turret_star_id = _turret_client_id
	test_turret_star.rpc(_turret_client_id)
	var host: Node = players[1]
	var turret: Node3D = turrets[0]
	var tpos: Vector3 = turret.position
	# BUILD-39: турель стоит вплотную к обрыву, поэтому и посадка, и огневая
	# линия — ВНУТРИ берега (за кромкой уже пропасть). Турель наводится внутрь
	# (рыск PI — нос в сторону плато), мишень в створе стволов.
	var near := tpos + Vector3(0.4, 0.0, 1.4)     # рядом: < 2.6 м (посадка)
	var firing_line := tpos + Vector3(0.35, 0.0, 3.0)   # в створе стволов: огонь

	# Подносим игроков к турели (хост — напрямую, клиент — test-телепортом).
	get_tree().create_timer(0.3).timeout.connect(func() -> void:
		host.position = tpos + Vector3(0.0, 0.0, 1.6)
		host.rotation.y = 0.0
		test_set_pos.rpc(_turret_client_id, near, 0.0)
	)

	# Хост садится.
	get_tree().create_timer(1.0).timeout.connect(func() -> void:
		try_mount_player(1, 0)
		if turret.is_occupied() and int(turret.occupant_id) == 1 and host.mounted_idx == 0:
			print("[TURRET] сервер: хост в турели (сиденье занято id=1)")
		else:
			_turret_fail("хост не сел: occupant=%s, mounted=%s" % [str(turret.occupant_id), str(host.mounted_idx)])
	)

	# BUILD-38: стволы ПОДНИМАЮТСЯ вместе со взглядом сидящего и опускаются
	# обратно, когда он смотрит в горизонт (до этого наклон не менялся вообще).
	get_tree().create_timer(1.3).timeout.connect(func() -> void:
		host.head.rotation.x = 0.55
	)
	get_tree().create_timer(1.7).timeout.connect(func() -> void:
		var up_now := float(turret.aim_pitch())
		if up_now > 0.3:
			print("[TURRET] сервер: стволы поднялись за взглядом сидящего (наклон=%.2f рад)" % up_now)
		else:
			_turret_fail("стволы не поднялись: наклон=%.2f рад (жду ~0.55)" % up_now)
		host.head.rotation.x = 0.0
	)
	get_tree().create_timer(2.1).timeout.connect(func() -> void:
		var dn_now := float(turret.aim_pitch())
		if absf(dn_now) < 0.2:
			print("[TURRET] сервер: стволы вернулись в горизонт (наклон=%.2f рад)" % dn_now)
		else:
			_turret_fail("стволы не вернулись в горизонт: наклон=%.2f рад" % dn_now)
	)

	# Клиент пытается сесть в ЗАНЯТУЮ турель — сервер должен отказать.
	get_tree().create_timer(1.5).timeout.connect(func() -> void:
		test_client_do_mount.rpc(0)
	)
	get_tree().create_timer(1.9).timeout.connect(func() -> void:
		var client: Node = players.get(_turret_client_id)
		if turret.is_occupied() and int(turret.occupant_id) == 1 and (client == null or client.mounted_idx != 0):
			print("[TURRET] сервер: чужая посадка отклонена (турель занята)")
		else:
			_turret_fail("чужая посадка прошла: occupant=%s" % str(turret.occupant_id))
	)

	# Клиент уходит на огневую линию; хост разворачивается на неё и стреляет
	# трижды (чередование левый/правый). Купол ставим на цель МГНОВЕННО: здесь
	# проверяется огонь, а не скорость доводки (она в тесте посадки выше).
	get_tree().create_timer(2.2).timeout.connect(func() -> void:
		test_set_pos.rpc(_turret_client_id, firing_line, 0.0)
		var to_target := firing_line - tpos
		var aim_yaw := atan2(-to_target.x, -to_target.z)
		host.rotation.y = aim_yaw
		turret.yaw_node.rotation.y = wrapf(aim_yaw - turret.rotation.y, -PI, PI)
	)
	for i in 3:
		get_tree().create_timer(2.5 + 0.2 * i).timeout.connect(func() -> void:
			host._turret_fire()
		)

	# Проверка: клиент пострадал (3 × 25), патроны списаны (30 → 27).
	get_tree().create_timer(3.3).timeout.connect(func() -> void:
		var client: Node = players.get(_turret_client_id)
		var mag := int(turret.mag)
		if client != null and int(client.health) == 25:
			print("[TURRET] сервер: 3 выстрела по клиенту (hp клиента=25)")
		else:
			_turret_fail("урон не сошёлся: hp клиента=%s (ждём 25)" % str(client.health if client else "нет"))
		if mag == int(Game.TURRET["magazine"]) - 3:
			print("[TURRET] сервер: магазин турели %d (−3 патрона)" % mag)
		else:
			_turret_fail("магазин: %d (ждём %d)" % [mag, int(Game.TURRET["magazine"]) - 3])
	)

	# Хост выходит из турели.
	get_tree().create_timer(3.7).timeout.connect(func() -> void:
		try_dismount_player(1)
		if not turret.is_occupied() and host.mounted_idx == -1:
			print("[TURRET] сервер: хост вышел (турель свободна)")
		else:
			_turret_fail("выход хоста: occupant=%s, mounted=%s" % [str(turret.occupant_id), str(host.mounted_idx)])
	)

	# BUILD-38: перед выходом задаём взгляд вверх — после выхода стволы обязаны
	# сами лечь в горизонт, а не остаться задранными до следующей посадки.
	get_tree().create_timer(3.45).timeout.connect(func() -> void:
		host.head.rotation.x = 0.6
	)
	get_tree().create_timer(4.05).timeout.connect(func() -> void:
		var after := float(turret.aim_pitch())
		if absf(after) < 0.2:
			print("[TURRET] сервер: после выхода стволы сами легли в горизонт (наклон=%.2f рад)" % after)
		else:
			_turret_fail("после выхода стволы остались задранными: наклон=%.2f рад" % after)
	)

	# Клиент возвращается рядом и садится в теперь свободную турель.
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		test_set_pos.rpc(_turret_client_id, near, 0.0)
	)
	get_tree().create_timer(4.6).timeout.connect(func() -> void:
		test_client_do_mount.rpc(0)
	)
	get_tree().create_timer(5.0).timeout.connect(func() -> void:
		if turret.is_occupied() and int(turret.occupant_id) == _turret_client_id:
			print("[TURRET] сервер: клиент сел в освобождённую турель (id=%d)" % _turret_client_id)
		else:
			_turret_fail("клиент не сел: occupant=%s (ждём %d)" % [str(turret.occupant_id), _turret_client_id])
	)

	# Клиент выходит; финал.
	get_tree().create_timer(5.4).timeout.connect(func() -> void:
		test_client_dismount.rpc()
	)
	get_tree().create_timer(5.9).timeout.connect(func() -> void:
		if not turret.is_occupied():
			print("[TURRET] сервер: клиент вышел (турель свободна)")
		else:
			_turret_fail("клиент не вышел: occupant=%s" % str(turret.occupant_id))
		if _turret_ok:
			print("[TURRET_OK] сервер: сценарий турели пройден (посадка/занятость/огонь/выход)")
		get_tree().create_timer(2.0).timeout.connect(func() -> void: get_tree().quit(0 if _turret_ok else 1))
	)


## BUILD-39: наблюдатель «звёздного» клиента: как только occupant турели стал
## им (событие _event_mount), проверяет собственную mounted в тот же такт.
## Отдельная асинхронная функция, потому что create_timer(...).timeout.connect
## срабатывает ОДИН раз — одноточечная lambda «пропускала» окно посадки.
func _turret_mount_watch(my_id: int) -> void:
	var t := 0.0
	while t < 6.0:
		if _turret_star_id == my_id and turrets.size() > 0 and int(turrets[0].occupant_id) == my_id:
			_turret_mount_seen = true
			var me: Node = players.get(my_id)
			if me != null and int(me.mounted_idx) == 0:
				print("[TURRET] клиент: мы видим, что сидим в турели (mounted=0)")
			else:
				_turret_fail("клиент: occupant = я, но mounted=%s (ждём 0)" % str(me.mounted_idx if me else "нет"))
			return
		await get_tree().create_timer(0.05).timeout
		t += 0.05


## Клиент проверяет своё: прилёты выстрелов (трассеры/отдача на своей ноде —
## у всех), урон и видимость собственной посадки (у «звёздного» клиента,
## которого ведёт сценарий).
func _turret_client_monitor() -> void:
	var my_id := multiplayer.get_unique_id()
	# После трёх выстрелов хоста (2.5–2.9 с серверной шкалы): каждый клиент
	# получил 3 события fx. Часовая рассинхронизация нод ~0.5 с — проверяем
	# с запасом. (turrets читаем напрямую: локальные переменные в ламбдах
	# захватываются по значению, а не по ссылке.)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		if turrets.size() == 0:
			_turret_fail("клиент: нет турели в сцене")
			return
		var fx := int(turrets[0].fx_seen)
		if fx >= 3:
			print("[TURRET] клиент: получено %d выстрел-событий (отдача+трассер)" % fx)
		else:
			_turret_fail("клиент: выстрел-событий=%d (ждём >=3)" % fx)
		if _turret_star_id != my_id:
			return  # остальные зрители урона не получают
		var hp := int(players.get(my_id).health) if players.has(my_id) else -1
		if hp == 25:
			print("[TURRET] клиент: hp=%d после 3 выстрелов" % hp)
		else:
			_turret_fail("клиент: hp=%d (ждём 25)" % hp)
	)
	# Когда «звёздный» клиент сел (после выхода хоста) — видим свою посадку.
	# BUILD-39: проверка СОБЫТИЙНАЯ, не по таймеру: часы хоста и клиента могут
	# расходиться на секунды (клиент запускается позже), и любая одноточечная
	# проверка «на N-й секунде» то ловит посадку, то промахивается (на 5.1 с
	# клиент видел mounted=-1, хотя сервер уже монтировал). Ждём, пока occupant
	# турели НЕ СТАНЕТ нами (событие _event_mount), и в тот же такт проверяем
	# mounted — обе переменные ставятся одним и тем же RPC, поэтому согласованы.
	get_tree().create_timer(0.1).timeout.connect(func() -> void:
		_turret_mount_watch(my_id)
	)
	# Страховка: если до конца сценария occupant так и не стал нами — событие
	# посадки до клиента не дошло, и это настоящий сбой синхронизации.
	get_tree().create_timer(6.4).timeout.connect(func() -> void:
		if _turret_star_id == my_id and not _turret_mount_seen:
			_turret_fail("клиент: за всё время сценария occupant турели так и не стал нами")
	)
	# Выходим вслед за хостом (он закроет сервер — ловим разрыв соединения).
	multiplayer.server_disconnected.connect(func() -> void:
		if _turret_ok:
			print("[TURRET_OK] клиент: видимость посадки и выстрелов подтверждена")
		get_tree().create_timer(0.5).timeout.connect(func() -> void: get_tree().quit(0 if _turret_ok else 1))
	)
	get_tree().create_timer(30.0).timeout.connect(func() -> void:
		if _turret_ok:
			print("[TURRET_OK] клиент: видимость посадки и выстрелов подтверждена")
		get_tree().quit(0 if _turret_ok else 1)
	)


func _on_peer_disconnected(id: int) -> void:
	if Game.smoke_test:
		print("[SMOKE] дисконнект пира %d (сторона: %s)" % [id, "сервер" if multiplayer.is_server() else "клиент"])
	# Сигнал приходит КАЖДОЙ ноде: убираем модель выбывшего везде.
	var p: Node = players.get(id)
	if p != null:
		p.queue_free()
		players.erase(id)
	scores.erase(id)
	_spawn_idx.erase(id)
	sides.erase(id)
	_downed.erase(id)
	_push_squad()
	if Game.autostart:
		print("[AUTOSTART] игрок %d вышел, осталось %d" % [id, players.size()])
	if not multiplayer.is_server() or _match_over or Game.solo_test_mode:
		return
	# BUILD-34: кооператив — уход игрока оборону не ломает: отбиваются те, кто
	# остался. Матч завершается, только если ушёл последний игрок.
	if players.size() >= 1:
		Game.scores_changed.emit(scores.duplicate(), multiplayer.get_unique_id())
		return
	_match_over = true
	Game.match_over.emit("Все игроки отключились")
	_event_opponent_left.rpc()


@rpc("authority", "call_remote", "reliable")
func _event_opponent_left() -> void:
	Game.match_over.emit("Игрок отключился")


# ---------------------------------------------------------------- smoke-тест (автоматизация)

func _smoke_host_shoots_client() -> void:
	# Повторение жалобы «хост не наносит урон»: хост стреляет в клиента.
	if not multiplayer.is_server():
		return
	var host_node: Node = players.get(1)
	var client_node: Node = null
	for k in players.keys():
		if k != 1:
			client_node = players.get(k)
			break
	if host_node == null or client_node == null:
		print("[SMOKE] сервер: нет обоих игроков (ключи=%s)" % str(players.keys()))
		return
	var origin: Vector3 = host_node.get_head_world_position()
	var dir: Vector3 = (client_node.get_head_world_position() - origin).normalized()
	# Поворачиваем хоста лицом к клиенту и стреляем через реальный _fire() —
	# тот самый путь, что и при клике мышью у игрока.
	host_node.rotation.y = atan2(-dir.x, -dir.z)
	print("[SMOKE] сервер: хост стреляет в клиента через _fire() (%d выстрелов)" % SMOKE_SHOTS)
	for i in SMOKE_SHOTS:
		# Разносим выстрелы на 300 мс — как реальные клики (кулдаун оружия 250 мс).
		get_tree().create_timer(0.3 * i).timeout.connect(host_node._fire)


func _synthetic_click() -> void:
	# Имитация реального клика ЛКМ: событие проходит тот же конвейер,
	# что и событие от ОС (обновление действий ввода -> _unhandled_input).
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.button_mask = 1
	press.position = Vector2(320.0, 240.0)
	press.global_position = press.position
	get_tree().root.push_input(press, true)
	var release: InputEventMouseButton = press.duplicate()
	release.pressed = false
	release.button_mask = 0
	get_tree().root.push_input(release, true)


# Вторая фаза inputtest: нож (быстрый и тяжёлый удар), перезарядка и
# прицеливание снайперки.
#
# Важно: в headless синтетические НАЖАТИЯ КЛАВИШ (push_input + InputEventKey)
# не маппятся на действия, а Input.action_press даёт is_action_just_pressed
# лишь в том же кадре. Поэтому смену слотов делаем напрямую (_select_weapon),
# а огонь/прицел — через Input.action_press (уровневые is_action_pressed
# видны и в следующих кадрах). Так мы проверяем именно игровую логику,
# минуя только ОС-слой клавиатуры.
func _input_test_weapons() -> void:
	if not multiplayer.is_server():
		return
	var me: Node = players.get(1)
	if me == null:
		print("[WEAPONTEST_FAIL] нет ноды хоста")
		return
	print("[WEAPONTEST] фаза оружия: нож -> перезарядка -> прицел снайперки")

	# --- 1) Быстрый удар ножом (ЛКМ).
	me._select_weapon(0)
	get_tree().create_timer(0.3).timeout.connect(func() -> void: Input.action_press("fire"))
	get_tree().create_timer(0.6).timeout.connect(func() -> void: Input.action_release("fire"))

	# --- 2) Тяжёлый удар ножом (замах ~450 мс + удар ~160 мс).
	# Запускаем состояние напрямую: ПКМ-замах опрашивается через
	# is_action_just_pressed, который синтетически не воспроизвести.
	get_tree().create_timer(1.2).timeout.connect(func() -> void:
		me._start_heavy_strike()
		if me._knife_phase != 1:
			print("[WEAPONTEST_FAIL] замах не стартовал (фаза=%d)" % me._knife_phase)
		# BUILD-18: сочленённая рука — кисть правой руки лежит НА РУКОЯТИ ножа
		# и движется вместе с клинком при замахе/ударе.
		var grip_w: Vector3 = me.knife_fp.global_transform * Vector3(0.0, -0.045, 0.13)
		var hand_r: MeshInstance3D = me._fp_arm_nodes[0]["hand"]
		if hand_r.visible and hand_r.global_position.distance_to(grip_w) < 0.05:
			print("[WEAPONTEST] кисть на рукояти ножа, движется с клинком")
		else:
			print("[WEAPONTEST_FAIL] кисть на ноже: видима=%s, от рукояти %.3f м" % [str(hand_r.visible), hand_r.global_position.distance_to(grip_w)])
	)
	get_tree().create_timer(2.2).timeout.connect(func() -> void:
		if me._knife_phase != 0:
			print("[WEAPONTEST_FAIL] тяжёлый удар застрял в фазе %d" % me._knife_phase)
		else:
			print("[WEAPONTEST] тяжёлый удар ОК (замах -> удар -> фаза 0)")
	)

	# --- 3) Перезарядка пистолета: имитируем неполный магазин и старт.
	get_tree().create_timer(2.6).timeout.connect(func() -> void:
		me._select_weapon(1)
		me.ammo_mag[1] = 5
		me._start_reload()
	)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:  # reload 1200 мс + запас
		if int(me.ammo_mag[1]) == 12 and me.reload_end_ms == 0:
			print("[WEAPONTEST] перезарядка пистолета ОК: магазин снова 12")
		else:
			print("[WEAPONTEST_FAIL] перезарядка: магазин=%d, reload_end_ms=%d" % [int(me.ammo_mag[1]), me.reload_end_ms])
	)

	# --- 4) Прицел снайперки (ПКМ): зум + замедление.
	get_tree().create_timer(4.8).timeout.connect(func() -> void:
		me._select_weapon(2)
		Input.action_press("fire_alt")
	)
	get_tree().create_timer(5.4).timeout.connect(func() -> void:
		var fov_ok: bool = me.camera.fov < 40.0
		if me._ads and me.current_weapon == 2 and fov_ok:
			print("[WEAPONTEST] прицел снайперки ОК (ADS, FOV=%.1f)" % me.camera.fov)
		else:
			print("[WEAPONTEST_FAIL] прицел: ADS=%s оружие=%d FOV=%.1f" % [str(me._ads), me.current_weapon, me.camera.fov])
	)
	get_tree().create_timer(5.9).timeout.connect(func() -> void: Input.action_release("fire_alt"))
	get_tree().create_timer(6.3).timeout.connect(func() -> void:
		if not me._ads:
			print("[WEAPONTEST] прицел отпущен")
		else:
			print("[WEAPONTEST_FAIL] прицел не отпустился")
	)

	# --- 5) Реакции оружия у стены (BUILD-14/15): подъём ВВЕРХ, складывание
	# «в обе руки» ВНИЗ-влево, ствол ВНИЗ при взгляде вверх; выстрел со
	# смещённым оружием ЗАБЛОКИРОВАН, свободный выстрел — строго в перекрестие.
	# 5a) Пистолет у стены: ствол поднимается ВВЕРХ, оружие не у камеры.
	# BUILD-32: стена — западный край плато ущелья (x = -Map.MAP_HALF_X).
	var wall_x: float = -Map.MAP_HALF_X + 0.5   # внутренняя грань скалы
	var wall_z := 30.0                               # открытая площадка плато
	get_tree().create_timer(6.8).timeout.connect(func() -> void:
		me._select_weapon(1)  # пистолет
		me.position = Vector3(wall_x + 0.65, 1.0, wall_z)
		me.rotation.y = PI / 2.0  # лицом к стене (-X)
		me.head.rotation.x = 0.0
		me.reset_net_targets()
	)
	get_tree().create_timer(7.3).timeout.connect(func() -> void:
		var up := bool(me._fp_tilt > 0.7)
		var not_pulled := bool(me.gun_anchor.position.z < -0.34)
		if up and not_pulled:
			print("[WEAPONTEST] пистолет у стены: ствол ВВЕРХ (%.2f рад), не у камеры (z=%.2f)" % [me._fp_tilt, me.gun_anchor.position.z])
		else:
			print("[WEAPONTEST_FAIL] пистолет у стены: наклон=%.2f, z=%.2f" % [me._fp_tilt, me.gun_anchor.position.z])
		me._select_weapon(2)  # снайперка — длинная, должна сложиться
	)
	# 5b) Снайперка у стены: ей не хватает места — СКЛАДЫВАНИЕ к груди.
	get_tree().create_timer(7.7).timeout.connect(func() -> void:
		if me._fp_fold > 0.8:
			print("[WEAPONTEST] снайперка у стены: СЛОЖЕНА к груди (fold=%.2f)" % me._fp_fold)
		else:
			print("[WEAPONTEST_FAIL] снайперка не сложилась (наклон=%.2f, fold=%.2f)" % [me._fp_tilt, me._fp_fold])
	)
	# 5c) Пистолет вплотную к стене: складывается. Выстрел из сложенного
	# положения ЗАБЛОКИРОВАН (пуля не должна лететь по кривому стволу).
	get_tree().create_timer(8.1).timeout.connect(func() -> void:
		me._select_weapon(1)
		me.position = Vector3(wall_x + 0.35, 1.0, wall_z)  # 35 см до стены
		me.rotation.y = PI / 2.0
		me.reset_net_targets()
	)
	get_tree().create_timer(8.7).timeout.connect(func() -> void:
		var folded := bool(me._fp_fold > 0.8)
		var displaced := bool(me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		me._fire()  # попытка выстрела из сложенного положения
		var blocked := bool(int(me.ammo_mag[1]) == before)
		if folded and displaced and blocked:
			print("[WEAPONTEST] упор: оружие СЛОЖЕНО (fold=%.2f), выстрел ЗАБЛОКИРОВАН (патроны %d→%d)" % [me._fp_fold, before, int(me.ammo_mag[1])])
		else:
			print("[WEAPONTEST_FAIL] упор: fold=%.2f, displaced=%s, патроны %d→%d" % [me._fp_fold, str(displaced), before, int(me.ammo_mag[1])])
	)
	# 5d) Взгляд ВВЕРХ на стену: реакция — ствол опускается ВНИЗ.
	get_tree().create_timer(9.1).timeout.connect(func() -> void:
		me.position = Vector3(wall_x + 0.65, 1.0, wall_z)
		me.head.rotation.x = 0.6
		me.reset_net_targets()
	)
	get_tree().create_timer(9.7).timeout.connect(func() -> void:
		if me._fp_tilt < -0.5 and me._fp_fold < 0.2:
			print("[WEAPONTEST] взгляд вверх: ствол опущен ВНИЗ (%.2f рад)" % me._fp_tilt)
		else:
			print("[WEAPONTEST_FAIL] взгляд вверх: наклон=%.2f, fold=%.2f" % [me._fp_tilt, me._fp_fold])
	)
	# 5e) Пистолет ПОДНЯТ у стены (наклон > 0.25): выстрел тоже заблокирован.
	get_tree().create_timer(9.9).timeout.connect(func() -> void:
		me.head.rotation.x = 0.0
		me.position = Vector3(wall_x + 0.65, 1.0, wall_z)
		me.reset_net_targets()
	)
	get_tree().create_timer(10.4).timeout.connect(func() -> void:
		var raised := bool(me._fp_tilt > 0.7)
		var displaced := bool(me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		me._fire()  # попытка выстрела с поднятым стволом
		var blocked := bool(int(me.ammo_mag[1]) == before)
		if raised and displaced and blocked:
			print("[WEAPONTEST] ствол ВВЕРХ (%.2f рад): выстрел ЗАБЛОКИРОВАН" % me._fp_tilt)
		else:
			print("[WEAPONTEST_FAIL] поднятый ствол: наклон=%.2f, displaced=%s, патроны %d→%d" % [me._fp_tilt, str(displaced), before, int(me.ammo_mag[1])])
	)
	# 5f) Отошли от стены: оружие свободно, выстрел идёт СТРОГО в перекрестие.
	get_tree().create_timer(10.7).timeout.connect(func() -> void:
		me.position = Map.SPAWN_TEST[0]    # возвращаемся на свой спавн
		me.rotation.y = Map.SPAWN_TEST_YAW[0]
		me.reset_net_targets()
	)
	get_tree().create_timer(11.2).timeout.connect(func() -> void:
		me.next_allowed_shot_ms = 0
		var free := bool(me._fp_tilt < 0.05 and me._fp_fold < 0.05 and not me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		var cam_fwd: Vector3 = -me.camera.global_transform.basis.z
		var aim_dot: float = me._aim_dir().dot(cam_fwd)
		me._fire()
		var fired := bool(int(me.ammo_mag[1]) == before - 1)
		var straight := bool(aim_dot > 0.999)
		if free and fired and straight:
			print("[WEAPONTEST] свободно: выстрел в перекрестие (патроны %d→%d, dot=%.3f)" % [before, int(me.ammo_mag[1]), aim_dot])
		else:
			print("[WEAPONTEST_FAIL] свободный выстрел: free=%s, fired=%s, dot=%.3f, патроны %d→%d" % [str(free), str(fired), aim_dot, before, int(me.ammo_mag[1])])
	)
	# BUILD-19: соперник — НЕ стена: встаём вплотную к клиенту, оружие не
	# должно складываться/задираться из-за его тела.
	get_tree().create_timer(11.6).timeout.connect(func() -> void:
		# ~0.7 м до соперника: он стоит на своём тестовом спавне.
		var foe_pos: Vector3 = Map.SPAWN_TEST[1]
		me.position = Vector3(foe_pos.x - 0.7, 1.0, foe_pos.z)
		me.rotation.y = Map.SPAWN_TEST_YAW[0]  # лицом к сопернику (+X)
		me.head.rotation.x = 0.0
		me.reset_net_targets()
	)
	get_tree().create_timer(12.3).timeout.connect(func() -> void:
		if me._fp_fold < 0.1 and absf(me._fp_tilt) < 0.1:
			print("[WEAPONTEST] соперник не стена: в упор оружие НЕ сложено (fold=%.2f, наклон=%.2f)" % [me._fp_fold, me._fp_tilt])
			print("[WEAPONTEST_OK]")
		else:
			print("[WEAPONTEST_FAIL] оружие среагировало на тело соперника (fold=%.2f, наклон=%.2f)" % [me._fp_fold, me._fp_tilt])
		me.position = Map.SPAWN_TEST[0]
		me.rotation.y = Map.SPAWN_TEST_YAW[0]
		me.reset_net_targets()
	)
	# BUILD-21/23: взгляд сильно ВНИЗ, «ровно под тело» — оружие и руки
	# выносятся ПЕРЕД телом, а не проваливаются в него; стрельба разрешена.
	get_tree().create_timer(12.7).timeout.connect(func() -> void:
		me.head.rotation.x = -1.55  # ~89° вниз, ровно под себя
	)
	get_tree().create_timer(13.5).timeout.connect(func() -> void:
		var gp: Vector3 = me.gun_anchor.global_position
		var radial := Vector2(gp.x - me.global_position.x, gp.z - me.global_position.z).length()
		me.next_allowed_shot_ms = 0
		var before := int(me.ammo_mag[1])
		me._fire()
		var fired := bool(int(me.ammo_mag[1]) == before - 1)
		if radial > 0.29 and radial < 0.5 and gp.y < 1.35 and fired and me._fp_fold < 0.05 and absf(me._fp_tilt) < 0.05:
			print("[WEAPONTEST] взгляд вниз: оружие У тела (%.2f м от оси), локти согнуты, выстрел разрешён (%d→%d)" % [radial, before, int(me.ammo_mag[1])])
		else:
			print("[WEAPONTEST_FAIL] взгляд вниз: от оси=%.2f м, y=%.2f, fired=%s, fold=%.2f, наклон=%.2f" % [radial, gp.y, str(fired), me._fp_fold, me._fp_tilt])
		# BUILD-22: локти при взгляде вниз сгибаются и остаются ВНЕ тела.
		var elb: MeshInstance3D = me._fp_arm_nodes[1]["upper"]
		var half: float = elb.mesh.size.z * 0.5
		var e1 := elb.global_position + elb.global_transform.basis.z * half
		var e2 := elb.global_position - elb.global_transform.basis.z * half
		var shp: Vector3 = me._fp_arm_nodes[1]["shoulder"].global_position
		var ep := e1 if e1.distance_to(shp) > e2.distance_to(shp) else e2
		var elb_rad := Vector2(ep.x - me.global_position.x, ep.z - me.global_position.z).length()
		if elb_rad > 0.30:
			print("[WEAPONTEST] взгляд вниз: локти согнуты и вне тела (%.2f м от оси)" % elb_rad)
		else:
			print("[WEAPONTEST_FAIL] локоть внутри тела: %.2f м от оси" % elb_rad)
		# BUILD-23: новое тело — торс и ноги с коленями видны, стопы на земле.
		var feet_ok := bool(me.torso_node != null and me.torso_node.visible \
			and me._leg_rig_r["foot"].global_position.y < 0.2 \
			and me._leg_rig_l["foot"].global_position.y < 0.2)
		# BUILD-26: свои грудь и шея скрыты — не перекрывают камеру.
		var chest_hidden := bool(not me._chest_mesh.visible and not me._neck_mesh.visible)
		if feet_ok and chest_hidden:
			print("[WEAPONTEST] тело: ноги с коленями на земле; свои грудь/шея скрыты (обзор чистый)")
		else:
			print("[WEAPONTEST_FAIL] тело: ноги=%s, грудь_скрыта=%s" % [str(feet_ok), str(chest_hidden)])
		# Резкий поворот: торс доворачивается первым (не больше 0.7 рад),
		# затем ноги и всё тело следуют.
		me.rotation.y += 2.4
	)
	get_tree().create_timer(13.7).timeout.connect(func() -> void:
		var diff := wrapf(me.rotation.y - me._legs_yaw, -PI, PI)
		var twist: float = float(me.torso_node.rotation.y) + diff
		if absf(twist) > 0.6 and absf(twist) <= 0.71 and absf(diff) > 0.7:
			print("[WEAPONTEST] торс: сначала довернулся торс (%.2f рад), тело ещё догоняет (%.2f)" % [twist, diff])
		else:
			print("[WEAPONTEST_FAIL] торс: твист=%.2f, разница=%.2f" % [twist, diff])
	)
	get_tree().create_timer(14.2).timeout.connect(func() -> void:
		var diff2 := wrapf(me.rotation.y - me._legs_yaw, -PI, PI)
		if absf(diff2) < 0.3:
			print("[WEAPONTEST] торс: затем всё тело довернулось следом")
		else:
			print("[WEAPONTEST_FAIL] торс: тело не довернулось (остаток %.2f)" % diff2)
		me.head.rotation.x = 0.0
		me.rotation.y = -PI / 2.0
		me.reset_net_targets()
	)
	# BUILD-25: «кручусь на WASD» — ноги отклоняются в сторону шага лишь
	# в пределах 0.6 рад от взгляда и не делают полный оборот.
	get_tree().create_timer(14.5).timeout.connect(func() -> void:
		var side: Vector3 = me.global_transform.basis.x
		for i in 60:
			me._update_body_pose(0.05, true, side, false, true, 0.0, 0.0, 0.0)
		var lean := wrapf(me._legs_yaw - me.rotation.y, -PI, PI)
		if absf(lean) <= 0.61:
			print("[WEAPONTEST] стрейф по кругу: ноги отклонились на %.2f рад, без оборота" % lean)
		else:
			print("[WEAPONTEST_FAIL] стрейф: ноги ушли на %.2f рад" % lean)
		me.reset_net_targets()
	)

# Клиентская часть inputtest: проверяем, что анимации хоста (замах ножа,
# перезарядка, прицел) реально дошли до клиента и проигрываются на его
# копии ноды хоста. Тайминги синхронизированы с _input_test_weapons хоста
# (фаза стартует через 16 с после спавна).
func _input_test_client_checks() -> void:
	if multiplayer.is_server():
		return
	var host_node: Node = players.get(1)
	if host_node == null:
		print("[CLIENTANIM_FAIL] нет ноды хоста у клиента")
		return
	# BUILD-27: присед и прыжок синхронизированы. Хост: присед 14.6..15.8,
	# прыжок 15.9..16.4. Клиент опрашивает дважды (запас на рассинхрон часов).
	# Замах тяжёлого удара: у хоста старт на +17.2 с, длится до +17.9 с.
	# Заодно проверяем кисть от первого лица, прикреплённую к ножу (BUILD-15):
	# она видна вместе с клинком и машет вместе с ним.
	get_tree().create_timer(17.45).timeout.connect(func() -> void:
		if host_node._remote_knife_phase == 1 or host_node._remote_knife_phase == 2:
			print("[CLIENTANIM] замах ножа соперника виден (фаза=%d)" % host_node._remote_knife_phase)
		else:
			print("[CLIENTANIM_FAIL] замах ножа не пришёл (фаза=%d)" % host_node._remote_knife_phase)
		# BUILD-18: рука соперника на ноже — СОЧЛЕНЁННАЯ: правая видима, кисть
		# на рукояти клинка, левая скрыта (нож держат одной рукой).
		var rarm: Dictionary = host_node._remote_arm_nodes[0]
		var larm: Dictionary = host_node._remote_arm_nodes[1]
		var knife_grip_w: Vector3 = host_node.knife_remote.global_transform * Vector3(0.0, -0.045, 0.12)
		var knife_arms_ok: bool = rarm["upper"].visible and not larm["upper"].visible \
			and rarm["hand"].global_position.distance_to(knife_grip_w) < 0.05
		if knife_arms_ok:
			print("[CLIENTANIM] рука соперника на ноже: сочленённая, кисть на рукояти")
		else:
			print("[CLIENTANIM_FAIL] рука на ноже: правая=%s, левая скрыта=%s, от рукояти %.3f м" % [str(rarm["upper"].visible), str(not larm["upper"].visible), rarm["hand"].global_position.distance_to(knife_grip_w)])
	)
	# Перезарядка: у хоста +18.6..19.8 с. Перезарядка пистолета видна
	# вместе с кистями на оружии (BUILD-15).
	get_tree().create_timer(19.05).timeout.connect(func() -> void:
		if host_node._remote_reload_end_ms > Time.get_ticks_msec():
			print("[CLIENTANIM] перезарядка соперника видна")
		else:
			print("[CLIENTANIM_FAIL] перезарядка соперника не пришла")
		var hands: bool = host_node._remote_arm_nodes.size() == 2 \
			and host_node._remote_arm_nodes[0]["hand"].visible \
			and host_node._remote_arm_nodes[1]["hand"].visible
		if hands:
			print("[CLIENTANIM] кисти соперника видны на пистолете")
		else:
			print("[CLIENTANIM_FAIL] кисти соперника на пистолете не видны")
		# Рука СОЧЛЕНЁННАЯ: сегмент плеча фиксированной длины (локоть существует).
		var upper: MeshInstance3D = host_node._remote_arm_nodes[0]["upper"]
		var up_len: float = upper.mesh.size.z
		if up_len > 0.2 and upper.visible:
			print("[CLIENTANIM] рука соперника сочленённая: плечо %.2f м + предплечье + кисть" % up_len)
		else:
			print("[CLIENTANIM_FAIL] сегмент плеча соперника: длина=%.2f, виден=%s" % [up_len, str(upper.visible)])
	)
	# BUILD-28: idle-дыхание соперника синхронизировано (два замера фазы).
	get_tree().create_timer(20.5).timeout.connect(func() -> void:
		_breath_c0 = host_node._remote_breath
	)
	get_tree().create_timer(20.9).timeout.connect(func() -> void:
		if absf(host_node._remote_breath - _breath_c0) > 0.001:
			print("[CLIENTANIM] idle-дыхание соперника синхронизировано (%.4f м)" % host_node._remote_breath)
		else:
			print("[CLIENTANIM_FAIL] idle-дыхание соперника не пришло")
	)
	# Прицел: у хоста +20.8..21.9 с. Заодно проверяем (BUILD-15):
	# — снайперка соперника НЕ перевёрнута (рыск ≈ базовый π, как в сцене);
	# — дуло смотрит ВПЕРЁД по взгляду соперника;
	# — обе кисти соперника лежат на снайперке.
	get_tree().create_timer(21.2).timeout.connect(func() -> void:
		if host_node._remote_ads:
			print("[CLIENTANIM] прицел соперника виден")
		else:
			print("[CLIENTANIM_FAIL] прицел соперника не пришёл")
		var yaw_err := absf(wrapf(host_node.sniper_remote.rotation.y - host_node._sniper_remote_yaw0, -PI, PI))
		if yaw_err < 0.05:
			print("[CLIENTANIM] снайперка соперника НЕ перевёрнута (рыск=%.2f)" % host_node.sniper_remote.rotation.y)
		else:
			print("[CLIENTANIM_FAIL] снайперка соперника перевёрнута (рыск=%.2f, база=%.2f)" % [host_node.sniper_remote.rotation.y, host_node._sniper_remote_yaw0])
		var muzzle_fwd: bool = host_node.sniper_remote_muzzle.global_position.x > host_node.head.global_position.x
		if muzzle_fwd:
			print("[CLIENTANIM] дуло снайперки смотрит вперёд")
		else:
			print("[CLIENTANIM_FAIL] дуло снайперки смотрит назад")
		var hands: bool = host_node._remote_arm_nodes.size() == 2 \
			and host_node._remote_arm_nodes[0]["hand"].visible \
			and host_node._remote_arm_nodes[1]["hand"].visible
		var grip_ok: bool = hands and host_node._remote_arm_nodes[0]["hand"].global_position.distance_to(host_node.sniper_remote.global_transform * Vector3(0.0, -0.16, 0.5)) < 0.03
		if grip_ok:
			print("[CLIENTANIM] обе сочленённые руки соперника лежат на снайперке")
		else:
			print("[CLIENTANIM_FAIL] руки соперника на снайперке: видны=%s, на рукоятке=%s" % [str(hands), str(grip_ok)])
	)
	# Всё должно сброситься после окончания фазы.
	get_tree().create_timer(22.6).timeout.connect(func() -> void:
		if not host_node._remote_ads and host_node._remote_knife_phase == 0:
			print("[CLIENTANIM] состояния соперника сбросились")
		else:
			print("[CLIENTANIM_FAIL] состояния соперника не сбросились (ADS=%s, нож=%d)" % [str(host_node._remote_ads), host_node._remote_knife_phase])
	)
	# BUILD-17: реакции у стен ПРИХОДЯТ ПО СЕТИ от владельца (у хоста фаза
	# стен стартует на +22.8 с). В +23.15 хост держит пистолет у стены —
	# ствол ПОДНЯТ; проверяем, что мы видим тот же наклон, что у владельца.
	get_tree().create_timer(23.15).timeout.connect(func() -> void:
		if host_node._remote_tilt > 0.7 and host_node._remote_fold < 0.2:
			print("[CLIENTANIM] наклон соперника синхронизирован (ствол вверх, %.2f рад)" % host_node._remote_tilt)
		else:
			print("[CLIENTANIM_FAIL] наклон соперника не пришёл (наклон=%.2f, fold=%.2f)" % [host_node._remote_tilt, host_node._remote_fold])
	)
	# В +24.9 хост держит пистолет ВПЛОТНУЮ к стене — оружие СЛОЖЕНО ВБОК.
	# Раньше мы видели вместо этого подъём ствола; теперь складывание должно
	# прийти по сети: большой fold и НЕбольшой наклон.
	get_tree().create_timer(24.9).timeout.connect(func() -> void:
		if host_node._remote_fold > 0.7 and host_node._remote_tilt < 0.3:
			print("[CLIENTANIM] складывание соперника синхронизировано (ВБОК, fold=%.2f, наклон=%.2f)" % [host_node._remote_fold, host_node._remote_tilt])
		else:
			print("[CLIENTANIM_FAIL] складывание соперника: наклон=%.2f, fold=%.2f (ожидали ВБОК)" % [host_node._remote_tilt, host_node._remote_fold])
	)
	# BUILD-21: хост на +28.7 с держит взгляд вниз (тангаж -1.3 рад). Его
	# оружие должно быть вынесено ПЕРЕД телом, а не проваливаться внутрь.
	get_tree().create_timer(29.3).timeout.connect(func() -> void:
		var gp: Vector3 = host_node.remote_gun.global_position
		var radial := Vector2(gp.x - host_node.global_position.x, gp.z - host_node.global_position.z).length()
		# BUILD-22: вторая (левая) рука соперника не пересекает торс —
		# локоть держится снаружи.
		var elb: MeshInstance3D = host_node._remote_arm_nodes[1]["upper"]
		var half: float = elb.mesh.size.z * 0.5
		var e1 := elb.global_position + elb.global_transform.basis.z * half
		var e2 := elb.global_position - elb.global_transform.basis.z * half
		var shp: Vector3 = host_node._remote_arm_nodes[1]["shoulder"].global_position
		var ep := e1 if e1.distance_to(shp) > e2.distance_to(shp) else e2
		var elb_rad := Vector2(ep.x - host_node.global_position.x, ep.z - host_node.global_position.z).length()
		# BUILD-23: у соперника видны торс и ноги с коленями, стопы на земле.
		var feet_ok := bool(host_node.torso_node != null and host_node.torso_node.visible \
			and host_node._leg_rig_r["foot"].global_position.y < 0.2 \
			and host_node._leg_rig_l["foot"].global_position.y < 0.2)
		# BUILD-26: у соперника тело ПОЛНОЕ (грудь видна), у себя — скрыта.
		var chest_ok := bool(host_node._chest_mesh.visible)
		if host_node.head.rotation.x < -1.0 and radial > 0.29 and radial < 0.5 and elb_rad > 0.30 and feet_ok and chest_ok:
			print("[CLIENTANIM] соперник вниз: оружие у тела (%.2f м), локти вне (%.2f м), ноги с коленями на земле" % [radial, elb_rad])
			print("[CLIENTANIM_OK]")
		else:
			print("[CLIENTANIM_FAIL] соперник вниз: тангаж=%.2f, оружие=%.2f, локоть=%.2f, ноги=%s" % [host_node.head.rotation.x, radial, elb_rad, str(feet_ok)])
	)


func _smoke_on_got_hit() -> void:
	_smoke_client_got_hits += 1
	print("[SMOKE] клиент: получил урон #%d" % _smoke_client_got_hits)
	if _smoke_client_got_hits == SMOKE_SHOTS:
		print("[SMOKE] SMOKE_CLIENT_GOT_HIT_OK (урон от хоста дошёл)")
		if Game.input_test:
			for i in SMOKE_SHOTS:
				get_tree().create_timer(0.2 + 0.3 * i).timeout.connect(_synthetic_click)
		else:
			_smoke_client_fire_deferred(0)  # теперь отвечаем огнём


func _smoke_client_fire_deferred(attempt: int) -> void:
	if attempt > 10 or _smoke_fired:
		return
	var me: Node = players.get(multiplayer.get_unique_id())
	var host: Node = players.get(1)
	if me == null or host == null:
		get_tree().create_timer(0.2).timeout.connect(func() -> void:
			_smoke_client_fire_deferred(attempt + 1)
		)
		return
	_smoke_fired = true
	var origin: Vector3 = me.get_head_world_position()
	var dir: Vector3 = (host.get_head_world_position() - origin).normalized()
	print("[SMOKE] клиент: стреляю в хоста (%d выстрелов)" % SMOKE_SHOTS)
	for i in SMOKE_SHOTS:
		me.request_shoot.rpc_id(1, origin, dir, 1, 0)  # пистолет, обычная атака


func _smoke_on_dealt_hit() -> void:
	_smoke_client_hits += 1
	if _smoke_client_hits >= SMOKE_SHOTS:
		print("[SMOKE] SMOKE_CLIENT_OK")
		if Game.input_test:
			# Не выходим сразу: хост ещё проверяет нож/перезарядку/прицел,
			# а дисконнект клиента завершил бы матч досрочно.
			get_tree().create_timer(30.0).timeout.connect(func() -> void: get_tree().quit(0))
		else:
			get_tree().quit(0)


func _smoke_host_finish() -> void:
	if not Game.smoke_test or not multiplayer.is_server():
		return
	if _smoke_hits >= SMOKE_SHOTS * 2:  # клиент попал в хоста + хост попал в клиента
		print("[SMOKE] SMOKE_HOST_OK хиты=%d" % _smoke_hits)
		get_tree().quit(0)
	else:
		print("[SMOKE] SMOKE_HOST_FAIL хиты=%d (ожидалось %d)" % [_smoke_hits, SMOKE_SHOTS * 2])
		get_tree().quit(1)


# ------------------------------------------------- BUILD-31: тест клавиши F
# Репродукция пользовательского сценария: игрок подходит к турели и ЖМЁТ F.
# Отличие от turrett: здесь не вызывается try_mount_player напрямую —
# диспетчеризуется настоящее событие клавиатуры, то есть проходят ОБА
# обработчика ввода (unhandled_input и опрос в _physics_process).

var _keytest_ok := true
var _keytest_last_mounted := -99
var _keytest_toggles := 0
var _keytest_cid := 0


func _keytest_fail(msg: String) -> void:
	_keytest_ok = false
	print("[KEYTEST_FAIL] " + msg)


## Настоящее нажатие клавиши (press + release) — как от клавиатуры.
func _keytest_press(action_keycode: int) -> void:
	var down := InputEventKey.new()
	down.physical_keycode = action_keycode
	down.pressed = true
	down.echo = false
	Input.parse_input_event(down)
	var up := InputEventKey.new()
	up.physical_keycode = action_keycode
	up.pressed = false
	up.echo = false
	Input.parse_input_event(up)


## Хост: подводит себя к турели 0, жмёт F, следит за mounted_idx по кадрам.
## Сценарий (одно нажатие F = ровно ОДНО переключение состояния):
##   0.4с  хост жмёт F -> садится
##   1.2с  клиент жмёт F -> отказ (турель занята)
##   2.0с  хост жмёт F -> выходит
##   2.4с  хост телепортирует клиента к турели
##   3.0с  клиент жмёт F -> садится (полный any_peer/RPC-путь)
##   4.0с  клиент жмёт F -> выходит
func _keytest_host() -> void:
	var host: Node = players.get(1)
	if host == null:
		_keytest_fail("нет ноды хоста")
		return
	_keytest_cid = 0
	for k in players.keys():
		if int(k) != 1:
			_keytest_cid = int(k)
			break
	test_turret_star.rpc(_keytest_cid)  # «ведомый» клиент (остальные не проверяются)
	var turret: Node3D = turrets[0]
	var tpos: Vector3 = turret.position
	host.position = tpos + Vector3(0.0, 0.0, 1.6)
	host.rotation.y = 0.0
	_keytest_last_mounted = int(host.mounted_idx)
	print("[KEYTEST] хост у турели 0 (mounted=%d, occupant=%d), клиент=%d" % [int(host.mounted_idx), int(turret.occupant_id), _keytest_cid])

	get_tree().create_timer(0.4).timeout.connect(func() -> void:
		print("[KEYTEST] хост жмёт F (посадка)")
		_keytest_press(KEY_F)
	)
	# Первый замер: сразу после посадки — здесь и ловится «сам вышел».
	get_tree().create_timer(0.9).timeout.connect(func() -> void:
		if int(host.mounted_idx) != 0 or not turret.is_occupied() or int(turret.occupant_id) != 1:
			_keytest_fail("после F хост НЕ в турели: mounted=%d occupant=%d (сработал авто-выход)" % [int(host.mounted_idx), int(turret.occupant_id)])
		else:
			print("[KEYTEST] хост: посадка удержана (mounted=0, occupant=1)")
	)
	get_tree().create_timer(1.2).timeout.connect(func() -> void:
		print("[KEYTEST] клиент %d жмёт F в ЗАНЯТУЮ турель" % _keytest_cid)
		test_keypress.rpc(_keytest_cid)
	)
	get_tree().create_timer(1.8).timeout.connect(func() -> void:
		var c: Node = players.get(_keytest_cid)
		if c != null and int(c.mounted_idx) == 0:
			_keytest_fail("клиент сел в занятую турель (mounted=%d)" % int(c.mounted_idx))
		else:
			print("[KEYTEST] занятая турель: клиенту отказано (mounted=%s)" % str(int(c.mounted_idx) if c else "-"))
		print("[KEYTEST] хост жмёт F (выход)")
		_keytest_press(KEY_F)
	)
	get_tree().create_timer(2.2).timeout.connect(func() -> void:
		if int(host.mounted_idx) != -1 or turret.is_occupied():
			_keytest_fail("выход хоста по F не сработал: mounted=%d occupant=%d" % [int(host.mounted_idx), int(turret.occupant_id)])
		else:
			print("[KEYTEST] хост: выход по F (mounted=-1, сиденье свободно)")
	)
	get_tree().create_timer(2.4).timeout.connect(func() -> void:
		test_set_pos.rpc(_keytest_cid, tpos + Vector3(0.0, 0.0, 1.6), 0.0)
	)
	get_tree().create_timer(3.0).timeout.connect(func() -> void:
		print("[KEYTEST] клиент %d жмёт F (посадка через RPC)" % _keytest_cid)
		test_keypress.rpc(_keytest_cid)
	)
	get_tree().create_timer(3.6).timeout.connect(func() -> void:
		if not turret.is_occupied() or int(turret.occupant_id) != _keytest_cid:
			_keytest_fail("клиент не сел: occupant=%d (ждём %d)" % [int(turret.occupant_id), _keytest_cid])
		else:
			print("[KEYTEST] клиент: посадка удержана (occupant=%d)" % _keytest_cid)
		print("[KEYTEST] клиент %d жмёт F (выход)" % _keytest_cid)
		test_keypress.rpc(_keytest_cid)
	)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		if turret.is_occupied():
			_keytest_fail("клиент не вышел: occupant=%d" % int(turret.occupant_id))
		else:
			print("[KEYTEST] клиент: выход по F (сиденье свободно)")
		if _keytest_ok and _keytest_toggles != 2:
			_keytest_fail("переключений состояния у хоста=%d (ждём 2: сел и вышел по одному разу)" % _keytest_toggles)
		if _keytest_ok:
			print("[KEYTEST_OK] сервер: 1 нажатие F = 1 переключение (хост и клиент, сел/вышел)")
		get_tree().create_timer(1.0).timeout.connect(func() -> void: get_tree().quit(0 if _keytest_ok else 1))
	)


## Опрос по кадрам: считаем, сколько раз mounted_idx менялся за одно нажатие.
func _keytest_poll() -> void:
	var host: Node = players.get(1)
	if host == null:
		return
	var m := int(host.mounted_idx)
	if m != _keytest_last_mounted:
		_keytest_toggles += 1
		print("[KEYTEST] смена состояния #%d: mounted %d -> %d" % [_keytest_toggles, _keytest_last_mounted, m])
		_keytest_last_mounted = m


## BUILD-31: клиент считает СВОИ переключения mounted_idx.
## Ожидание: 3 нажатия F (одно — в занятую турель, отказ) дают РОВНО 2
## переключения: посадка и выход. Если нажатие срабатывает дважды,
## переключений будет больше — это и есть «сам вышел из турели».
## Счётчики — в словаре: лямбды GDScript захватывают переменные по значению.
func _keytest_client_monitor() -> void:
	var my_id := multiplayer.get_unique_id()
	var st := {"last": -1, "toggles": 0}
	var me0: Node = players.get(my_id)
	if me0 != null:
		st["last"] = int(me0.mounted_idx)
	var t := Timer.new()
	t.wait_time = 0.1
	add_child(t)
	t.timeout.connect(func() -> void:
		var me: Node = players.get(my_id)
		if me == null:
			return
		var m := int(me.mounted_idx)
		if m != int(st["last"]):
			st["toggles"] = int(st["toggles"]) + 1
			print("[KEYTEST] клиент: mounted %d -> %d (переключение #%d)" % [int(st["last"]), m, int(st["toggles"])])
			st["last"] = m
	)
	t.start()
	get_tree().create_timer(5.0).timeout.connect(func() -> void:
		if _turret_star_id != my_id:
			return  # сценарий ведёт другого клиента — проверять нечего
		var n := int(st["toggles"])
		if n != 2:
			_keytest_fail("клиент: переключений mounted=%d (ждём 2: посадка и выход)" % n)
		else:
			print("[KEYTEST] клиент: 2 переключения mounted — посадка и выход без авто-выхода")
		if _keytest_ok:
			print("[KEYTEST_OK] клиент: F работает как одно действие")
	)


## BUILD-31, проверка 2: видит ли СОПЕРНИК посадку и поворот купола.
## occupant_id ставится только на сервере (try_mount_player), а _event_mount
## его не передаёт — значит у клиента сиденье может оставаться «свободным»,
## а купол — не следовать за взглядом сидящего.
func _keytest_sync_host() -> void:
	var host: Node = players.get(1)
	if host == null:
		_keytest_fail("нет ноды хоста")
		return
	_keytest_cid = 0
	for k in players.keys():
		if int(k) != 1:
			_keytest_cid = int(k)
			break
	test_turret_star.rpc(_keytest_cid)
	var turret: Node3D = turrets[0]
	var tpos: Vector3 = turret.position
	host.position = tpos + Vector3(0.0, 0.0, 1.6)
	host.rotation.y = 0.0
	get_tree().create_timer(0.4).timeout.connect(func() -> void: _keytest_press(KEY_F))
	get_tree().create_timer(1.2).timeout.connect(func() -> void:
		print("[KEYSYNC] сервер: хост сидит, поворачиваю купол (рыск 0.6) и поднимаю стволы (0.5)")
		host.rotation.y = 0.6
		host.head.rotation.x = 0.5
	)
	get_tree().create_timer(2.6).timeout.connect(func() -> void:
		print("[KEYSYNC] сервер: хост выходит из турели")
		_keytest_press(KEY_F)
	)
	get_tree().create_timer(4.4).timeout.connect(func() -> void:
		if _keytest_ok:
			print("[KEYSYNC_OK] сервер: соперник видит и посадку, и поворот купола")
		get_tree().create_timer(0.8).timeout.connect(func() -> void: get_tree().quit(0 if _keytest_ok else 1))
	)


## Клиент: проверяет occupant_id своей копии турели и поворот купола.
func _keytest_sync_client() -> void:
	var my_id := multiplayer.get_unique_id()
	get_tree().create_timer(1.6).timeout.connect(func() -> void:
		if turrets.size() == 0:
			print("[KEYSYNC_FAIL] клиент: нет турели в сцене")
			_keytest_ok = false
			return
		var t: Node3D = turrets[0]
		if not t.is_occupied():
			print("[KEYSYNC_FAIL] клиент: occupant_id=%d — турель выглядит СВОБОДНОЙ, хотя в ней сидит хост" % int(t.occupant_id))
			_keytest_ok = false
		else:
			print("[KEYSYNC] клиент: occupant_id=%d — сиденье занято" % int(t.occupant_id))
	)
	# BUILD-38: соперник видит и подъём стволов (наклон едет вместе с рыском).
	get_tree().create_timer(2.3).timeout.connect(func() -> void:
		if turrets.size() == 0:
			return
		var t: Node3D = turrets[0]
		var dp := float(t.aim_pitch())
		if dp < 0.3:
			print("[KEYSYNC_FAIL] клиент: стволы не поднялись за сидящим (наклон=%.2f рад, ждём ~0.5)" % dp)
			_keytest_ok = false
		else:
			print("[KEYSYNC] клиент: стволы поднялись вместе с сидящим (наклон=%.2f рад)" % dp)
	)
	get_tree().create_timer(2.6).timeout.connect(func() -> void:
		if turrets.size() == 0:
			return
		var t: Node3D = turrets[0]
		var dy := absf(wrapf(aim_yaw_of(t) - t.rotation.y, -PI, PI))
		if dy < 0.15:
			print("[KEYSYNC_FAIL] клиент: купол не довернулся за сидящим (доворот=%.2f рад, ждём ~0.6)" % dy)
			_keytest_ok = false
		else:
			print("[KEYSYNC] клиент: купол следует за сидящим (доворот=%.2f рад)" % dy)
	)
	get_tree().create_timer(3.6).timeout.connect(func() -> void:
		if turrets.size() == 0:
			return
		var t: Node3D = turrets[0]
		if t.is_occupied():
			print("[KEYSYNC_FAIL] клиент: после выхода хоста сиденье занято (occupant=%d)" % int(t.occupant_id))
			_keytest_ok = false
		else:
			print("[KEYSYNC] клиент: после выхода хоста сиденье свободно")
		if _keytest_ok:
			print("[KEYSYNC_OK] клиент: соперник видит занятость и поворот купола")
	)


func aim_yaw_of(t: Node3D) -> float:
	return wrapf(t.rotation.y + t.yaw_node.rotation.y, -PI, PI)


## BUILD-31, проверка 3: сидящего убили — сиденье должно освободиться на всех
## нодах, и в турель должен суметь сесть другой игрок.
func _keytest_death_host() -> void:
	var host: Node = players.get(1)
	if host == null:
		_keytest_fail("нет ноды хоста")
		return
	_keytest_cid = 0
	for k in players.keys():
		if int(k) != 1:
			_keytest_cid = int(k)
			break
	test_turret_star.rpc(_keytest_cid)
	var turret: Node3D = turrets[0]
	var tpos: Vector3 = turret.position
	host.position = tpos + Vector3(0.0, 0.0, 1.6)
	host.rotation.y = 0.0
	get_tree().create_timer(0.4).timeout.connect(func() -> void: _keytest_press(KEY_F))
	# Клиент встаёт перед турелью и расстреливает сидящего (4 × 25 = смерть).
	get_tree().create_timer(0.9).timeout.connect(func() -> void:
		test_set_pos.rpc(_keytest_cid, tpos + Vector3(0.0, 0.0, 2.4), 0.0)
	)
	for i in 4:
		get_tree().create_timer(1.3 + 0.35 * i).timeout.connect(func() -> void:
			test_star_shoot_at_host.rpc(_keytest_cid)
	)
	get_tree().create_timer(3.2).timeout.connect(func() -> void:
		# BUILD-34: «смерть» стала ранением — боец вываливается из турели, но жив.
		if not host.downed:
			_keytest_fail("хост не ранен (hp=%d) — сценарий не состоялся" % int(host.health))
		elif turret.is_occupied():
			_keytest_fail("сервер: сидящий ранен, но сиденье занято (occupant=%d)" % int(turret.occupant_id))
		elif int(host.mounted_idx) != -1:
			_keytest_fail("сервер: сидящий ранен, но mounted=%d" % int(host.mounted_idx))
		else:
			print("[DEATHT] сервер: сидящий ранен — он на полу, сиденье свободно")
	)
	get_tree().create_timer(3.6).timeout.connect(func() -> void:
		print("[DEATHT] сервер: клиент %d жмёт F в освобождённую турель" % _keytest_cid)
		test_keypress.rpc(_keytest_cid)
	)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		var c: Node = players.get(_keytest_cid)
		if c == null or int(c.mounted_idx) != 0 or not turret.is_occupied() or int(turret.occupant_id) != _keytest_cid:
			_keytest_fail("сервер: клиент не сел в освобождённую (mounted=%s, occupant=%d)" % [str(int(c.mounted_idx) if c else "-"), int(turret.occupant_id)])
		else:
			print("[DEATHT] сервер: клиент сел в освобождённую турель")
		if _keytest_ok:
			print("[DEATHT_OK] сервер: ранение сидящего освобождает турель (его поднимет товарищ)")
		get_tree().create_timer(1.4).timeout.connect(func() -> void: get_tree().quit(0 if _keytest_ok else 1))
	)


## Клиент стреляет в сторону сидящего хоста (тестовый путь, как в smoke).
@rpc("authority", "call_remote", "reliable")
func test_star_shoot_at_host(id: int) -> void:
	if not Game.death_test:
		return
	if id != multiplayer.get_unique_id():
		return
	var me: Node = players.get(id)
	var host: Node = players.get(1)
	if me == null or host == null:
		return
	var origin: Vector3 = me.head.global_position
	var dir: Vector3 = (host.global_position + Vector3(0.0, 1.1, 0.0) - origin).normalized()
	me.request_shoot.rpc_id(1, origin, dir, 1, 0)


## Клиент: после ранения сидящего сиденье должно быть свободным и у него.
func _keytest_death_client() -> void:
	var my_id := multiplayer.get_unique_id()
	get_tree().create_timer(3.4).timeout.connect(func() -> void:
		if _turret_star_id != my_id or turrets.size() == 0:
			return
		var t: Node3D = turrets[0]
		if t.is_occupied():
			print("[DEATHT_FAIL] клиент: сидящий умер, но у меня occupant=%d" % int(t.occupant_id))
			_keytest_ok = false
		else:
			print("[DEATHT] клиент: после ранения сидящего сиденье свободно")
	)
	get_tree().create_timer(4.6).timeout.connect(func() -> void:
		if _turret_star_id != my_id or turrets.size() == 0:
			return
		var me: Node = players.get(my_id)
		var t: Node3D = turrets[0]
		if me != null and int(me.mounted_idx) == 0 and t.is_occupied() and int(t.occupant_id) == my_id:
			print("[DEATHT_OK] клиент: сел в освобождённую турель (occupant=%d)" % my_id)
		else:
			print("[DEATHT_FAIL] клиент: не сел в освобождённую (mounted=%s, occupant=%d)" % [str(int(me.mounted_idx) if me else "-"), int(t.occupant_id)])
			_keytest_ok = false
	)


# ---------------------------------------------- BUILD-32: тест геометрии карты
## Проверяет лучами, что карта «Ущелье» собрана верно: пол на плато, настилы
## тропы под пробными точками, дно ущелья, площадки башен, туман, и что между
## тестовыми спавнами есть прямая видимость (это нужно headless-сценариям).
## Запуск: godot --headless --path . res://scenes/game/arena.tscn -- maptest
func _map_test_run() -> void:
	var ok := true
	var map := get_node_or_null("Map")
	if map == null:
		print("[MAPTEST_FAIL] нет узла Map")
		get_tree().quit(1)
		return
	var space := get_world_3d().direct_space_state

	# 1) Плато: под каждым спавном обеих сторон — пол ровно на y = 0.
	var spawn_ok := true
	for pt in Map.SPAWN_NORTH + Map.SPAWN_SOUTH:
		var hit := _map_ray(space, pt + Vector3(0.0, 1.5, 0.0), pt + Vector3(0.0, -3.0, 0.0))
		if hit.is_empty() or absf(float(hit.position.y)) > 0.35:
			spawn_ok = false
			ok = false
			print("[MAPTEST_FAIL] под спавном %s нет пола плато (луч=%s)" % [str(pt), str(hit)])
	if spawn_ok:
		print("[MAPTEST] плато под всеми %d спавнами: ровно y=0" % (Map.SPAWN_NORTH.size() + Map.SPAWN_SOUTH.size()))

	# 2) BUILD-39: турели стоят ВПЛОТНУЮ к кромке, но на твёрдом плато:
	#    под основанием — пол y = 0, а между краем основания и обрывом ~0.3 м.
	for tp in TURRET_SPAWNS:
		var rim_dir := 1.0 if tp.z > 0.0 else -1.0
		var hit2 := _map_ray(space, tp + Vector3(0.0, 1.2, 0.0), tp + Vector3(0.0, -3.0, 0.0))
		if hit2.is_empty() or absf(float(hit2.position.y)) > 0.35:
			ok = false
			print("[MAPTEST_FAIL] под турелью %s нет плато (луч=%s)" % [str(tp), str(hit2)])
		var gap: float = (absf(tp.z) - Map.TURRET_BASE_R) - Map.RIM_EDGE_Z
		if absf(gap - Map.TURRET_RIM_GAP) > 0.15:
			ok = false
			print("[MAPTEST_FAIL] турель %s: зазор до обрыва %.2f м (ждём ~%.2f)" % [str(tp), gap, Map.TURRET_RIM_GAP])
		else:
			print("[MAPTEST] турель %s: основание на плато, до обрыва %.2f м" % [str(tp), gap])
		# За краем основания — 0.3 м полки и обрыв: в 0.6 м наружу пола нет.
		var outside2 := Vector3(tp.x, tp.y + 1.0, tp.z - rim_dir * (Map.TURRET_BASE_R + Map.TURRET_RIM_GAP + 0.6))
		var hit2b := _map_ray(space, outside2, outside2 + Vector3(0.0, -8.0, 0.0))
		if hit2b.is_empty() or float(hit2b.position.y) < -1.0:
			print("[MAPTEST] за кромкой у турели — обрыв (как и задумано)")
		else:
			ok = false
			print("[MAPTEST_FAIL] за кромкой у турели %s найден пол: %s" % [str(tp), str(hit2b)])

	# 3) BUILD-39: лестниц-серпантинов больше нет — там, где висели марши
	#    (две полосы вдоль обрыва на западной и восточной половинах), пусто.
	var old_path_pts := [
		Vector3(-25.0, 0.0, 20.8), Vector3(-13.0, -15.0, 17.4), Vector3(-25.0, -30.0, 20.8),
		Vector3(-13.0, -45.0, 17.4), Vector3(25.0, -15.0, -17.4), Vector3(13.0, -45.0, -20.8),
	]
	var path_clean := true
	for pt in old_path_pts:
		var hit3 := _map_ray(space, pt + Vector3(0.0, 1.0, 0.0), pt + Vector3(0.0, -2.0, 0.0))
		if not hit3.is_empty() and float(hit3.position.y) > Map.DEEP_Y:
			path_clean = false
			print("[MAPTEST_FAIL] на месте прежней лестницы %s что-то есть: %s" % [str(pt), str(hit3)])
	if path_clean:
		print("[MAPTEST] лестниц-серпантинов нет: на месте прежних маршей пусто")

	# 4) Дно ущелья.
	var hit4 := _map_ray(space, Vector3(0.0, Map.GORGE_FLOOR_Y + 2.0, 0.0), Vector3(0.0, Map.GORGE_FLOOR_Y - 3.0, 0.0))
	if not hit4.is_empty() and absf(float(hit4.position.y) - Map.GORGE_FLOOR_Y) < 0.5:
		print("[MAPTEST] дно ущелья на y=%.0f" % Map.GORGE_FLOOR_Y)
	else:
		ok = false
		print("[MAPTEST_FAIL] дна ущелья нет: %s" % str(hit4))

	# 5) Над центром ущелья настила нет: прыжком ущелье не перескочить.
	var hit5 := _map_ray(space, Vector3(0.0, 0.5, 0.0), Vector3(0.0, -1.0, 0.0))
	if hit5.is_empty() or float(hit5.position.y) < -1.0:
		print("[MAPTEST] над центром ущелья пусто (провал на дно: %s)" % ("нет дна" if hit5.is_empty() else "y=%.0f" % float(hit5.position.y)))
	else:
		ok = false
		print("[MAPTEST_FAIL] в центре ущелья что-то есть: %s" % str(hit5))

	# 6) BUILD-38: точки прорыва периметра стоят на плато своего берега —
	# туда бегут полые люди, вылезшие из ущелья.
	for bpos in [Map.BREACH_N, Map.BREACH_S]:
		var hit6 := _map_ray(space, bpos + Vector3(0.0, 3.0, 0.0), bpos - Vector3(0.0, 2.0, 0.0))
		if hit6.is_empty() or absf(float(hit6.position.y)) > 0.6:
			ok = false
			print("[MAPTEST_FAIL] под точкой прорыва %s нет плато (луч=%s)" % [str(bpos), str(hit6)])
		else:
			print("[MAPTEST] точка прорыва %s на плато берега" % str(bpos))

	# 7) BUILD-38: ущелье чистое — с кромки одного берега видно кромку другого
	# (тумана больше нет, обзор через пропасть открыт).
	var rim_view := _map_ray(space, Vector3(0.0, 1.2, Map.RIM_Z - 0.8), Vector3(0.0, 1.2, -(Map.RIM_Z - 0.8)))
	if rim_view.is_empty():
		print("[MAPTEST] ущелье просматривается насквозь (с кромки видно кромку)")
	else:
		ok = false
		print("[MAPTEST_FAIL] в ущелье препятствие на линии кромка-кромка: %s" % str(rim_view))

	# 8) Прямая видимость между тестовыми спавнами (нужна smoke/ffa-тестам).
	var s0: Vector3 = Map.SPAWN_NORTH[0] + Vector3(0.0, 1.1, 0.0)
	var s1: Vector3 = Map.SPAWN_NORTH[1] + Vector3(0.0, 1.1, 0.0)
	var s2: Vector3 = Map.SPAWN_NORTH[2] + Vector3(0.0, 1.1, 0.0)
	for pair in [[s0, s1], [s0, s2], [s1, s2]]:
		var hit8 := _map_ray(space, pair[0], pair[1])
		if hit8.is_empty():
			print("[MAPTEST] видимость между спавнами есть")
		else:
			ok = false
			print("[MAPTEST_FAIL] между спавнами %s препятствие: %s" % [str([pair[0], pair[1]]), str(hit8)])


	# BUILD-32: тестовые спавны (headless-сценарии стреляют «прямо вперёд»).
	var ts_ok := true
	for i in Map.SPAWN_TEST.size():
		var sp: Vector3 = Map.SPAWN_TEST[i]
		var floor_hit := _map_ray(space, sp + Vector3(0.0, 6.0, 0.0), sp - Vector3(0.0, 8.0, 0.0))
		var fy: float = float(floor_hit.position.y) if not floor_hit.is_empty() else -99.0
		if absf(fy) > 0.6:
			ts_ok = false
			print("[MAPTEST_FAIL] под тестовым спавном %d нет плато (y=%.2f, %s)" % [i, fy, str(floor_hit)])
	for pair2 in [[0, 1], [2, 3]]:
		var a: Vector3 = Map.SPAWN_TEST[pair2[0]] + Vector3(0.0, 1.6, 0.0)
		var b: Vector3 = Map.SPAWN_TEST[pair2[1]] + Vector3(0.0, 1.6, 0.0)
		var clear := _map_ray(space, a, b)
		if clear.is_empty():
			print("[MAPTEST] линия огня между тестовыми спавнами %d-%d свободна" % pair2)
		else:
			ts_ok = false
			print("[MAPTEST_FAIL] между тестовыми спавнами %d-%d препятствие: %s" % [pair2[0], pair2[1], str(clear.get("collider", null))])
	ok = ok and ts_ok

	print("[MAPTEST_OK] геометрия ущелья проверена" if ok else "[MAPTEST_FAIL] есть замечания")
	get_tree().quit(0 if ok else 1)


# ---------------------------------------------------------------- ходьба по карте (BUILD-35)
## Проверка «ногами»: капсула игрока реально идёт по спуску и по лестнице башни.
## Лучи показывают, что настил есть, но не показывают, ПРОХОДИМ ли он: ступеньки,
## навесы и разрывы видны только физике. Этот сценарий — именно про это.

var _walk_checks := 0
var _walk_fails := 0


func _walk_ok(cond: bool, label: String) -> void:
	_walk_checks += 1
	if cond:
		print("[WALKTEST] OK   %s" % label)
	else:
		_walk_fails += 1
		print("[WALKTEST] ФЕЙЛ %s" % label)


## Капсула игрока (те же размеры, что у настоящего: радиус 0.35, высота 1.8).
func _make_walker(pos: Vector3) -> CharacterBody3D:
	var b := CharacterBody3D.new()
	b.name = "WalkProbe"
	b.collision_layer = 2      # сам ничего не задевает…
	b.collision_mask = 1       # …а сталкивается с миром (слой карты = 1)
	var cs := CollisionShape3D.new()
	cs.name = "WalkProbeShape"
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0.0, 0.9, 0.0)
	b.add_child(cs)
	add_child(b)
	b.global_position = pos
	return b


## Провести капсулу по 3D-маршруту: скорость направлена ВДОЛЬ сегмента (вместе с
## подъёмом-спуском), шаг — кадр физики. Так проверяется именно геометрия: если на
## пути ступенька, дыра или преграда — капсула встанет. Ведём её так же, как идёт
## живой игрок по настилу: маршрут заранее проложен по полосам и площадкам.
func _walk_route(body: CharacterBody3D, route: Array, names: Array, speed: float, trace := false, trace_from := 0) -> int:
	var reached := 0
	var frames := 0
	var dt := 1.0 / float(Engine.physics_ticks_per_second)
	for i in route.size():
		var target: Vector3 = route[i]
		var t := 0.0
		var blocked := 0.0
		var last := body.global_position
		while t < 25.0:
			var cur := body.global_position
			if trace:
				if i >= trace_from and frames % 5 == 0:
					print("[WALKTRC] %s: %s (пол=%s)" % [names[i], str(cur), str(body.is_on_floor())])
				frames += 1
			var seg := target - cur
			seg.y = 0.0
			# Критерий прихода жёсткий: с мягким допуском на 1 м тест «проходил»
			# дыру в настиле, стоя на соседнем марше.
			if seg.length() <= 0.6 and absf(target.y - cur.y) <= 1.0:
				break
			var dir3 := (target - cur).normalized()
			# Подъём разрешаем только в пределах уклона марша (sin ~0.53 у спуска и
			# ~0.35 у лестницы). Иначе капсула «взлетала» бы прямо к цели, и проверка
			# перестала бы замечать, что подъёма нет.
			var v := dir3 * speed
			if v.y > 0.62:
				v.y = 0.0
			if not body.is_on_floor():
				v.y -= 14.0                  # в воздухе падаем — дыра сразу видна
			elif dir3.y <= 0.0:
				v.y -= 1.0                   # прижимаемся к настилу
			body.velocity = v
			body.move_and_slide()
			# Застряли: за 0.8 с не сдвинулись с места.
			if cur.distance_to(last) < 0.04:
				blocked += dt
				if blocked > 0.8:
					print("[WALKTEST] застряли у «%s» (я на %s, цель %s, на полу=%s)" % [
						names[i], str(cur), str(target), str(body.is_on_floor())])
					for ci in body.get_slide_collision_count():
						var col := body.get_slide_collision(ci)
						var node: Object = col.get_collider()
						var nm: String = (node as Node).name if node is Node else str(node)
						var extra := ""
						if node is Node3D:
							extra = " позиция %s" % str((node as Node3D).global_position)
							for ch in (node as Node3D).get_children():
								if ch is CollisionShape3D and ch.shape is BoxShape3D:
									extra += " размер %s" % str((ch.shape as BoxShape3D).size)
						print("[WALKTEST]   преграда «%s»:%s | нормаль %s, точка %s" % [nm, extra, str(col.get_normal()), str(col.get_position())])
					return reached
			else:
				blocked = 0.0
			last = cur
			t += dt
			await get_tree().physics_frame
		if t >= 25.0:
			print("[WALKTEST] не дошли до «%s» за 25 с (я на %s)" % [names[i], str(body.global_position)])
			return reached
		reached += 1
	return reached


func _walk_test_run() -> void:
	print("[WALKTEST] --- проверяю карту ногами (спуска на дно больше нет) ---")
	await _walk_plateau_run(1.0)
	await _walk_plateau_run(-1.0)
	print("[WALKTEST] итог: проверок=%d, провалов=%d" % [_walk_checks, _walk_fails])
	if _walk_fails == 0:
		print("[WALKTEST_OK] плато обоих берегов проходимо, площадка у турели достижима")
	else:
		print("[WALKTEST_FAIL] проверок=%d, провалов=%d" % [_walk_checks, _walk_fails])
	get_tree().quit(0 if _walk_fails == 0 else 1)


## BUILD-39: спуска в ущелье больше нет, поэтому капсула обходит ПЛАТО берега:
## спавн -> фланг у кромки -> напротив точки прорыва -> площадка у турели ->
## другой фланг -> обратно. Проверка ловит дыры и провалы в плато (после сноса
## башен и лестниц на месте построек должно быть ровное поле).
func _walk_plateau_run(side: float) -> void:
	var tag := "север" if side > 0.0 else "юг"
	# Маршрут задан для северного берега; южный — его поворот на 180°
	# (карта симметрична: турель, кромка, валуны и спавны зеркальны).
	var base: Array = [
		Vector3(-14.0, 0.6, 38.0),
		Vector3(-14.0, 0.6, 27.0),
		Vector3(-24.0, 0.6, 24.5),
		Vector3(0.0, 0.6, 27.5),
		Vector3(-10.4, 0.6, 26.0),
		Vector3(24.0, 0.6, 24.5),
		Vector3(-14.0, 0.6, 38.0),
	]
	var names: Array = [
		"спавн", "тыл у спавна", "фланг у кромки (первый)", "напротив точки прорыва",
		"площадка у турели", "фланг у кромки (второй)", "обратно на спавн",
	]
	var route: Array = []
	for pt in base:
		route.append(Vector3(side * float(pt.x), float(pt.y), side * float(pt.z)))
	var walker := _make_walker(route[0])
	await get_tree().physics_frame
	var reached := await _walk_route(walker, route, names, 6.0)
	_walk_ok(reached == route.size(), "%s: плато пройдено по всему периметру (%d из %d точек)" % [tag, reached, route.size()])
	walker.queue_free()


func _map_ray(space: PhysicsDirectSpaceState3D, from: Vector3, to: Vector3) -> Dictionary:
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.collide_with_areas = false
	return space.intersect_ray(q)
