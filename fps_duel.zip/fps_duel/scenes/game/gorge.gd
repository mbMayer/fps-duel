extends Node3D
class_name GorgeMap
## BUILD-32/38/39: карта «УЩЕЛЬЕ» — два плато, разделённые пропастью.
## BUILD-38: башен и тумана нет. BUILD-39: нет и лестниц-серпантинов на дно,
## мины убраны — на карте остались только ущелье и турели у кромки.
##
## ГЕОМЕТРИЯ (вид сверху, север — вверху):
##      z = +40  +--------------- северное плато ----------------+   <- берег A
##               |       прорыв периметра (0, 0, +26)            |
##               |            турель (-7, 0, +23.9)              |
##      z = 0    +---------- КРАЙ ОБРЫВА (z = +22.5) ------------+
##               |            УЩЕЛЬЕ (45 м)                     |  <- дно -60 м
##      z = 0    +---------- КРАЙ ОБРЫВА (z = -22.5) ------------+
##               |            турель (+7, 0, -23.9)              |
##               |       прорыв периметра (0, 0, -26)           |
##      z = -40  +--------------- южное плато -----------------+   <- берег B
##
## Спуска на дно НЕТ: берега изолированы, свои — на своём берегу. Дно ущелья
## работает только на «Полых людей»: они подходят по нему и лезут вверх по
## стене у кромки. Турели стоят вплотную к обрыву — стволы нависают над
## ущельем, поэтому видно и стену, и дно.

# ---------------------------------------------------------------- размеры карты
const RIM_Z := 22.5           # край обрыва: ширина ущелья 2*RIM_Z = 45 м
const MAP_HALF_X := 30.0      # половина ширины карты
const MAP_OUT_Z := 40.0       # внешний край плато
const GORGE_FLOOR_Y := -60.0  # дно ущелья
const CLIFF_H := 14.0         # высота стен по периметру (над плато)
const CLIFF_T := 1.0          # толщина стены обрыва (плита скалы под кромкой)
## BUILD-39: плита скалы стоит ПОСЕРЕДИНЕ линии RIM_Z, поэтому её верх на y = 0
## выдаётся на 0.5 м в сторону ущелья — настоящий край обрыва (где начинается
## падение) находится здесь:
const RIM_EDGE_Z := RIM_Z - CLIFF_T * 0.5   # 22.0
## BUILD-38: туман убран (и объём, и урон). Высота осталась как граница «глубины
## ущелья»: ниже неё «Полые люди» копят силы и оттуда начинают подъём по стене.
const DEEP_Y := -15.0

# ---------------------------------------------------------------- турели и прорыв
## BUILD-39: турели стоят ВПЛОТНУЮ к обрыву. Основание турели — цилиндр
## радиусом 1.12 м, поэтому центр отнесён от КРАЯ ОБРЫВА так, чтобы между краем
## основания и падением осталось ровно 0.3 м: 22.0 + 1.12 + 0.3 = 23.42.
## Купол и стволы при этом нависают над ущельем, а сама установка ещё стоит на
## твёрдом: под ней плато и полка скалы.
const TURRET_RIM_GAP := 0.3    # зазор от края основания турели до обрыва
const TURRET_BASE_R := 1.12    # радиус основания (см. turret.gd)
const TURRET_POS_N := Vector3(-7.0, 0.0, RIM_EDGE_Z + TURRET_BASE_R + TURRET_RIM_GAP)
const TURRET_POS_S := Vector3(7.0, 0.0, -(RIM_EDGE_Z + TURRET_BASE_R + TURRET_RIM_GAP))
## BUILD-38: башен нет — полый человек, вылезший на плато, бежит к этой точке
## («прорыв периметра»): она за кромкой на оси берега, в тылу позиций.
const BREACH_N := Vector3(0.0, 0.2, 26.0)
const BREACH_S := Vector3(0.0, 0.2, -26.0)

# ---------------------------------------------------------------- точки спавна
## Спавны северного плато — в тылу, лицом к ущелью.
## BUILD-32: точки для headless-проверок (турельные сценарии, стрельба) — пара
## на северном плато лицом к лицу. Коридор открыт: от точки 0 к 1 и от 2 к 3 нет
## ни укрытий, ни построек, поэтому выстрел «прямо вперёд» попадает в напарника
## (так работают старые тесты).
## BUILD-39: точки остались на прежнем месте — там, где раньше стояли марши
## лестницы, теперь чистое плато (проверяется `walktest`).
const SPAWN_TEST := [
	Vector3(-25.0, 1.0, 35.5),
	Vector3(-9.0, 1.0, 35.5),
	Vector3(-28.5, 1.0, 35.5),
	Vector3(-13.0, 1.0, 35.5),
]
## Куда смотрят тестовые спавны (0 и 2 — на восток, 1 и 3 — на запад).
const SPAWN_TEST_YAW := [-PI * 0.5, PI * 0.5, -PI * 0.5, PI * 0.5]

const SPAWN_NORTH := [
	Vector3(-14.0, 1.0, 38.0),
	Vector3(14.0, 1.0, 38.0),
	Vector3(-22.0, 1.0, 38.0),
	Vector3(22.0, 1.0, 38.0),
]
## Спавны южного плато (зеркально).
const SPAWN_SOUTH := [
	Vector3(14.0, 1.0, -38.0),
	Vector3(-14.0, 1.0, -38.0),
	Vector3(22.0, 1.0, -38.0),
	Vector3(-22.0, 1.0, -38.0),
]
# ---------------------------------------------------------------- материалы
var _mat_ground: StandardMaterial3D
var _mat_cliff: StandardMaterial3D
var _mat_deep: StandardMaterial3D
var _mat_rock: StandardMaterial3D

func _ready() -> void:
	_build_materials()
	_build_plateaus()
	_build_gorge()
	_build_perimeter()
	_build_cover()


func _build_materials() -> void:
	_mat_ground = StandardMaterial3D.new()
	_mat_ground.albedo_color = Color(0.42, 0.38, 0.30)   # сухая земля плато
	_mat_ground.roughness = 0.95
	_mat_cliff = StandardMaterial3D.new()
	_mat_cliff.albedo_color = Color(0.34, 0.30, 0.27)    # скала
	_mat_cliff.roughness = 1.0
	_mat_deep = StandardMaterial3D.new()
	_mat_deep.albedo_color = Color(0.16, 0.17, 0.19)     # дно ущелья
	_mat_deep.roughness = 1.0
	_mat_rock = StandardMaterial3D.new()
	_mat_rock.albedo_color = Color(0.50, 0.47, 0.42)     # укрытия-валуны
	_mat_rock.roughness = 0.95


# ---------------------------------------------------------------- помощники
## Куб: меш + коллизия в одном StaticBody3D (collide = false — только меш).
func _box(center: Vector3, size: Vector3, rot: Vector3, mat: Material, collide := true, node_name := "Box") -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = center
	body.rotation = rot
	if collide:
		body.collision_layer = 1
		body.collision_mask = 0
	var mesh := MeshInstance3D.new()
	mesh.name = "Mesh"
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	mesh.material_override = mat
	body.add_child(mesh)
	if collide:
		var shape := CollisionShape3D.new()
		shape.name = "Shape"
		var bs := BoxShape3D.new()
		bs.size = size
		shape.shape = bs
		body.add_child(shape)
	add_child(body)
	return body


func _slab(center: Vector3, size: Vector3, mat: Material, node_name := "Slab", rot := Vector3.ZERO) -> StaticBody3D:
	return _box(center, size, rot, mat, true, node_name)


# ---------------------------------------------------------------- плато и ущелье
func _build_plateaus() -> void:
	var depth := (MAP_OUT_Z - RIM_Z) * 0.5
	var thick := 2.0
	_slab(Vector3(0.0, -thick * 0.5, RIM_Z + depth), Vector3(MAP_HALF_X * 2.0, thick, depth * 2.0), _mat_ground, "PlateauN")
	_slab(Vector3(0.0, -thick * 0.5, -(RIM_Z + depth)), Vector3(MAP_HALF_X * 2.0, thick, depth * 2.0), _mat_ground, "PlateauS")


func _build_gorge() -> void:
	# Верх плиты скалы — на 3 см НИЖЕ уровня плато: иначе верх плато и полка
	# скалы лежат в одной плоскости на полосе 0.5 м, и в кадре мигает «лесенка»
	# (z-fighting). Три сантиметра на глаз не видны, а артефакт уходит.
	var top := -0.03
	# Отвесные стены обрыва: от дна до самого края плато.
	_slab(Vector3(0.0, (GORGE_FLOOR_Y + top) * 0.5, RIM_Z), Vector3(MAP_HALF_X * 2.0, absf(GORGE_FLOOR_Y - top), CLIFF_T), _mat_cliff, "CliffN")
	_slab(Vector3(0.0, (GORGE_FLOOR_Y + top) * 0.5, -RIM_Z), Vector3(MAP_HALF_X * 2.0, absf(GORGE_FLOOR_Y - top), CLIFF_T), _mat_cliff, "CliffS")
	# Дно ущелья.
	_slab(Vector3(0.0, GORGE_FLOOR_Y - 1.0, 0.0), Vector3(MAP_HALF_X * 2.0, 2.0, RIM_Z * 2.0), _mat_deep, "GorgeFloor")


func _build_perimeter() -> void:
	var wall_y := CLIFF_H * 0.5 - 0.5
	_slab(Vector3(-MAP_HALF_X, wall_y, 0.0), Vector3(1.0, CLIFF_H, MAP_OUT_Z * 2.0), _mat_cliff, "EdgeW")
	_slab(Vector3(MAP_HALF_X, wall_y, 0.0), Vector3(1.0, CLIFF_H, MAP_OUT_Z * 2.0), _mat_cliff, "EdgeE")
	_slab(Vector3(0.0, wall_y, MAP_OUT_Z), Vector3(MAP_HALF_X * 2.0, CLIFF_H, 1.0), _mat_cliff, "EdgeN")
	_slab(Vector3(0.0, wall_y, -MAP_OUT_Z), Vector3(MAP_HALF_X * 2.0, CLIFF_H, 1.0), _mat_cliff, "EdgeS")


# ---------------------------------------------------------------- укрытия
## Валуны для перестрелок. Коридор между спавнами (x от -20 до 20 при
## z ~ 31..34) и площадка вокруг турели оставлены открытыми: там стреляют
## headless-тесты, и линия огня не должна упираться в камень.
func _build_cover() -> void:
	var ys := 0.75
	for z_side in [1.0, -1.0]:
		# BUILD-33: укрытия на расширенном плато; коридор между тестовыми точками
		# (z = 36, |x| 13..21) и площадки спавнов остаются открытыми.
		_slab(Vector3(-26.0, ys, 30.0 * z_side), Vector3(3.0, 1.5, 2.2), _mat_rock, "Cover")
		_slab(Vector3(26.0, ys, 30.0 * z_side), Vector3(3.0, 1.5, 2.2), _mat_rock, "Cover")
		_slab(Vector3(-18.0, ys, 30.0 * z_side), Vector3(2.4, 1.5, 2.4), _mat_rock, "Cover")
		_slab(Vector3(18.0, ys, 30.0 * z_side), Vector3(2.4, 1.5, 2.4), _mat_rock, "Cover")
		_slab(Vector3(-26.0, ys, 38.5 * z_side), Vector3(2.6, 1.5, 2.0), _mat_rock, "Cover")
		_slab(Vector3(26.0, ys, 38.5 * z_side), Vector3(2.6, 1.5, 2.0), _mat_rock, "Cover")
