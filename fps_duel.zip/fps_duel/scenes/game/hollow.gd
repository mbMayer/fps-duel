extends CharacterBody3D
## BUILD-33: «Полый человек» — существо из тумана ущелья (по мотивам фильма).
##
## Поведение (считается ТОЛЬКО на сервере):
##   1) родился на дне у стены ущелья и КАРАБКАЕТСЯ вверх по скале;
##   2) вылез на кромку — бежит к башне своего берега;
##   3) дошёл до башни — «прорыв»: снимает целостность периметра;
##   4) рядом с игроком — бьёт его (по кулдауну).
## Убить можно из оружия и турели (в т.ч. авто).
##
## Синхронизация: сервер шлёт состояние 15 Гц (ненадёжный канал), клиенты
## интерполируют позицию и поворот, как у игроков.

const GROUP := "hollows"

const MAX_HP := 100.0
const CLIMB_SPEED := 3.4       # м/с вверх по стене
const WALK_SPEED := 4.6        # м/с по плато
const ATTACK_RANGE := 1.9      # м — дистанция удара по игроку
const ATTACK_DAMAGE := 14.0
const ATTACK_COOLDOWN := 1.1   # с между ударами
const BREACH_RANGE := 2.8      # м до башни — «прорыв»
const BODY_H := 1.75           # высота существа (капсула)

## Кто это: +1 — северный берег, -1 — южный.
var side := 1.0
var hp := MAX_HP
var dead := false
## 0 — карабкается по стене, 1 — идёт по плато, 2 — прорыв (удаляется)
var phase := 0
var target_pos := Vector3.ZERO   # цель на плато (база башни)
var speed_jitter := 1.0          # разброс скорости, чтобы толпа не шла строем
var seen_by_net := 0             # счётчик входящих пакетов (для тестов)

var _arena: Node = null
var _next_attack_ms := 0
var _climb_x := 0.0
var _net_timer := 0.0
const NET_INTERVAL := 0.0667     # 15 Гц

# --- интерполяция на клиентах ---
var _target_pos := Vector3.ZERO
var _target_yaw := 0.0
var _bob := 0.0

var _body: MeshInstance3D = null


func _ready() -> void:
	add_to_group(GROUP)
	_arena = get_tree().current_scene
	_build_mesh()
	_target_pos = position
	_target_yaw = rotation.y
	# BUILD-35: у «Полого» есть RPC состояния и ухода — имя должно совпадать у
	# всех нод (Hollow7), иначе пакет не находит цель у товарища.
	if name.begins_with("@"):
		push_error("[RPC] «Полый» добавлен под автоименем %s — у товарищей путь не совпадёт" % name)


## --- Создание (вызывает арена на сервере) ----------------------------------
## start_pos — точка на дне у стены; aim — база башни, к которой бежать.
func setup(start_pos: Vector3, aim: Vector3, rng_seed: int) -> void:
	position = start_pos
	_target_pos = start_pos
	side = signf(start_pos.z if absf(start_pos.z) > 0.001 else 1.0)
	target_pos = aim
	_climb_x = start_pos.x
	var r := RandomNumberGenerator.new()
	r.seed = rng_seed
	speed_jitter = r.randf_range(0.85, 1.15)
	rotation.y = PI if side > 0.0 else 0.0     # лицом к берегу (вверх по стене)


# ---------------------------------------------------------------- геометрия
## Существо: вытянутое тело, длинные руки, голова с тусклым свечением глаз.
## «Полые» — почти без лица, как в фильме.
func _build_mesh() -> void:
	var mat_body := StandardMaterial3D.new()
	mat_body.albedo_color = Color(0.16, 0.17, 0.19)
	mat_body.roughness = 0.95
	var mat_limb := StandardMaterial3D.new()
	mat_limb.albedo_color = Color(0.13, 0.14, 0.16)

	_body = MeshInstance3D.new()
	_body.name = "Body"
	var torso := BoxMesh.new()
	torso.size = Vector3(0.46, 0.72, 0.28)
	_body.mesh = torso
	_body.position = Vector3(0.0, 1.24, 0.0)
	_body.material_override = mat_body
	add_child(_body)

	var head := MeshInstance3D.new()
	head.name = "Head"
	var hm := SphereMesh.new()
	hm.radius = 0.17
	hm.height = 0.34
	head.mesh = hm
	head.position = Vector3(0.0, 1.75, 0.0)
	head.material_override = mat_body
	add_child(head)

	# Глаза — единственное «светлое» пятно: их видно в тумане.
	for sx in [-1.0, 1.0]:
		var eye := MeshInstance3D.new()
		eye.name = "Eye"
		var em := SphereMesh.new()
		em.radius = 0.035
		em.height = 0.07
		eye.mesh = em
		eye.position = Vector3(0.06 * sx, 1.77, -0.15)
		var emat := StandardMaterial3D.new()
		emat.albedo_color = Color(0.95, 0.65, 0.35)
		emat.emission_enabled = true
		emat.emission = Color(0.95, 0.45, 0.2)
		emat.emission_energy_multiplier = 2.2
		eye.material_override = emat
		add_child(eye)

	# Длинные руки (до колен) и ноги.
	for sx in [-1.0, 1.0]:
		var arm := MeshInstance3D.new()
		arm.name = "Arm"
		var am := BoxMesh.new()
		am.size = Vector3(0.14, 1.05, 0.14)
		arm.mesh = am
		arm.position = Vector3(0.32 * sx, 1.15, 0.0)
		arm.rotation.z = 0.16 * sx
		arm.material_override = mat_limb
		add_child(arm)
		var leg := MeshInstance3D.new()
		leg.name = "Leg"
		var lm := BoxMesh.new()
		lm.size = Vector3(0.16, 0.85, 0.16)
		leg.mesh = lm
		leg.position = Vector3(0.13 * sx, 0.44, 0.0)
		leg.material_override = mat_limb
		add_child(leg)

	# Коллизия: капсула по росту.
	var col := CollisionShape3D.new()
	var caps := CapsuleShape3D.new()
	caps.radius = 0.38
	caps.height = BODY_H
	col.shape = caps
	col.position = Vector3(0.0, BODY_H * 0.5, 0.0)
	add_child(col)
	collision_layer = 1     # тело: ловят выстрелы (маска 3) и сталкиваются игроки
	collision_mask = 1


# ---------------------------------------------------------------- логика
func is_server() -> bool:
	return multiplayer.multiplayer_peer != null and multiplayer.is_server()


func _physics_process(delta: float) -> void:
	if dead:
		return
	if _arena == null:
		_arena = get_tree().current_scene
	if not is_server():
		_client_tick(delta)
		return
	_server_tick(delta)
	_net_timer += delta
	if _net_timer >= NET_INTERVAL:
		_net_timer = 0.0
		_send_state.rpc(position, rotation.y, phase, hp)


## Карабканье вверх по стене и бег по плато.
func _server_tick(delta: float) -> void:
	if phase == 0:
		# Подъём по скале: ровно вверх, с лёгким зигзагом, без гравитации.
		var y := position.y + CLIMB_SPEED * speed_jitter * delta
		var wob := sin(y * 0.35) * 0.35
		position = Vector3(_climb_x + wob, y, position.z)
		if y >= 0.05:
			# Вылез на кромку: дальше — по земле, к башне.
			phase = 1
			position = Vector3(position.x, 0.1, side * (absf(position.z) + 0.6))
			velocity = Vector3.ZERO
		rotation.y = PI if side > 0.0 else 0.0
		return

	# Фаза 2: бежим к башне, обходя препятствия силами физики.
	var to := target_pos - position
	to.y = 0.0
	if to.length() < BREACH_RANGE:
		_breach()
		return
	var dir := to.normalized()
	velocity.x = dir.x * WALK_SPEED * speed_jitter
	velocity.z = dir.z * WALK_SPEED * speed_jitter
	if not is_on_floor():
		velocity.y -= 22.0 * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	rotation.y = atan2(-dir.x, -dir.z)
	_bob += delta * 7.0
	if _body != null:
		_body.position.y = 1.24 + sin(_bob) * 0.05

	# Атака ближайшего игрока.
	var now := Time.get_ticks_msec()
	if now >= _next_attack_ms and _arena != null:
		var victim: Node = _arena.nearest_player_within(position, ATTACK_RANGE)
		if victim != null:
			_next_attack_ms = now + int(ATTACK_COOLDOWN * 1000.0)
			_arena.hollow_hit_player(victim, ATTACK_DAMAGE, self)


## Прорыв: существо дошло до башни — периметр теряет прочность.
func _breach() -> void:
	phase = 2
	if _arena != null:
		_arena.hollow_breach(self)
	_net_gone.rpc()
	queue_free()


## BUILD-33: клиент убирает свою копию, когда сервер её удалил.
@rpc("authority", "call_remote", "reliable")
func _net_gone() -> void:
	queue_free()


func take_damage(dmg: float, _attacker_id: int) -> void:
	if dead:
		return
	hp -= dmg
	if hp <= 0.0:
		die()


func die() -> void:
	if dead:
		return
	dead = true
	if _arena != null:
		_arena.hollow_died(self)
	_net_gone.rpc()
	queue_free()


# ---------------------------------------------------------------- сеть (клиент)
func _client_tick(delta: float) -> void:
	var k := clampf(delta * 8.0, 0.0, 1.0)
	position = position.lerp(_target_pos, k)
	rotation.y = lerp_angle(rotation.y, _target_yaw, k)
	# Карабканье читается по покачиванию корпуса.
	if _body != null:
		_bob += delta * (7.0 if phase == 1 else 3.0)
		_body.position.y = 1.24 + sin(_bob) * 0.05


@rpc("authority", "call_remote", "unreliable_ordered")
func _send_state(pos: Vector3, yaw: float, ph: int, h: float) -> void:
	seen_by_net += 1
	_target_pos = pos
	_target_yaw = yaw
	phase = ph
	dead = h <= 0.0
