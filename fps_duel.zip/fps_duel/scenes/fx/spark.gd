extends Node3D
## Искра попадания: расширяется и гаснет за 0.15 с.


func _ready() -> void:
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property($Mesh, "scale", Vector3(2.5, 2.5, 2.5), 0.15)
	tw.tween_property($Mesh, "transparency", 1.0, 0.15)
	tw.chain().tween_callback(queue_free)
