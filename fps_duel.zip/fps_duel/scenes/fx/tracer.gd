extends Node3D
## Трассер: светящийся отрезок между двумя точками, живёт 0.08 с.

@onready var mesh: MeshInstance3D = $Mesh


func _ready() -> void:
	get_tree().create_timer(0.08).timeout.connect(queue_free)


func setup(from: Vector3, to: Vector3) -> void:
	var length := from.distance_to(to)
	if length < 0.001:
		queue_free()
		return
	position = (from + to) * 0.5
	look_at(to, Vector3.UP)
	mesh.scale.z = length
