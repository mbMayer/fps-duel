extends Control
## Экран лобби: список игроков, старт матча (хост), приглашение друга (Steam).

@onready var info_label: Label = $Layout/VBox/LobbyInfoLabel
@onready var slot_labels: Array[Label] = [
	$Layout/VBox/PlayerList/P1Label,
	$Layout/VBox/PlayerList/P2Label,
	$Layout/VBox/PlayerList/P3Label,
	$Layout/VBox/PlayerList/P4Label,
	$Layout/VBox/PlayerList/P5Label,
]
@onready var status_label: Label = $Layout/VBox/StatusLabel
@onready var host_row: HBoxContainer = $Layout/VBox/HostRow
@onready var guest_label: Label = $Layout/VBox/GuestLabel
@onready var start_btn: Button = $Layout/VBox/HostRow/StartBtn
@onready var invite_btn: Button = $Layout/VBox/HostRow/InviteBtn


func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	NetworkManager.lobby_updated.connect(_refresh)
	SteamManager.lobby_members_changed.connect(_refresh)
	NetworkManager.status_changed.connect(_set_status)
	SteamManager.status_changed.connect(_set_status)
	_refresh()


func _set_status(text: String) -> void:
	if text != "":
		status_label.text = text


func _refresh() -> void:
	if Game.mode == Game.Mode.STEAM:
		info_label.text = "Steam-лобби, код: %d" % SteamManager.current_lobby_id
	else:
		info_label.text = "LAN-сессия, порт %d" % NetworkManager.PORT

	# BUILD-29: deathmatch до 5 игроков — заполняем слоты по списку участников.
	# На клиенте get_peers() уже включает сервера (id 1), на хосте — нет.
	var ids: Array[int] = []
	if multiplayer.multiplayer_peer != null:
		for pid in multiplayer.get_peers():
			ids.append(int(pid))
		if not ids.has(1):
			ids.append(1)
	ids.sort()
	var my_id := multiplayer.get_unique_id()
	for i in slot_labels.size():
		var lbl: Label = slot_labels[i]
		if i < ids.size():
			var who := "это вы" if ids[i] == my_id else ""
			lbl.text = ("%d. %s%s" % [i + 1, "Хост" if ids[i] == 1 else "Игрок", (" — " + who) if who != "" else ""]).strip_edges()
			lbl.modulate = Color(0.7, 1.0, 0.7) if ids[i] == my_id else Color(1, 1, 1)
		else:
			lbl.text = "%d. Ожидание игрока…" % (i + 1)
			lbl.modulate = Color(1.0, 1.0, 1.0, 0.4)

	host_row.visible = NetworkManager.is_host
	invite_btn.visible = SteamManager.initialized
	guest_label.visible = not NetworkManager.is_host
	start_btn.disabled = ids.size() < 2


func _on_start_pressed() -> void:
	NetworkManager.start_match()


func _on_invite_pressed() -> void:
	SteamManager.invite_friend()


func _on_leave_pressed() -> void:
	NetworkManager.leave_to_menu()
