extends CanvasLayer
## HUD: здоровье, счёт, хитмаркер, вспышка урона, оверлеи смерти/конца матча.

const RESPAWN_TIME := 3.0

var _local_player: Node = null
var _respawn_left := 0.0
var _match_ended := false

@onready var health_bar: ProgressBar = $HealthBar
@onready var health_label: Label = $HealthLabel
@onready var score_label: Label = $ScoreLabel
@onready var hit_marker: Label = $HitMarker
@onready var damage_flash: ColorRect = $DamageFlash
@onready var respawn_label: Label = $RespawnLabel
@onready var died_overlay: ColorRect = $DiedOverlay
@onready var match_over_overlay: ColorRect = $MatchOverOverlay
@onready var winner_label: Label = $MatchOverOverlay/Box/WinnerLabel
@onready var weapon_label: Label = $WeaponLabel
@onready var turret_hint: Label = $TurretHint


func _ready() -> void:
	Game.health_changed.connect(_on_health)
	Game.scores_changed.connect(_on_scores)
	Game.got_hit.connect(_on_got_hit)
	Game.dealt_hit.connect(_on_dealt_hit)
	Game.died.connect(_on_died)
	Game.respawned.connect(_on_respawned)
	Game.match_over.connect(_on_match_over)
	Game.player_spawned_local.connect(_on_local_spawned)
	Game.weapon_changed.connect(_on_weapon)
	hit_marker.modulate.a = 0.0
	weapon_label.text = Game.weapon_label(1)  # старт с пистолетом


func _on_weapon(label: String) -> void:
	weapon_label.text = label


func _process(delta: float) -> void:
	if _local_player == null:
		_find_local_player()
	if _respawn_left > 0.0:
		_respawn_left = maxf(_respawn_left - delta, 0.0)
		respawn_label.text = "Возрождение через %d…" % ceili(_respawn_left)
		respawn_label.visible = _respawn_left > 0.0
	# BUILD-30: подсказка про турель (рядом — «сесть», в ней — «выйти»).
	_update_turret_hint()


func _find_local_player() -> void:
	var root := get_tree().current_scene
	if root == null:
		return
	var players := root.get_node_or_null("Players")
	if players == null:
		return
	_local_player = players.get_node_or_null(str(multiplayer.get_unique_id()))
	if _local_player != null:
		_on_health(_local_player.health)


func _on_local_spawned(p: Node) -> void:
	_local_player = p
	_on_health(p.health)


## BUILD-30: подсказка у турели. Видна, когда рядом свободная турель (и ты
## не сидишь) — «F — сесть в турель», или когда ты сидишь — «F — выйти из
## турели». Берём список тurrets с арены (текущей сцены).
func _update_turret_hint() -> void:
	if _local_player == null or _local_player.dead:
		turret_hint.visible = false
		return
	if _local_player.mounted_idx >= 0:
		turret_hint.text = "F — выйти из турели"
		turret_hint.visible = true
		return
	var root := get_tree().current_scene
	if root == null or not root.has_method("get_player_by_id"):
		turret_hint.visible = false
		return
	var arr: Array = root.turrets
	var range_m: float = float(root.MOUNT_RANGE)
	var nearest := 9999.0
	for t in arr:
		if t.is_occupied():
			continue
		var d: float = t.position.distance_to(_local_player.global_position)
		if d < nearest:
			nearest = d
	if nearest <= range_m:
		turret_hint.text = "F — сесть в турель"
		turret_hint.visible = true
	else:
		turret_hint.visible = false


func _on_health(value: float) -> void:
	health_bar.value = value
	health_label.text = "%d HP" % int(round(value))


func _on_scores(sc: Dictionary, my_id: int) -> void:
	# BUILD-29: FFA-таблица. Номер игрока = позиция его peer_id по возрастанию.
	var ids := sc.keys()
	ids.sort()
	var nums := {}
	for i in ids.size():
		nums[int(ids[i])] = i + 1
	var parts: Array[String] = ["Вы %d" % int(sc.get(my_id, 0))]
	var others: Array[Array] = []
	for pid in nums:
		if int(pid) == my_id:
			continue
		others.append([int(pid), int(sc[pid])])
	others.sort_custom(func(a: Array, b: Array) -> bool: return a[1] > b[1])
	for o in others:
		parts.append("иг%d: %d" % [nums[o[0]], o[1]])
	score_label.text = "  ·  ".join(parts)


func _on_got_hit() -> void:
	damage_flash.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(damage_flash, "modulate:a", 0.0, 0.35)


func _on_dealt_hit() -> void:
	hit_marker.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(hit_marker, "modulate:a", 0.0, 0.2)


func _on_died(_killer: String) -> void:
	died_overlay.visible = true
	_respawn_left = RESPAWN_TIME


func _on_respawned() -> void:
	died_overlay.visible = false
	_respawn_left = 0.0
	respawn_label.visible = false


func _on_match_over(label: String) -> void:
	_match_ended = true
	winner_label.text = label
	match_over_overlay.visible = true


func _unhandled_input(event: InputEvent) -> void:
	if _match_ended:
		return
	if event.is_action_pressed("ui_cancel"):
		$ConfirmDialog.popup_centered()
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func _on_confirm_confirmed() -> void:
	NetworkManager.leave_to_menu()


func _on_confirm_canceled() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
