extends Node3D
## Сервер-авторитарная логика матча: спавн, попадания, урон, счёт, респаун.
## Все решения принимает хост (сервер); клиенты шлют только запросы.

const RESPAWN_TIME := 3.0
const READY_RETRY := 0.4
const SMOKE_SHOTS := 3

# BUILD-30: две турели на противоположных сторонах арены (север/юг),
# каждая смотрит в центр.
const TURRET_SCENE := "res://scenes/game/turret.tscn"
const TURRET_SPAWNS := [Vector3(0.0, 0.0, 16.0), Vector3(0.0, 0.0, -16.0)]
const MOUNT_RANGE := 2.6

# BUILD-29: пять точек по периметру — deathmatch до 5 игроков.
const SPAWN_POINTS := [
	Vector3(-10.0, 1.0, 0.0),
	Vector3(10.0, 1.0, 0.0),
	Vector3(0.0, 1.0, -12.0),
	Vector3(-12.0, 1.0, 9.0),
	Vector3(12.0, 1.0, 9.0),
]

@export var player_scene: PackedScene

var players := {}   # peer_id -> Player
var _spawn_idx := {}  # peer_id -> индекс точки спавна (для респауна)
var scores := {}    # peer_id -> убийства
var turrets: Array[Node3D] = []  # BUILD-30


func get_player_by_id(id: int) -> Node:
	return players.get(id)

var _ready_clients: Array[int] = []
var _match_over := false
var _smoke_hits := 0
var _smoke_client_hits := 0
var _smoke_client_got_hits := 0
var _smoke_fired := false

@onready var players_root: Node3D = $Players


var _arena_t := 0.0
var _crouch_seen := false
var _jump_seen := false
var _pose_poll_done := false
var _breath_h0 := 0.0
var _breath_c0 := 0.0


# BUILD-27: присед/прыжок хоста ловим СОБЫТИЙНО (опрос флагов), а не по
# таймерам — часы хоста и клиента могут слегка расходиться.
func _process(delta: float) -> void:
	_arena_t += delta
	# BUILD-30: авторитетное завершение перезарядки турели (сервер):
	# патроны доходят до полного магазина.
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		var now := Time.get_ticks_msec()
		for t in turrets:
			if t.reload_end_ms > 0 and now >= t.reload_end_ms:
				t.reload_end_ms = 0
				t.mag = int(Game.TURRET["magazine"])
	if not Game.input_test or multiplayer.multiplayer_peer == null or multiplayer.is_server():
		return
	if _arena_t < 13.0 or _arena_t > 24.5:
		return
	var host_node: Node = players.get(1)
	if host_node == null:
		return
	if not _crouch_seen and host_node._remote_crouch:
		_crouch_seen = true
		# поза разгоняется ~0.4 с — ассерт чуть позже.
		get_tree().create_timer(0.5).timeout.connect(func() -> void:
			var hm: float = host_node._head_mesh.global_position.y
			if host_node.head.position.y < 1.35 and hm < 1.4:
				print("[CLIENTANIM] присед соперника синхронизирован (голова %.2f м, голова-меш %.2f м)" % [host_node.head.position.y, hm])
			else:
				print("[CLIENTANIM_FAIL] присед соперника: голова=%.2f, меш=%.2f" % [host_node.head.position.y, hm])
		)
	if not _jump_seen and _arena_t > 15.0 and not host_node._remote_grounded:
		_jump_seen = true
		get_tree().create_timer(0.3).timeout.connect(func() -> void:
			var foot_y: float = host_node._leg_rig_r["foot"].global_position.y
			if foot_y > 0.2:
				print("[CLIENTANIM] прыжок соперника синхронизирован (ноги поджаты, стопа %.2f м)" % foot_y)
			else:
				print("[CLIENTANIM_FAIL] прыжок соперника: стопа=%.2f" % foot_y)
		)
	if _arena_t > 24.0 and not _pose_poll_done:
		_pose_poll_done = true
		if not _crouch_seen:
			print("[CLIENTANIM_FAIL] присед соперника не пришёл")
		if not _jump_seen:
			print("[CLIENTANIM_FAIL] прыжок соперника не пришёл")


func _ready() -> void:
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	if Game.smoke_test and not multiplayer.is_server():
		Game.dealt_hit.connect(_smoke_on_dealt_hit)
		Game.got_hit.connect(_smoke_on_got_hit)
	if Game.ffa_test and not multiplayer.is_server():
		_ffa_client_monitor()
	if Game.turret_test and not multiplayer.is_server():
		_turret_client_monitor()
	if Game.autostart:
		# Headless-проверки: дублируем финал в лог.
		Game.match_over.connect(func(label: String) -> void:
			print("[AUTOSTART] матч завершён:\n" + label)
		)
	if multiplayer.multiplayer_peer == null:
		return  # одиночный просмотр сцены в редакторе
	_setup_turrets()
	if multiplayer.is_server():
		scores[1] = 0
		for id in multiplayer.get_peers():
			scores[int(id)] = 0
	else:
		_start_ready_retry()


# ---------------------------------------------------------------- турели (BUILD-30)

func _setup_turrets() -> void:
	var scene := load(TURRET_SCENE)
	for i in TURRET_SPAWNS.size():
		var t: Node3D = scene.instantiate()
		t.turret_idx = i
		t.position = TURRET_SPAWNS[i]
		t.rotation.y = atan2(TURRET_SPAWNS[i].x, TURRET_SPAWNS[i].z)  # смотрит в центр
		add_child(t)
		turrets.append(t)


## Посадка в турель: запрос (клиент) / прямое действие (хост) -> проверка на
## сервере -> авторитетное событие всем нодам.
@rpc("any_peer", "call_remote", "reliable")
func request_mount(turret_idx: int) -> void:
	try_mount_player(multiplayer.get_remote_sender_id(), turret_idx)


@rpc("any_peer", "call_remote", "reliable")
func request_dismount() -> void:
	try_dismount_player(multiplayer.get_remote_sender_id())


func try_mount_player(id: int, turret_idx: int) -> void:
	if not multiplayer.is_server() or _match_over:
		return
	if turret_idx < 0 or turret_idx >= turrets.size():
		return
	var t: Node3D = turrets[turret_idx]
	var p: Node = players.get(id)
	if p == null or p.dead or p.mounted_idx >= 0 or t.is_occupied():
		return
	if t.position.distance_to(p.position) > MOUNT_RANGE:
		return
	t.occupant_id = id
	p._apply_mount_event(turret_idx)  # на серверной ноде
	_event_mount.rpc(id, turret_idx)
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d сел в турель %d" % [id, turret_idx])


func try_dismount_player(id: int) -> void:
	if not multiplayer.is_server() or _match_over:
		return
	var p: Node = players.get(id)
	if p == null or p.mounted_idx < 0:
		return
	var t: Node3D = turrets[p.mounted_idx]
	var tidx := int(p.mounted_idx)
	t.occupant_id = -1
	# Выходим вбок от турели (на «правую» сторону от её носа), внутрь арены.
	var yaw: float = float(p.rotation.y)
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var pos := t.position + right * 1.7
	pos.x = clampf(pos.x, -19.0, 19.0)
	pos.z = clampf(pos.z, -19.0, 19.0)
	p._apply_dismount_event(pos, yaw)  # на серверной ноде
	_event_dismount.rpc(id, pos, yaw)
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d вышел из турели %d (pos=%s)" % [id, tidx, str(pos)])


@rpc("authority", "call_remote", "reliable")
func _event_mount(id: int, turret_idx: int) -> void:
	var p: Node = players.get(id)
	if p != null:
		p._apply_mount_event(turret_idx)


@rpc("authority", "call_remote", "reliable")
func _event_dismount(id: int, pos: Vector3, yaw: float) -> void:
	var p: Node = players.get(id)
	if p != null:
		p._apply_dismount_event(pos, yaw)


## Перезарядка турели: клиент просит, сервер подтверждает (и держит свой
## авторитетный таймер; завершение — в _process).
@rpc("any_peer", "call_remote", "reliable")
func request_turret_reload() -> void:
	var sender := multiplayer.get_remote_sender_id()
	var p: Node = players.get(sender)
	if p == null or p.mounted_idx < 0:
		return
	var t: Node3D = turrets[p.mounted_idx]
	if t.reload_end_ms > 0 or t.mag >= int(Game.TURRET["magazine"]):
		return
	t.reload_end_ms = Time.get_ticks_msec() + int(Game.TURRET["reload_ms"])
	if Game.turret_test or OS.is_debug_build():
		print("[TURRET] сервер: игрок %d начал перезарядку турели %d" % [sender, p.mounted_idx])


## Выстрел из турели дошёл до остальных: отдача ствола + трассер.
## Шлёт СТРЕЛЯЮЩИЙ (any_peer) — сервер и другие клиенты не видят собственного
## RPC, поэтому двойного эффекта у стрелка нет (у него — локальный).
@rpc("any_peer", "call_remote", "unreliable")
func _turret_fx(turret_idx: int, barrel_idx: int, end: Vector3) -> void:
	if turret_idx < 0 or turret_idx >= turrets.size():
		return
	var t: Node3D = turrets[turret_idx]
	t.fx_seen += 1
	t.fire_kick(barrel_idx)
	_spawn_tracer_scene(t.world_muzzle(barrel_idx), end)


func _spawn_tracer_scene(from: Vector3, to: Vector3) -> void:
	var tracer: Node3D = preload("res://scenes/fx/tracer.tscn").instantiate()
	add_child(tracer)
	tracer.setup(from, to)


## Тест-телепорт (только для headless-автотеста турели): сервер сдвигает ноду
## ЧУЖОГО игрока на его клиенте — авторитет движения остаётся у клиента.
@rpc("authority", "call_remote", "reliable")
func test_set_pos(id: int, pos: Vector3, yaw: float) -> void:
	if not Game.turret_test:
		return
	var p: Node = players.get(id)
	if p == null:
		return
	p.position = pos
	p.rotation.y = yaw
	p.reset_net_targets()


## Тест: клиент выполняет реальную команду «сесть» (полный any_peer-путь).
@rpc("authority", "call_remote", "reliable")
func test_client_do_mount(turret_idx: int) -> void:
	if not Game.turret_test:
		return
	request_mount.rpc(turret_idx)


## Тест: клиент выполняет реальную команду «выйти».
@rpc("authority", "call_remote", "reliable")
func test_client_dismount() -> void:
	if not Game.turret_test:
		return
	request_dismount.rpc()


# ---------------------------------------------------------------- готовность и спавн

func _start_ready_retry() -> void:
	var t := Timer.new()
	t.wait_time = READY_RETRY
	t.autostart = true
	add_child(t)
	t.timeout.connect(func() -> void:
		if players.has(multiplayer.get_unique_id()) or multiplayer.multiplayer_peer == null:
			t.queue_free()
			return
		_notify_ready.rpc_id(1)
	)


@rpc("any_peer", "call_remote", "reliable")
func _notify_ready() -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender > 1 and not _ready_clients.has(sender):
		_ready_clients.append(sender)
		_try_spawn_all()


func _try_spawn_all() -> void:
	if players.size() > 0 or _match_over:
		return
	var expected: Array[int] = [1]
	for id in multiplayer.get_peers():
		expected.append(int(id))
	for id in expected:
		if id != 1 and not _ready_clients.has(id):
			return  # ждём, пока все клиенты загрузят сцену
	for i in expected.size():
		_spawn_player(expected[i], i)
	if Game.input_test:
		print("[INPUTTEST] сервер: спавн готов — имитирую клики ЛКМ через полный конвейер ввода")
		for i in SMOKE_SHOTS:
			get_tree().create_timer(0.5 + 0.3 * i).timeout.connect(_synthetic_click)
		get_tree().create_timer(16.0).timeout.connect(_input_test_weapons)
		get_tree().create_timer(35.0).timeout.connect(_smoke_host_finish)
		# BUILD-27: присед (14.6..15.8) и прыжок (15.8) — АБСОЛЮТНАЯ шкала,
		# клиент ловит события опросом в _process.
		get_tree().create_timer(14.6).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me != null:
				me.dbg_crouch = true
		)
		get_tree().create_timer(15.2).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			var ok := bool(me._crouch_w > 0.7 and me.head.position.y < 1.35)
			if ok:
				print("[WEAPONTEST] присед: голова %.2f м, колени согнуты (вес %.2f)" % [me.head.position.y, me._crouch_w])
			else:
				print("[WEAPONTEST_FAIL] присед: голова=%.2f, вес=%.2f" % [me.head.position.y, me._crouch_w])
		)
		get_tree().create_timer(15.8).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			me.dbg_crouch = false
			me.velocity.y = me.JUMP_VELOCITY  # сразу за приседом — прыжок
		)
		get_tree().create_timer(16.1).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			var foot_y: float = me._leg_rig_r["foot"].global_position.y
			var ok := bool(me._air_w > 0.5 and foot_y > 0.2)
			if ok:
				print("[WEAPONTEST] прыжок: в воздухе ноги поджаты (стопа %.2f м)" % foot_y)
			else:
				print("[WEAPONTEST_FAIL] прыжок: air=%.2f, стопа=%.2f" % [me._air_w, foot_y])
		)
		# BUILD-28: idle-дыхание оружия в покое (два замера — фаза идёт).
		get_tree().create_timer(20.5).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me != null:
				_breath_h0 = me._fp_breath
		)
		get_tree().create_timer(20.9).timeout.connect(func() -> void:
			var me: Node = players.get(1)
			if me == null:
				return
			if absf(me._fp_breath - _breath_h0) > 0.001:
				print("[WEAPONTEST] idle-дыхание: оружие живёт в покое (%.4f м)" % me._fp_breath)
			else:
				print("[WEAPONTEST_FAIL] idle-дыхание отсутствует")
		)
	elif Game.turret_test:
		# BUILD-30: сценарий турели — хост-оркестрация, клиент-монитор.
		print("[TURRET] сервер: игроки заспавнены (ключи=%s) — начинаю сценарий турели" % str(players.keys()))
		_turret_test_host()
	elif Game.ffa_test:
		# BUILD-29: FFA-тест. Хост убивает одного клиента 5 раз и побеждает —
		# проверяем, что счёт (словарь на всех игроков) и финал доходят до каждой ноды.
		print("[FFA] сервер: игроки заспавнены (ключи=%s) — начинаю тест фрагов" % str(players.keys()))
		_ffa_test_host()
	elif Game.smoke_test:
		print("[SMOKE] сервер: игроки заспавнены (арена #%d, ключи=%s)" % [get_instance_id(), str(players.keys())])
		get_tree().create_timer(0.5).timeout.connect(_smoke_host_shoots_client)
		get_tree().create_timer(6.0).timeout.connect(_smoke_host_finish)


func _spawn_player(id: int, index: int) -> void:
	if players.has(id):
		return
	var pos: Vector3 = SPAWN_POINTS[index % SPAWN_POINTS.size()]
	# BUILD-29: каждый спавн смотрит в центр арены.
	var yaw := atan2(pos.x, pos.z)
	_make_player(id, pos, yaw)
	scores[id] = 0
	_spawn_idx[id] = index
	_sync_spawn.rpc(id, pos, yaw)
	if id == multiplayer.get_unique_id():
		Game.player_spawned_local.emit(players[id])
		Game.scores_changed.emit(scores.duplicate(), id)


func _make_player(id: int, pos: Vector3, yaw: float) -> CharacterBody3D:
	var p: CharacterBody3D = player_scene.instantiate()
	p.name = str(id)
	p.position = pos
	p.rotation.y = yaw
	p.set_multiplayer_authority(id)
	if OS.is_debug_build():
		print("[AUTH] создан игрок %d (авторитет=%d, мой_id=%d, сервер=%s)" % [id, p.get_multiplayer_authority(), multiplayer.get_unique_id(), str(multiplayer.is_server())])
	players_root.add_child(p)
	players[id] = p
	return p


@rpc("authority", "call_remote", "reliable")
func _sync_spawn(id: int, pos: Vector3, yaw: float) -> void:
	if players.has(id):
		return
	_make_player(id, pos, yaw)
	scores[id] = 0
	if id == multiplayer.get_unique_id():
		_spawn_idx[id] = players.size() - 1
		Game.player_spawned_local.emit(players[id])
		Game.scores_changed.emit(scores.duplicate(), id)
		if Game.input_test and not multiplayer.is_server():
			_input_test_client_checks()


# ---------------------------------------------------------------- стрельба (только сервер)

func handle_shoot_request(sender_id: int, origin: Vector3, dir: Vector3, weapon_idx: int, attack_type: int) -> void:
	if OS.is_debug_build():
		print("[SHOT] сервер получил запрос от %d (оружие=%d, атака=%d)" % [sender_id, weapon_idx, attack_type])
	if not multiplayer.is_server():
		return
	if _match_over:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — матч завершён" % sender_id)
		return
	var shooter: Node = players.get(sender_id)
	if shooter == null or shooter.dead:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — стрелок не найден или мёртв" % sender_id)
		return
	# BUILD-30: турель — отдельная ветка валидации (оружие индекса 3).
	if weapon_idx == Game.TURRET_IDX:
		_handle_turret_shot(sender_id, shooter, dir)
		return
	# Античит: стрелять можно только тем оружием, что реально выбрано.
	if not Game.WEAPONS.has(weapon_idx) or weapon_idx != shooter.current_weapon:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — оружие не совпадает (запрошено %d, в руках %d)" % [sender_id, weapon_idx, shooter.current_weapon])
		return
	# Тяжёлая атака есть только у ножа.
	if weapon_idx != 0:
		attack_type = 0
	var w: Dictionary = Game.WEAPONS[weapon_idx]
	var now := Time.get_ticks_msec()
	if now < shooter.reload_end_ms:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: отклонено — идёт перезарядка" % sender_id)
		return
	# Патроны: у ножа их нет, остальное оружие требует наличия в магазине.
	# Хост уже списал патрон локально в _fire() — сервер списывает только клиентам.
	var is_heavy := weapon_idx == 0 and attack_type == 1
	if sender_id != multiplayer.get_unique_id() and int(w.get("magazine", -1)) >= 0:
		if int(shooter.ammo_mag.get(weapon_idx, 0)) <= 0:
			if OS.is_debug_build():
				print("[SHOT] игрок %d: отклонено — нет патронов" % sender_id)
			return
		shooter.ammo_mag[weapon_idx] = int(shooter.ammo_mag[weapon_idx]) - 1
	if sender_id != multiplayer.get_unique_id():
		# Кулдаун проверяется только для КЛИЕНТОВ (античит против спам-выстрелов).
		# Хост уже прошёл проверку кулдауна в _fire(); повторная проверка здесь
		# отбрасывала ВСЕ выстрелы хоста — это и был баг «хост не наносит урон».
		var bypass := Game.smoke_test and not Game.input_test
		if not bypass and now < shooter.next_allowed_shot_ms:
			if OS.is_debug_build():
				print("[SHOT] игрок %d: отклонено — кулдаун оружия" % sender_id)
			return
		var cd := int(w["heavy_cooldown_ms"]) if is_heavy else int(w["cooldown_ms"])
		shooter.next_allowed_shot_ms = now + cd
	dir = dir.normalized()
	# Античит: клиент должен стрелять примерно из своей серверной позиции.
	var head_pos: Vector3 = shooter.get_head_world_position()
	if origin.distance_to(head_pos) > 2.5:
		origin = head_pos
	var weapon_range: float = float(w["heavy_range"]) if is_heavy else float(w["range"])
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * weapon_range)
	query.collision_mask = 3  # мир (1) + хитбоксы (2)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	# Выстрел «по стволу» у стены: дуло может стоять вплотную к поверхности.
	query.hit_from_inside = true
	query.exclude = [
		shooter.get_rid(),                    # RID самого тела (CollisionObject3D)
		shooter.get_node("Hitbox").get_rid(), # RID Area3D-хитбокса
	]
	var hit := space.intersect_ray(query)
	var end := origin + dir * weapon_range
	var victim: Node = null
	if hit:
		end = hit.position
		victim = _resolve_victim(hit.collider, shooter)
	var damage: float = float(w["heavy_damage"]) if is_heavy else float(w["damage"])
	if victim != null:
		if OS.is_debug_build():
			print("[SHOT] игрок %d: ПОПАЛ по игроку %d (%s, урон %.0f)" % [sender_id, str(victim.name).to_int(), str(w["name"]), damage])
		_apply_damage(victim, shooter, damage)
	elif OS.is_debug_build():
		# Диагностика для отладки «не наносится урон»: видно, куда ушёл луч.
		print("[SHOT] игрок %d: мимо (луч остановлен: %s)" % [sender_id, str(hit.collider if hit else "ничего")])
	_impact.rpc(end, victim != null)
	_spawn_impact(end)  # сервер не получает собственный call_remote — спавним искры локально


# BUILD-30: выстрел из турели. Авторитетно на сервере: ствол и точка вылета
# считаются из состояния СЕРВЕРНОЙ турели (клиентский origin игнорируется),
# направление зажимается к оси ствола — турель бьёт только «вперёд по курсу».
# Стволы стреляют по очереди: серверный счётчик t.barrel.
func _handle_turret_shot(sender_id: int, shooter: Node, dir: Vector3) -> void:
	if shooter.mounted_idx < 0 or shooter.mounted_idx >= turrets.size():
		if OS.is_debug_build():
			print("[TURRET] игрок %d: отклонено — не сидит в турели" % sender_id)
		return
	var t: Node3D = turrets[shooter.mounted_idx]
	var w: Dictionary = Game.TURRET
	var now := Time.get_ticks_msec()
	if now < t.reload_end_ms:
		if OS.is_debug_build():
			print("[TURRET] игрок %d: отклонено — идёт перезарядка" % sender_id)
		return
	if sender_id != multiplayer.get_unique_id():
		# Кулдаун и патроны — только для клиентов (хост уже прошёл эти
		# проверки локально в _turret_fire; его копия турели и есть серверная).
		if now < shooter.next_allowed_shot_ms:
			if OS.is_debug_build():
				print("[TURRET] игрок %d: отклонено — кулдаун" % sender_id)
			return
		if t.mag <= 0:
			if OS.is_debug_build():
				print("[TURRET] игрок %d: отклонено — нет патронов (сервер)" % sender_id)
			return
		t.mag -= 1
		t.barrel = int(t.barrel) ^ 1
		shooter.next_allowed_shot_ms = now + int(w["cooldown_ms"])
	var barrel: int = int(t.barrel)
	var muzzle: Vector3 = t.world_muzzle(barrel)
	# Зажим направления: рыск ≤ 0.25 рад от оси купола, тангаж ≤ 0.15 рад
	# (стволы горизонтальные — «стрельба в пол» из турели невозможна).
	var t_yaw: float = float(t.aim_yaw())
	var d: Vector3 = dir.normalized()
	var dyaw: float = atan2(-d.x, -d.z)
	var dev: float = wrapf(dyaw - t_yaw, -PI, PI)
	var ny: float = t_yaw + clampf(dev, -0.25, 0.25)
	var pitch: float = clampf(asin(clampf(d.y, -1.0, 1.0)), -0.15, 0.15)
	d = Vector3(-sin(ny) * cos(pitch), sin(pitch), -cos(ny) * cos(pitch)).normalized()
	var range_m := float(w["range"])
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(muzzle, muzzle + d * range_m)
	query.collision_mask = 3  # мир (1) + хитбоксы (2)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	query.hit_from_inside = true
	query.exclude = [
		shooter.get_rid(),
		shooter.get_node("Hitbox").get_rid(),
	]
	var hit := space.intersect_ray(query)
	var end := muzzle + d * range_m
	var victim: Node = null
	if hit:
		end = hit.position
		victim = _resolve_victim(hit.collider, shooter)
	if victim != null:
		if OS.is_debug_build():
			print("[TURRET] сервер: игрок %d (турель %d, ствол %d) попал по игроку %d" % [sender_id, shooter.mounted_idx, barrel, str(victim.name).to_int()])
		_apply_damage(victim, shooter, float(w["damage"]))
	elif OS.is_debug_build():
		print("[TURRET] сервер: игрок %d (турель %d): мимо (луч: %s)" % [sender_id, shooter.mounted_idx, str(hit.collider if hit else "ничего")])
	_impact.rpc(end, victim != null)
	_spawn_impact(end)


func _spawn_impact(point: Vector3) -> void:
	var spark: Node3D = preload("res://scenes/fx/spark.tscn").instantiate()
	spark.position = point
	add_child(spark)


func _resolve_victim(collider: Object, shooter: Node) -> Node:
	var node := collider as Node
	if node == null:
		return null
	var candidate: Node = node
	if not candidate is CharacterBody3D:
		candidate = node.get_parent()
	if candidate == null or candidate == shooter:
		return null
	if players.values().has(candidate) and not candidate.dead:
		return candidate
	return null


func _apply_damage(victim: Node, attacker: Node, damage: float) -> void:
	var victim_id := str(victim.name).to_int()
	var attacker_id := str(attacker.name).to_int()
	victim.health -= damage
	if Game.smoke_test:
		_smoke_hits += 1
		print("[SMOKE] сервер: попадание #%d по игроку %d (урон %.0f, hp=%.0f)" % [_smoke_hits, victim_id, damage, victim.health])
	if victim.health <= 0.0:
		victim.health = 0.0
		victim.dead = true
		scores[attacker_id] = int(scores.get(attacker_id, 0)) + 1
		_event_death.rpc(victim_id, attacker_id, scores)
		_local_death_feedback(victim_id, attacker_id)
		_start_respawn(victim_id)
		if int(scores[attacker_id]) >= Game.KILL_TARGET:
			_end_match(attacker_id)
	else:
		_event_damage.rpc(victim_id, damage, attacker_id, victim.health)
		if Game.smoke_test:
			print("[SMOKE][DBG] сервер отправил _event_damage жертве %d" % victim_id)
		_local_damage_feedback(victim_id, attacker_id, victim.health)


func _local_damage_feedback(victim_id: int, attacker_id: int, hp: float) -> void:
	var mine := multiplayer.get_unique_id()
	if victim_id == mine:
		Game.got_hit.emit()
		Game.health_changed.emit(hp)
	if attacker_id == mine:
		Game.dealt_hit.emit()


func _local_death_feedback(victim_id: int, attacker_id: int) -> void:
	var mine := multiplayer.get_unique_id()
	Game.scores_changed.emit(scores.duplicate(), mine)
	if victim_id == mine:
		# BUILD-29: FFA — показываем, кто убил.
		Game.died.emit("Игрок %d" % _player_num(attacker_id))


# ---------------------------------------------------------------- события для клиентов

@rpc("authority", "call_remote", "reliable")
func _event_damage(victim_id: int, _damage: float, attacker_id: int, health_left: float) -> void:
	if Game.smoke_test:
		print("[SMOKE][DBG] получен _event_damage: жертва=%d, я=%d, коннектов got_hit=%d, арена #%d" % [victim_id, multiplayer.get_unique_id(), Game.got_hit.get_connections().size(), get_instance_id()])
	var p: Node = players.get(victim_id)
	if p != null:
		p.health = health_left
	var mine := multiplayer.get_unique_id()
	if victim_id == mine:
		Game.got_hit.emit()
		Game.health_changed.emit(health_left)
	if attacker_id == mine:
		Game.dealt_hit.emit()


@rpc("authority", "call_remote", "reliable")
func _event_death(victim_id: int, attacker_id: int, new_scores: Dictionary) -> void:
	var p: Node = players.get(victim_id)
	if p != null:
		p.health = 0.0
		p.dead = true
		p._apply_unmount_cleanup()  # BUILD-30: смерть освобождает турель
	var mine := multiplayer.get_unique_id()
	Game.scores_changed.emit(new_scores.duplicate(), mine)
	if victim_id == mine:
		# BUILD-29: FFA — показываем, кто убил.
		Game.died.emit("Игрок %d" % _player_num(attacker_id))


@rpc("authority", "call_remote", "unreliable")
func _impact(point: Vector3, _hit_something: bool) -> void:
	_spawn_impact(point)


# ---------------------------------------------------------------- респаун

func _start_respawn(victim_id: int) -> void:
	get_tree().create_timer(RESPAWN_TIME).timeout.connect(func() -> void:
		_respawn(victim_id)
	)


func _respawn(victim_id: int) -> void:
	if _match_over or not multiplayer.is_server():
		return
	var p: Node = players.get(victim_id)
	if p == null:
		return
	var idx := int(_spawn_idx.get(victim_id, 0))
	p.position = SPAWN_POINTS[idx % SPAWN_POINTS.size()]
	p.velocity = Vector3.ZERO
	p.health = 100.0
	p.dead = false
	p._apply_unmount_cleanup()  # BUILD-30: если сидел в турели — на земле
	p.reset_net_targets()
	_event_respawn.rpc(victim_id, p.position, p.rotation.y)
	if victim_id == multiplayer.get_unique_id():
		Game.respawned.emit()
		Game.health_changed.emit(100.0)


@rpc("authority", "call_remote", "reliable")
func _event_respawn(id: int, pos: Vector3, yaw: float) -> void:
	var p: Node = players.get(id)
	if p == null:
		return
	p.position = pos
	p.rotation.y = yaw
	p.health = 100.0
	p.dead = false
	p._apply_unmount_cleanup()  # BUILD-30: респаун всегда на земле
	p.reset_net_targets()
	if id == multiplayer.get_unique_id():
		Game.respawned.emit()
		Game.health_changed.emit(100.0)


# ---------------------------------------------------------------- конец матча / дисконнект

func _end_match(winner_id: int) -> void:
	if _match_over:
		return
	_match_over = true
	# BUILD-29: FFA — каждый клиент сам собирает итог («кто выиграл» + таблица).
	Game.match_over.emit(_match_over_label(winner_id, scores))
	_event_match_over.rpc(winner_id, scores.duplicate())
	if Game.smoke_test:
		get_tree().create_timer(1.5).timeout.connect(func() -> void:
			print("[SMOKE] матч завершён")
			get_tree().quit(0)
		)
		return
	get_tree().create_timer(5.0).timeout.connect(func() -> void:
		NetworkManager.return_to_lobby()
	)


func _player_num(id: int) -> int:
	# BUILD-29: номер игрока = позиция его peer_id в отсортированном списке.
	var ids := players.keys()
	ids.sort()
	return ids.find(id) + 1


func _match_over_label(winner_id: int, sc: Dictionary) -> String:
	var mine := multiplayer.get_unique_id()
	var ids := sc.keys()
	ids.sort()
	var lines: Array[String] = []
	var rank := 0
	for i in ids.size():
		rank += 1
		var tag := " ← вы" if int(ids[i]) == mine else ""
		lines.append("%d. Игрок %d — %d%s" % [rank, _player_num(int(ids[i])), int(sc[ids[i]]), tag])
	var title := "Вы победили!" if winner_id == mine else "Победил игрок %d" % _player_num(winner_id)
	return title + "\n" + "\n".join(lines)


# ---------------------------------------------------------------- FFA-тест (автоматизация)

var _ffa_last_scores := {}

func _ffa_test_host() -> void:
	var victim_id := 0
	for k in players.keys():
		if int(k) != 1:
			victim_id = int(k)
			break
	if victim_id == 0 or not players.has(victim_id):
		print("[FFA_FAIL] сервер: нет жертвы (ключи=%s)" % str(players.keys()))
		return
	var killer: Node = players[1]
	var victim: Node = players[victim_id]
	for i in Game.KILL_TARGET:
		get_tree().create_timer(2.0 + 0.4 * i).timeout.connect(func() -> void:
			if _match_over:
				return
			victim.health = 1.0
			victim.dead = false
			_apply_damage(victim, killer, 100.0)
		)
	get_tree().create_timer(6.0).timeout.connect(func() -> void:
		var my := int(scores.get(1, 0))
		if _match_over and my >= Game.KILL_TARGET and scores.size() >= 3:
			print("[FFA_OK] сервер: победа хоста, фрагов=%d, игроков в счёте=%d" % [my, scores.size()])
		else:
			print("[FFA_FAIL] сервер: over=%s, фрагов хоста=%d, игроков=%d" % [str(_match_over), my, scores.size()])
		get_tree().create_timer(2.5).timeout.connect(func() -> void: get_tree().quit(0))
	)


# ---------------------------------------------------------------- тест турели (BUILD-30)

var _turret_client_id := 0
var _turret_ok := true
var _turret_star_id := 0  # клиент, которого ведёт сценарий (знает сам сервер)


## Сервер сообщает клиентам, кто «звёздный» (в сценарии участвует только он).
@rpc("authority", "call_remote", "reliable")
func test_turret_star(id: int) -> void:
	if not Game.turret_test:
		return
	_turret_star_id = id


func _turret_fail(msg: String) -> void:
	_turret_ok = false
	print("[TURRET_FAIL] " + msg)


## Хост ведёт сценарий: посадка, чужая попытка сесть (занято), три выстрела по
## клиенту (чередование стволов, урон), выход, посадка клиента в освобождённую.
## Геометрия: турель 0 на (0,0,16) смотрит в центр (ось -Z, рыск 0). Стволы
## стреляют с зажимом ±0.25 рад от оси купола, поэтому мишень ставим ПОД ОСЬЮ:
## клиент на (0.35, 0, 13.0) — почти прямо перед носом турели.
func _turret_test_host() -> void:
	for k in players.keys():
		if int(k) != 1:
			_turret_client_id = int(k)
			break
	if _turret_client_id == 0:
		_turret_fail("сервер: нет второго игрока (ключи=%s)" % str(players.keys()))
		return
	_turret_star_id = _turret_client_id
	test_turret_star.rpc(_turret_client_id)
	var host: Node = players[1]
	var turret: Node3D = turrets[0]
	var tpos: Vector3 = turret.position
	var near := tpos + Vector3(0.4, 0.0, -1.4)    # рядом: < 2.6 м (посадка)
	var firing_line := tpos + Vector3(0.35, 0.0, -3.0)  # перед носом: огонь

	# Подносим игроков к турели (хост — напрямую, клиент — test-телепортом).
	get_tree().create_timer(0.3).timeout.connect(func() -> void:
		host.position = tpos + Vector3(0.0, 0.0, -1.6)
		host.rotation.y = 0.0
		test_set_pos.rpc(_turret_client_id, near, 0.0)
	)

	# Хост садится.
	get_tree().create_timer(1.0).timeout.connect(func() -> void:
		try_mount_player(1, 0)
		if turret.is_occupied() and int(turret.occupant_id) == 1 and host.mounted_idx == 0:
			print("[TURRET] сервер: хост в турели (сиденье занято id=1)")
		else:
			_turret_fail("хост не сел: occupant=%s, mounted=%s" % [str(turret.occupant_id), str(host.mounted_idx)])
	)

	# Клиент пытается сесть в ЗАНЯТУЮ турель — сервер должен отказать.
	get_tree().create_timer(1.5).timeout.connect(func() -> void:
		test_client_do_mount.rpc(0)
	)
	get_tree().create_timer(1.9).timeout.connect(func() -> void:
		var client: Node = players.get(_turret_client_id)
		if turret.is_occupied() and int(turret.occupant_id) == 1 and (client == null or client.mounted_idx != 0):
			print("[TURRET] сервер: чужая посадка отклонена (турель занята)")
		else:
			_turret_fail("чужая посадка прошла: occupant=%s" % str(turret.occupant_id))
	)

	# Клиент уходит на огневую линию; хост наводит купол на мишень (рыск -0.09
	# рад — внутри зажима ствола) и стреляет трижды: чередование левый/правый.
	get_tree().create_timer(2.2).timeout.connect(func() -> void:
		test_set_pos.rpc(_turret_client_id, firing_line, 0.0)
		host.rotation.y = -0.09
	)
	for i in 3:
		get_tree().create_timer(2.5 + 0.2 * i).timeout.connect(func() -> void:
			host._turret_fire()
		)

	# Проверка: клиент пострадал (3 × 25), патроны списаны (30 → 27).
	get_tree().create_timer(3.3).timeout.connect(func() -> void:
		var client: Node = players.get(_turret_client_id)
		var mag := int(turret.mag)
		if client != null and int(client.health) == 25:
			print("[TURRET] сервер: 3 выстрела по клиенту (hp клиента=25)")
		else:
			_turret_fail("урон не сошёлся: hp клиента=%s (ждём 25)" % str(client.health if client else "нет"))
		if mag == int(Game.TURRET["magazine"]) - 3:
			print("[TURRET] сервер: магазин турели %d (−3 патрона)" % mag)
		else:
			_turret_fail("магазин: %d (ждём %d)" % [mag, int(Game.TURRET["magazine"]) - 3])
	)

	# Хост выходит из турели.
	get_tree().create_timer(3.7).timeout.connect(func() -> void:
		try_dismount_player(1)
		if not turret.is_occupied() and host.mounted_idx == -1:
			print("[TURRET] сервер: хост вышел (турель свободна)")
		else:
			_turret_fail("выход хоста: occupant=%s, mounted=%s" % [str(turret.occupant_id), str(host.mounted_idx)])
	)

	# Клиент возвращается рядом и садится в теперь свободную турель.
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		test_set_pos.rpc(_turret_client_id, near, 0.0)
	)
	get_tree().create_timer(4.6).timeout.connect(func() -> void:
		test_client_do_mount.rpc(0)
	)
	get_tree().create_timer(5.0).timeout.connect(func() -> void:
		if turret.is_occupied() and int(turret.occupant_id) == _turret_client_id:
			print("[TURRET] сервер: клиент сел в освобождённую турель (id=%d)" % _turret_client_id)
		else:
			_turret_fail("клиент не сел: occupant=%s (ждём %d)" % [str(turret.occupant_id), _turret_client_id])
	)

	# Клиент выходит; финал.
	get_tree().create_timer(5.4).timeout.connect(func() -> void:
		test_client_dismount.rpc()
	)
	get_tree().create_timer(5.9).timeout.connect(func() -> void:
		if not turret.is_occupied():
			print("[TURRET] сервер: клиент вышел (турель свободна)")
		else:
			_turret_fail("клиент не вышел: occupant=%s" % str(turret.occupant_id))
		if _turret_ok:
			print("[TURRET_OK] сервер: сценарий турели пройден (посадка/занятость/огонь/выход)")
		get_tree().create_timer(2.0).timeout.connect(func() -> void: get_tree().quit(0 if _turret_ok else 1))
	)


## Клиент проверяет своё: прилёты выстрелов (трассеры/отдача на своей ноде —
## у всех), урон и видимость собственной посадки (у «звёздного» клиента,
## которого ведёт сценарий).
func _turret_client_monitor() -> void:
	var my_id := multiplayer.get_unique_id()
	# После трёх выстрелов хоста (2.5–2.9 с серверной шкалы): каждый клиент
	# получил 3 события fx. Часовая рассинхронизация нод ~0.5 с — проверяем
	# с запасом. (turrets читаем напрямую: локальные переменные в ламбдах
	# захватываются по значению, а не по ссылке.)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:
		if turrets.size() == 0:
			_turret_fail("клиент: нет турели в сцене")
			return
		var fx := int(turrets[0].fx_seen)
		if fx >= 3:
			print("[TURRET] клиент: получено %d выстрел-событий (отдача+трассер)" % fx)
		else:
			_turret_fail("клиент: выстрел-событий=%d (ждём >=3)" % fx)
		if _turret_star_id != my_id:
			return  # остальные зрители урона не получают
		var hp := int(players.get(my_id).health) if players.has(my_id) else -1
		if hp == 25:
			print("[TURRET] клиент: hp=%d после 3 выстрелов" % hp)
		else:
			_turret_fail("клиент: hp=%d (ждём 25)" % hp)
	)
	# Когда «звёздный» клиент сел (после выхода хоста) — видим свою посадку.
	get_tree().create_timer(5.1).timeout.connect(func() -> void:
		if _turret_star_id != my_id:
			return
		var me: Node = players.get(my_id)
		if me != null and me.mounted_idx == 0:
			print("[TURRET] клиент: мы видим, что сидим в турели (mounted=0)")
		else:
			_turret_fail("клиент: mounted=%s (ждём 0)" % str(me.mounted_idx if me else "нет"))
	)
	# Выходим вслед за хостом (он закроет сервер — ловим разрыв соединения).
	multiplayer.server_disconnected.connect(func() -> void:
		if _turret_ok:
			print("[TURRET_OK] клиент: видимость посадки и выстрелов подтверждена")
		get_tree().create_timer(0.5).timeout.connect(func() -> void: get_tree().quit(0 if _turret_ok else 1))
	)
	get_tree().create_timer(30.0).timeout.connect(func() -> void:
		if _turret_ok:
			print("[TURRET_OK] клиент: видимость посадки и выстрелов подтверждена")
		get_tree().quit(0 if _turret_ok else 1)
	)


func _ffa_client_monitor() -> void:
	Game.scores_changed.connect(func(sc: Dictionary, _my_id: int) -> void:
		_ffa_last_scores = sc
	)
	Game.match_over.connect(func(label: String) -> void:
		var n := _ffa_last_scores.size()
		if n >= 3 and label.contains("Игрок"):
			print("[FFA_OK] клиент: финал получен, в счёте %d игрока; итог:\n%s" % [n, label])
		else:
			print("[FFA_FAIL] клиент: в финальном счёте %d игрока, финал='%s'" % [n, label])
		# Выходим ПОСЛЕ хоста: хост сам завершит сервер, клиент выйдет по разрыву.
		multiplayer.server_disconnected.connect(_ffa_quit)
		get_tree().create_timer(20.0).timeout.connect(_ffa_quit)  # страховка
	)


func _ffa_quit() -> void:
	get_tree().quit(0)


@rpc("authority", "call_remote", "reliable")
func _event_match_over(winner_id: int, sc: Dictionary) -> void:
	# BUILD-29: каждый клиент собирает свой итог (победа/поражение + таблица).
	Game.match_over.emit(_match_over_label(winner_id, sc))


func _on_peer_disconnected(id: int) -> void:
	if Game.smoke_test:
		print("[SMOKE] дисконнект пира %d (сторона: %s)" % [id, "сервер" if multiplayer.is_server() else "клиент"])
	# Сигнал приходит КАЖДОЙ ноде: убираем модель выбывшего везде.
	var p: Node = players.get(id)
	if p != null:
		p.queue_free()
		players.erase(id)
	scores.erase(id)
	_spawn_idx.erase(id)
	if Game.autostart:
		print("[AUTOSTART] игрок %d вышел, осталось %d" % [id, players.size()])
	if not multiplayer.is_server() or _match_over:
		return
	# BUILD-29: FFA — матч продолжается, пока осталось хотя бы 2 игрока.
	if players.size() >= 2:
		Game.scores_changed.emit(scores.duplicate(), multiplayer.get_unique_id())
		return
	# Остался один — он победитель; никого — матч просто закончен.
	_match_over = true
	if players.size() == 1:
		var winner: int = players.keys()[0]
		Game.match_over.emit(_match_over_label(winner, scores))
		_event_match_over.rpc(winner, scores.duplicate())
	else:
		Game.match_over.emit("Все игроки отключились")
		_event_opponent_left.rpc()


@rpc("authority", "call_remote", "reliable")
func _event_opponent_left() -> void:
	Game.match_over.emit("Игрок отключился")


# ---------------------------------------------------------------- smoke-тест (автоматизация)

func _smoke_host_shoots_client() -> void:
	# Повторение жалобы «хост не наносит урон»: хост стреляет в клиента.
	if not multiplayer.is_server():
		return
	var host_node: Node = players.get(1)
	var client_node: Node = null
	for k in players.keys():
		if k != 1:
			client_node = players.get(k)
			break
	if host_node == null or client_node == null:
		print("[SMOKE] сервер: нет обоих игроков (ключи=%s)" % str(players.keys()))
		return
	var origin: Vector3 = host_node.get_head_world_position()
	var dir: Vector3 = (client_node.get_head_world_position() - origin).normalized()
	# Поворачиваем хоста лицом к клиенту и стреляем через реальный _fire() —
	# тот самый путь, что и при клике мышью у игрока.
	host_node.rotation.y = atan2(-dir.x, -dir.z)
	print("[SMOKE] сервер: хост стреляет в клиента через _fire() (%d выстрелов)" % SMOKE_SHOTS)
	for i in SMOKE_SHOTS:
		# Разносим выстрелы на 300 мс — как реальные клики (кулдаун оружия 250 мс).
		get_tree().create_timer(0.3 * i).timeout.connect(host_node._fire)


func _synthetic_click() -> void:
	# Имитация реального клика ЛКМ: событие проходит тот же конвейер,
	# что и событие от ОС (обновление действий ввода -> _unhandled_input).
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.button_mask = 1
	press.position = Vector2(320.0, 240.0)
	press.global_position = press.position
	get_tree().root.push_input(press, true)
	var release: InputEventMouseButton = press.duplicate()
	release.pressed = false
	release.button_mask = 0
	get_tree().root.push_input(release, true)


# Вторая фаза inputtest: нож (быстрый и тяжёлый удар), перезарядка и
# прицеливание снайперки.
#
# Важно: в headless синтетические НАЖАТИЯ КЛАВИШ (push_input + InputEventKey)
# не маппятся на действия, а Input.action_press даёт is_action_just_pressed
# лишь в том же кадре. Поэтому смену слотов делаем напрямую (_select_weapon),
# а огонь/прицел — через Input.action_press (уровневые is_action_pressed
# видны и в следующих кадрах). Так мы проверяем именно игровую логику,
# минуя только ОС-слой клавиатуры.
func _input_test_weapons() -> void:
	if not multiplayer.is_server():
		return
	var me: Node = players.get(1)
	if me == null:
		print("[WEAPONTEST_FAIL] нет ноды хоста")
		return
	print("[WEAPONTEST] фаза оружия: нож -> перезарядка -> прицел снайперки")

	# --- 1) Быстрый удар ножом (ЛКМ).
	me._select_weapon(0)
	get_tree().create_timer(0.3).timeout.connect(func() -> void: Input.action_press("fire"))
	get_tree().create_timer(0.6).timeout.connect(func() -> void: Input.action_release("fire"))

	# --- 2) Тяжёлый удар ножом (замах ~450 мс + удар ~160 мс).
	# Запускаем состояние напрямую: ПКМ-замах опрашивается через
	# is_action_just_pressed, который синтетически не воспроизвести.
	get_tree().create_timer(1.2).timeout.connect(func() -> void:
		me._start_heavy_strike()
		if me._knife_phase != 1:
			print("[WEAPONTEST_FAIL] замах не стартовал (фаза=%d)" % me._knife_phase)
		# BUILD-18: сочленённая рука — кисть правой руки лежит НА РУКОЯТИ ножа
		# и движется вместе с клинком при замахе/ударе.
		var grip_w: Vector3 = me.knife_fp.global_transform * Vector3(0.0, -0.045, 0.13)
		var hand_r: MeshInstance3D = me._fp_arm_nodes[0]["hand"]
		if hand_r.visible and hand_r.global_position.distance_to(grip_w) < 0.05:
			print("[WEAPONTEST] кисть на рукояти ножа, движется с клинком")
		else:
			print("[WEAPONTEST_FAIL] кисть на ноже: видима=%s, от рукояти %.3f м" % [str(hand_r.visible), hand_r.global_position.distance_to(grip_w)])
	)
	get_tree().create_timer(2.2).timeout.connect(func() -> void:
		if me._knife_phase != 0:
			print("[WEAPONTEST_FAIL] тяжёлый удар застрял в фазе %d" % me._knife_phase)
		else:
			print("[WEAPONTEST] тяжёлый удар ОК (замах -> удар -> фаза 0)")
	)

	# --- 3) Перезарядка пистолета: имитируем неполный магазин и старт.
	get_tree().create_timer(2.6).timeout.connect(func() -> void:
		me._select_weapon(1)
		me.ammo_mag[1] = 5
		me._start_reload()
	)
	get_tree().create_timer(4.2).timeout.connect(func() -> void:  # reload 1200 мс + запас
		if int(me.ammo_mag[1]) == 12 and me.reload_end_ms == 0:
			print("[WEAPONTEST] перезарядка пистолета ОК: магазин снова 12")
		else:
			print("[WEAPONTEST_FAIL] перезарядка: магазин=%d, reload_end_ms=%d" % [int(me.ammo_mag[1]), me.reload_end_ms])
	)

	# --- 4) Прицел снайперки (ПКМ): зум + замедление.
	get_tree().create_timer(4.8).timeout.connect(func() -> void:
		me._select_weapon(2)
		Input.action_press("fire_alt")
	)
	get_tree().create_timer(5.4).timeout.connect(func() -> void:
		var fov_ok: bool = me.camera.fov < 40.0
		if me._ads and me.current_weapon == 2 and fov_ok:
			print("[WEAPONTEST] прицел снайперки ОК (ADS, FOV=%.1f)" % me.camera.fov)
		else:
			print("[WEAPONTEST_FAIL] прицел: ADS=%s оружие=%d FOV=%.1f" % [str(me._ads), me.current_weapon, me.camera.fov])
	)
	get_tree().create_timer(5.9).timeout.connect(func() -> void: Input.action_release("fire_alt"))
	get_tree().create_timer(6.3).timeout.connect(func() -> void:
		if not me._ads:
			print("[WEAPONTEST] прицел отпущен")
		else:
			print("[WEAPONTEST_FAIL] прицел не отпустился")
	)

	# --- 5) Реакции оружия у стены (BUILD-14/15): подъём ВВЕРХ, складывание
	# «в обе руки» ВНИЗ-влево, ствол ВНИЗ при взгляде вверх; выстрел со
	# смещённым оружием ЗАБЛОКИРОВАН, свободный выстрел — строго в перекрестие.
	# 5a) Пистолет у стены: ствол поднимается ВВЕРХ, оружие не у камеры.
	get_tree().create_timer(6.8).timeout.connect(func() -> void:
		me._select_weapon(1)  # пистолет
		me.position = Vector3(-21.1, 1.0, 0.0)
		me.rotation.y = PI / 2.0  # лицом к стене (-X)
		me.head.rotation.x = 0.0
		me.reset_net_targets()
	)
	get_tree().create_timer(7.3).timeout.connect(func() -> void:
		var up := bool(me._fp_tilt > 0.7)
		var not_pulled := bool(me.gun_anchor.position.z < -0.34)
		if up and not_pulled:
			print("[WEAPONTEST] пистолет у стены: ствол ВВЕРХ (%.2f рад), не у камеры (z=%.2f)" % [me._fp_tilt, me.gun_anchor.position.z])
		else:
			print("[WEAPONTEST_FAIL] пистолет у стены: наклон=%.2f, z=%.2f" % [me._fp_tilt, me.gun_anchor.position.z])
		me._select_weapon(2)  # снайперка — длинная, должна сложиться
	)
	# 5b) Снайперка у стены: ей не хватает места — СКЛАДЫВАНИЕ к груди.
	get_tree().create_timer(7.7).timeout.connect(func() -> void:
		if me._fp_fold > 0.8:
			print("[WEAPONTEST] снайперка у стены: СЛОЖЕНА к груди (fold=%.2f)" % me._fp_fold)
		else:
			print("[WEAPONTEST_FAIL] снайперка не сложилась (наклон=%.2f, fold=%.2f)" % [me._fp_tilt, me._fp_fold])
	)
	# 5c) Пистолет вплотную к стене: складывается. Выстрел из сложенного
	# положения ЗАБЛОКИРОВАН (пуля не должна лететь по кривому стволу).
	get_tree().create_timer(8.1).timeout.connect(func() -> void:
		me._select_weapon(1)
		me.position = Vector3(-21.4, 1.0, 0.0)  # 35 см до стены
		me.rotation.y = PI / 2.0
		me.reset_net_targets()
	)
	get_tree().create_timer(8.7).timeout.connect(func() -> void:
		var folded := bool(me._fp_fold > 0.8)
		var displaced := bool(me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		me._fire()  # попытка выстрела из сложенного положения
		var blocked := bool(int(me.ammo_mag[1]) == before)
		if folded and displaced and blocked:
			print("[WEAPONTEST] упор: оружие СЛОЖЕНО (fold=%.2f), выстрел ЗАБЛОКИРОВАН (патроны %d→%d)" % [me._fp_fold, before, int(me.ammo_mag[1])])
		else:
			print("[WEAPONTEST_FAIL] упор: fold=%.2f, displaced=%s, патроны %d→%d" % [me._fp_fold, str(displaced), before, int(me.ammo_mag[1])])
	)
	# 5d) Взгляд ВВЕРХ на стену: реакция — ствол опускается ВНИЗ.
	get_tree().create_timer(9.1).timeout.connect(func() -> void:
		me.position = Vector3(-21.1, 1.0, 0.0)
		me.head.rotation.x = 0.6
		me.reset_net_targets()
	)
	get_tree().create_timer(9.7).timeout.connect(func() -> void:
		if me._fp_tilt < -0.5 and me._fp_fold < 0.2:
			print("[WEAPONTEST] взгляд вверх: ствол опущен ВНИЗ (%.2f рад)" % me._fp_tilt)
		else:
			print("[WEAPONTEST_FAIL] взгляд вверх: наклон=%.2f, fold=%.2f" % [me._fp_tilt, me._fp_fold])
	)
	# 5e) Пистолет ПОДНЯТ у стены (наклон > 0.25): выстрел тоже заблокирован.
	get_tree().create_timer(9.9).timeout.connect(func() -> void:
		me.head.rotation.x = 0.0
		me.position = Vector3(-21.1, 1.0, 0.0)
		me.reset_net_targets()
	)
	get_tree().create_timer(10.4).timeout.connect(func() -> void:
		var raised := bool(me._fp_tilt > 0.7)
		var displaced := bool(me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		me._fire()  # попытка выстрела с поднятым стволом
		var blocked := bool(int(me.ammo_mag[1]) == before)
		if raised and displaced and blocked:
			print("[WEAPONTEST] ствол ВВЕРХ (%.2f рад): выстрел ЗАБЛОКИРОВАН" % me._fp_tilt)
		else:
			print("[WEAPONTEST_FAIL] поднятый ствол: наклон=%.2f, displaced=%s, патроны %d→%d" % [me._fp_tilt, str(displaced), before, int(me.ammo_mag[1])])
	)
	# 5f) Отошли от стены: оружие свободно, выстрел идёт СТРОГО в перекрестие.
	get_tree().create_timer(10.7).timeout.connect(func() -> void:
		me.position = Vector3(-10.0, 1.0, 0.0)  # возвращаем на спавн
		me.rotation.y = -PI / 2.0
		me.reset_net_targets()
	)
	get_tree().create_timer(11.2).timeout.connect(func() -> void:
		me.next_allowed_shot_ms = 0
		var free := bool(me._fp_tilt < 0.05 and me._fp_fold < 0.05 and not me._weapon_displaced())
		var before := int(me.ammo_mag[1])
		var cam_fwd: Vector3 = -me.camera.global_transform.basis.z
		var aim_dot: float = me._aim_dir().dot(cam_fwd)
		me._fire()
		var fired := bool(int(me.ammo_mag[1]) == before - 1)
		var straight := bool(aim_dot > 0.999)
		if free and fired and straight:
			print("[WEAPONTEST] свободно: выстрел в перекрестие (патроны %d→%d, dot=%.3f)" % [before, int(me.ammo_mag[1]), aim_dot])
		else:
			print("[WEAPONTEST_FAIL] свободный выстрел: free=%s, fired=%s, dot=%.3f, патроны %d→%d" % [str(free), str(fired), aim_dot, before, int(me.ammo_mag[1])])
	)
	# BUILD-19: соперник — НЕ стена: встаём вплотную к клиенту, оружие не
	# должно складываться/задираться из-за его тела.
	get_tree().create_timer(11.6).timeout.connect(func() -> void:
		me.position = Vector3(9.3, 1.0, 0.0)  # ~0.7 м до клиента (спавн +10)
		me.rotation.y = PI / 2.0
		me.head.rotation.x = 0.0
		me.reset_net_targets()
	)
	get_tree().create_timer(12.3).timeout.connect(func() -> void:
		if me._fp_fold < 0.1 and absf(me._fp_tilt) < 0.1:
			print("[WEAPONTEST] соперник не стена: в упор оружие НЕ сложено (fold=%.2f, наклон=%.2f)" % [me._fp_fold, me._fp_tilt])
			print("[WEAPONTEST_OK]")
		else:
			print("[WEAPONTEST_FAIL] оружие среагировало на тело соперника (fold=%.2f, наклон=%.2f)" % [me._fp_fold, me._fp_tilt])
		me.position = Vector3(-10.0, 1.0, 0.0)
		me.rotation.y = -PI / 2.0
		me.reset_net_targets()
	)
	# BUILD-21/23: взгляд сильно ВНИЗ, «ровно под тело» — оружие и руки
	# выносятся ПЕРЕД телом, а не проваливаются в него; стрельба разрешена.
	get_tree().create_timer(12.7).timeout.connect(func() -> void:
		me.head.rotation.x = -1.55  # ~89° вниз, ровно под себя
	)
	get_tree().create_timer(13.5).timeout.connect(func() -> void:
		var gp: Vector3 = me.gun_anchor.global_position
		var radial := Vector2(gp.x - me.global_position.x, gp.z - me.global_position.z).length()
		me.next_allowed_shot_ms = 0
		var before := int(me.ammo_mag[1])
		me._fire()
		var fired := bool(int(me.ammo_mag[1]) == before - 1)
		if radial > 0.29 and radial < 0.5 and gp.y < 1.35 and fired and me._fp_fold < 0.05 and absf(me._fp_tilt) < 0.05:
			print("[WEAPONTEST] взгляд вниз: оружие У тела (%.2f м от оси), локти согнуты, выстрел разрешён (%d→%d)" % [radial, before, int(me.ammo_mag[1])])
		else:
			print("[WEAPONTEST_FAIL] взгляд вниз: от оси=%.2f м, y=%.2f, fired=%s, fold=%.2f, наклон=%.2f" % [radial, gp.y, str(fired), me._fp_fold, me._fp_tilt])
		# BUILD-22: локти при взгляде вниз сгибаются и остаются ВНЕ тела.
		var elb: MeshInstance3D = me._fp_arm_nodes[1]["upper"]
		var half: float = elb.mesh.size.z * 0.5
		var e1 := elb.global_position + elb.global_transform.basis.z * half
		var e2 := elb.global_position - elb.global_transform.basis.z * half
		var shp: Vector3 = me._fp_arm_nodes[1]["shoulder"].global_position
		var ep := e1 if e1.distance_to(shp) > e2.distance_to(shp) else e2
		var elb_rad := Vector2(ep.x - me.global_position.x, ep.z - me.global_position.z).length()
		if elb_rad > 0.30:
			print("[WEAPONTEST] взгляд вниз: локти согнуты и вне тела (%.2f м от оси)" % elb_rad)
		else:
			print("[WEAPONTEST_FAIL] локоть внутри тела: %.2f м от оси" % elb_rad)
		# BUILD-23: новое тело — торс и ноги с коленями видны, стопы на земле.
		var feet_ok := bool(me.torso_node != null and me.torso_node.visible \
			and me._leg_rig_r["foot"].global_position.y < 0.2 \
			and me._leg_rig_l["foot"].global_position.y < 0.2)
		# BUILD-26: свои грудь и шея скрыты — не перекрывают камеру.
		var chest_hidden := bool(not me._chest_mesh.visible and not me._neck_mesh.visible)
		if feet_ok and chest_hidden:
			print("[WEAPONTEST] тело: ноги с коленями на земле; свои грудь/шея скрыты (обзор чистый)")
		else:
			print("[WEAPONTEST_FAIL] тело: ноги=%s, грудь_скрыта=%s" % [str(feet_ok), str(chest_hidden)])
		# Резкий поворот: торс доворачивается первым (не больше 0.7 рад),
		# затем ноги и всё тело следуют.
		me.rotation.y += 2.4
	)
	get_tree().create_timer(13.7).timeout.connect(func() -> void:
		var diff := wrapf(me.rotation.y - me._legs_yaw, -PI, PI)
		var twist: float = float(me.torso_node.rotation.y) + diff
		if absf(twist) > 0.6 and absf(twist) <= 0.71 and absf(diff) > 0.7:
			print("[WEAPONTEST] торс: сначала довернулся торс (%.2f рад), тело ещё догоняет (%.2f)" % [twist, diff])
		else:
			print("[WEAPONTEST_FAIL] торс: твист=%.2f, разница=%.2f" % [twist, diff])
	)
	get_tree().create_timer(14.2).timeout.connect(func() -> void:
		var diff2 := wrapf(me.rotation.y - me._legs_yaw, -PI, PI)
		if absf(diff2) < 0.3:
			print("[WEAPONTEST] торс: затем всё тело довернулось следом")
		else:
			print("[WEAPONTEST_FAIL] торс: тело не довернулось (остаток %.2f)" % diff2)
		me.head.rotation.x = 0.0
		me.rotation.y = -PI / 2.0
		me.reset_net_targets()
	)
	# BUILD-25: «кручусь на WASD» — ноги отклоняются в сторону шага лишь
	# в пределах 0.6 рад от взгляда и не делают полный оборот.
	get_tree().create_timer(14.5).timeout.connect(func() -> void:
		var side: Vector3 = me.global_transform.basis.x
		for i in 60:
			me._update_body_pose(0.05, true, side, false, true, 0.0, 0.0, 0.0)
		var lean := wrapf(me._legs_yaw - me.rotation.y, -PI, PI)
		if absf(lean) <= 0.61:
			print("[WEAPONTEST] стрейф по кругу: ноги отклонились на %.2f рад, без оборота" % lean)
		else:
			print("[WEAPONTEST_FAIL] стрейф: ноги ушли на %.2f рад" % lean)
		me.reset_net_targets()
	)

# Клиентская часть inputtest: проверяем, что анимации хоста (замах ножа,
# перезарядка, прицел) реально дошли до клиента и проигрываются на его
# копии ноды хоста. Тайминги синхронизированы с _input_test_weapons хоста
# (фаза стартует через 16 с после спавна).
func _input_test_client_checks() -> void:
	if multiplayer.is_server():
		return
	var host_node: Node = players.get(1)
	if host_node == null:
		print("[CLIENTANIM_FAIL] нет ноды хоста у клиента")
		return
	# BUILD-27: присед и прыжок синхронизированы. Хост: присед 14.6..15.8,
	# прыжок 15.9..16.4. Клиент опрашивает дважды (запас на рассинхрон часов).
	# Замах тяжёлого удара: у хоста старт на +17.2 с, длится до +17.9 с.
	# Заодно проверяем кисть от первого лица, прикреплённую к ножу (BUILD-15):
	# она видна вместе с клинком и машет вместе с ним.
	get_tree().create_timer(17.45).timeout.connect(func() -> void:
		if host_node._remote_knife_phase == 1 or host_node._remote_knife_phase == 2:
			print("[CLIENTANIM] замах ножа соперника виден (фаза=%d)" % host_node._remote_knife_phase)
		else:
			print("[CLIENTANIM_FAIL] замах ножа не пришёл (фаза=%d)" % host_node._remote_knife_phase)
		# BUILD-18: рука соперника на ноже — СОЧЛЕНЁННАЯ: правая видима, кисть
		# на рукояти клинка, левая скрыта (нож держат одной рукой).
		var rarm: Dictionary = host_node._remote_arm_nodes[0]
		var larm: Dictionary = host_node._remote_arm_nodes[1]
		var knife_grip_w: Vector3 = host_node.knife_remote.global_transform * Vector3(0.0, -0.045, 0.12)
		var knife_arms_ok: bool = rarm["upper"].visible and not larm["upper"].visible \
			and rarm["hand"].global_position.distance_to(knife_grip_w) < 0.05
		if knife_arms_ok:
			print("[CLIENTANIM] рука соперника на ноже: сочленённая, кисть на рукояти")
		else:
			print("[CLIENTANIM_FAIL] рука на ноже: правая=%s, левая скрыта=%s, от рукояти %.3f м" % [str(rarm["upper"].visible), str(not larm["upper"].visible), rarm["hand"].global_position.distance_to(knife_grip_w)])
	)
	# Перезарядка: у хоста +18.6..19.8 с. Перезарядка пистолета видна
	# вместе с кистями на оружии (BUILD-15).
	get_tree().create_timer(19.05).timeout.connect(func() -> void:
		if host_node._remote_reload_end_ms > Time.get_ticks_msec():
			print("[CLIENTANIM] перезарядка соперника видна")
		else:
			print("[CLIENTANIM_FAIL] перезарядка соперника не пришла")
		var hands: bool = host_node._remote_arm_nodes.size() == 2 \
			and host_node._remote_arm_nodes[0]["hand"].visible \
			and host_node._remote_arm_nodes[1]["hand"].visible
		if hands:
			print("[CLIENTANIM] кисти соперника видны на пистолете")
		else:
			print("[CLIENTANIM_FAIL] кисти соперника на пистолете не видны")
		# Рука СОЧЛЕНЁННАЯ: сегмент плеча фиксированной длины (локоть существует).
		var upper: MeshInstance3D = host_node._remote_arm_nodes[0]["upper"]
		var up_len: float = upper.mesh.size.z
		if up_len > 0.2 and upper.visible:
			print("[CLIENTANIM] рука соперника сочленённая: плечо %.2f м + предплечье + кисть" % up_len)
		else:
			print("[CLIENTANIM_FAIL] сегмент плеча соперника: длина=%.2f, виден=%s" % [up_len, str(upper.visible)])
	)
	# BUILD-28: idle-дыхание соперника синхронизировано (два замера фазы).
	get_tree().create_timer(20.5).timeout.connect(func() -> void:
		_breath_c0 = host_node._remote_breath
	)
	get_tree().create_timer(20.9).timeout.connect(func() -> void:
		if absf(host_node._remote_breath - _breath_c0) > 0.001:
			print("[CLIENTANIM] idle-дыхание соперника синхронизировано (%.4f м)" % host_node._remote_breath)
		else:
			print("[CLIENTANIM_FAIL] idle-дыхание соперника не пришло")
	)
	# Прицел: у хоста +20.8..21.9 с. Заодно проверяем (BUILD-15):
	# — снайперка соперника НЕ перевёрнута (рыск ≈ базовый π, как в сцене);
	# — дуло смотрит ВПЕРЁД по взгляду соперника;
	# — обе кисти соперника лежат на снайперке.
	get_tree().create_timer(21.2).timeout.connect(func() -> void:
		if host_node._remote_ads:
			print("[CLIENTANIM] прицел соперника виден")
		else:
			print("[CLIENTANIM_FAIL] прицел соперника не пришёл")
		var yaw_err := absf(wrapf(host_node.sniper_remote.rotation.y - host_node._sniper_remote_yaw0, -PI, PI))
		if yaw_err < 0.05:
			print("[CLIENTANIM] снайперка соперника НЕ перевёрнута (рыск=%.2f)" % host_node.sniper_remote.rotation.y)
		else:
			print("[CLIENTANIM_FAIL] снайперка соперника перевёрнута (рыск=%.2f, база=%.2f)" % [host_node.sniper_remote.rotation.y, host_node._sniper_remote_yaw0])
		var muzzle_fwd: bool = host_node.sniper_remote_muzzle.global_position.x > host_node.head.global_position.x
		if muzzle_fwd:
			print("[CLIENTANIM] дуло снайперки смотрит вперёд")
		else:
			print("[CLIENTANIM_FAIL] дуло снайперки смотрит назад")
		var hands: bool = host_node._remote_arm_nodes.size() == 2 \
			and host_node._remote_arm_nodes[0]["hand"].visible \
			and host_node._remote_arm_nodes[1]["hand"].visible
		var grip_ok: bool = hands and host_node._remote_arm_nodes[0]["hand"].global_position.distance_to(host_node.sniper_remote.global_transform * Vector3(0.0, -0.16, 0.5)) < 0.03
		if grip_ok:
			print("[CLIENTANIM] обе сочленённые руки соперника лежат на снайперке")
		else:
			print("[CLIENTANIM_FAIL] руки соперника на снайперке: видны=%s, на рукоятке=%s" % [str(hands), str(grip_ok)])
	)
	# Всё должно сброситься после окончания фазы.
	get_tree().create_timer(22.6).timeout.connect(func() -> void:
		if not host_node._remote_ads and host_node._remote_knife_phase == 0:
			print("[CLIENTANIM] состояния соперника сбросились")
		else:
			print("[CLIENTANIM_FAIL] состояния соперника не сбросились (ADS=%s, нож=%d)" % [str(host_node._remote_ads), host_node._remote_knife_phase])
	)
	# BUILD-17: реакции у стен ПРИХОДЯТ ПО СЕТИ от владельца (у хоста фаза
	# стен стартует на +22.8 с). В +23.15 хост держит пистолет у стены —
	# ствол ПОДНЯТ; проверяем, что мы видим тот же наклон, что у владельца.
	get_tree().create_timer(23.15).timeout.connect(func() -> void:
		if host_node._remote_tilt > 0.7 and host_node._remote_fold < 0.2:
			print("[CLIENTANIM] наклон соперника синхронизирован (ствол вверх, %.2f рад)" % host_node._remote_tilt)
		else:
			print("[CLIENTANIM_FAIL] наклон соперника не пришёл (наклон=%.2f, fold=%.2f)" % [host_node._remote_tilt, host_node._remote_fold])
	)
	# В +24.9 хост держит пистолет ВПЛОТНУЮ к стене — оружие СЛОЖЕНО ВБОК.
	# Раньше мы видели вместо этого подъём ствола; теперь складывание должно
	# прийти по сети: большой fold и НЕбольшой наклон.
	get_tree().create_timer(24.9).timeout.connect(func() -> void:
		if host_node._remote_fold > 0.7 and host_node._remote_tilt < 0.3:
			print("[CLIENTANIM] складывание соперника синхронизировано (ВБОК, fold=%.2f, наклон=%.2f)" % [host_node._remote_fold, host_node._remote_tilt])
		else:
			print("[CLIENTANIM_FAIL] складывание соперника: наклон=%.2f, fold=%.2f (ожидали ВБОК)" % [host_node._remote_tilt, host_node._remote_fold])
	)
	# BUILD-21: хост на +28.7 с держит взгляд вниз (тангаж -1.3 рад). Его
	# оружие должно быть вынесено ПЕРЕД телом, а не проваливаться внутрь.
	get_tree().create_timer(29.3).timeout.connect(func() -> void:
		var gp: Vector3 = host_node.remote_gun.global_position
		var radial := Vector2(gp.x - host_node.global_position.x, gp.z - host_node.global_position.z).length()
		# BUILD-22: вторая (левая) рука соперника не пересекает торс —
		# локоть держится снаружи.
		var elb: MeshInstance3D = host_node._remote_arm_nodes[1]["upper"]
		var half: float = elb.mesh.size.z * 0.5
		var e1 := elb.global_position + elb.global_transform.basis.z * half
		var e2 := elb.global_position - elb.global_transform.basis.z * half
		var shp: Vector3 = host_node._remote_arm_nodes[1]["shoulder"].global_position
		var ep := e1 if e1.distance_to(shp) > e2.distance_to(shp) else e2
		var elb_rad := Vector2(ep.x - host_node.global_position.x, ep.z - host_node.global_position.z).length()
		# BUILD-23: у соперника видны торс и ноги с коленями, стопы на земле.
		var feet_ok := bool(host_node.torso_node != null and host_node.torso_node.visible \
			and host_node._leg_rig_r["foot"].global_position.y < 0.2 \
			and host_node._leg_rig_l["foot"].global_position.y < 0.2)
		# BUILD-26: у соперника тело ПОЛНОЕ (грудь видна), у себя — скрыта.
		var chest_ok := bool(host_node._chest_mesh.visible)
		if host_node.head.rotation.x < -1.0 and radial > 0.29 and radial < 0.5 and elb_rad > 0.30 and feet_ok and chest_ok:
			print("[CLIENTANIM] соперник вниз: оружие у тела (%.2f м), локти вне (%.2f м), ноги с коленями на земле" % [radial, elb_rad])
			print("[CLIENTANIM_OK]")
		else:
			print("[CLIENTANIM_FAIL] соперник вниз: тангаж=%.2f, оружие=%.2f, локоть=%.2f, ноги=%s" % [host_node.head.rotation.x, radial, elb_rad, str(feet_ok)])
	)


func _smoke_on_got_hit() -> void:
	_smoke_client_got_hits += 1
	print("[SMOKE] клиент: получил урон #%d" % _smoke_client_got_hits)
	if _smoke_client_got_hits == SMOKE_SHOTS:
		print("[SMOKE] SMOKE_CLIENT_GOT_HIT_OK (урон от хоста дошёл)")
		if Game.input_test:
			for i in SMOKE_SHOTS:
				get_tree().create_timer(0.2 + 0.3 * i).timeout.connect(_synthetic_click)
		else:
			_smoke_client_fire_deferred(0)  # теперь отвечаем огнём


func _smoke_client_fire_deferred(attempt: int) -> void:
	if attempt > 10 or _smoke_fired:
		return
	var me: Node = players.get(multiplayer.get_unique_id())
	var host: Node = players.get(1)
	if me == null or host == null:
		get_tree().create_timer(0.2).timeout.connect(func() -> void:
			_smoke_client_fire_deferred(attempt + 1)
		)
		return
	_smoke_fired = true
	var origin: Vector3 = me.get_head_world_position()
	var dir: Vector3 = (host.get_head_world_position() - origin).normalized()
	print("[SMOKE] клиент: стреляю в хоста (%d выстрелов)" % SMOKE_SHOTS)
	for i in SMOKE_SHOTS:
		me.request_shoot.rpc_id(1, origin, dir, 1, 0)  # пистолет, обычная атака


func _smoke_on_dealt_hit() -> void:
	_smoke_client_hits += 1
	if _smoke_client_hits >= SMOKE_SHOTS:
		print("[SMOKE] SMOKE_CLIENT_OK")
		if Game.input_test:
			# Не выходим сразу: хост ещё проверяет нож/перезарядку/прицел,
			# а дисконнект клиента завершил бы матч досрочно.
			get_tree().create_timer(30.0).timeout.connect(func() -> void: get_tree().quit(0))
		else:
			get_tree().quit(0)


func _smoke_host_finish() -> void:
	if not Game.smoke_test or not multiplayer.is_server():
		return
	if _smoke_hits >= SMOKE_SHOTS * 2:  # клиент попал в хоста + хост попал в клиента
		print("[SMOKE] SMOKE_HOST_OK хиты=%d" % _smoke_hits)
		get_tree().quit(0)
	else:
		print("[SMOKE] SMOKE_HOST_FAIL хиты=%d (ожидалось %d)" % [_smoke_hits, SMOKE_SHOTS * 2])
		get_tree().quit(1)
