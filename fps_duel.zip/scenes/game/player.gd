extends CharacterBody3D
## Сетевой FPS-игрок.
##
## Имя ноды = peer id. Владелец управляет движением/камерой и стреляет;
## второй игрок видит тело с интерполяцией и процедурной «анимацией»
## (покачивание при ходьбе, отдача оружия) — см. _process.
##
## Синхронизация оптимизирована под 2 игроков: один ненадёжный
## упорядоченный пакет состояния в 20 Гц на игрока, события — надёжные.

const SPEED := 6.0
const JUMP_VELOCITY := 5.5
const GRAVITY := 20.0
const MOUSE_SENS := 0.0026
const NET_INTERVAL := 0.05  # 20 Гц
## Путь к 3Д-модели снайперской винтовки (сцена в вашем проекте).
## Если файла нет — игра не сломается, слот покажет модель-заглушку.
const SNIPER_SCENE_PATH := "res://sniper_gun.tscn"
# Общие параметры анимации оружия — ОДИНАКОВЫЕ для вида от первого лица
# и для «чужой» модели, чтобы оба игрока выглядели согласованно.
const BOB_SPEED := 9.0
const FP_BOB_AMP := Vector3(0.012, 0.014, 0.0)
const REMOTE_BOB_AMP := 0.05
const RECOIL_TIME := 0.28
const RECOIL_PUSH := Vector3(0.0, 0.02, 0.11)
const RECOIL_ROT_X := 0.18
## BUILD-20: отдача с лёгким уводом ствола вправо (сочнее, чем чисто вверх).
const RECOIL_ROT_Z := -0.06
## BUILD-20: покачивание оружия в такт шагам — небольшой крен и тангаж.
const WALK_SWAY_PITCH := 0.012
const WALK_SWAY_ROLL := 0.02
## BUILD-20: «дыхание» в покое — едва заметный подъём оружия.
const IDLE_BREATH_AMP := 0.004
# BUILD-21: «выталкивание» при прицеливании вниз. Якорь оружия висит на
# голове и при взгляде вниз описывает дугу ВОКРУГ головы — на крутом
# тангаже оружие и руки проваливались внутрь собственного тела (капсула
# радиусом 0.32). Ниже порога оружие выносится ВПЕРЁД по горизонтали (от
# груди) и чуть вниз — руки вытягиваются, как в жизни. Направление ствола
# НЕ меняется, поэтому стрельба остаётся разрешённой.
const DOWN_AIM_START := 0.35  # рад взгляда вниз, с которого начинаем выносить
const DOWN_AIM_FULL := 0.95   # рад, где вынос выходит на максимум
const DOWN_AIM_PUSH := 0.34   # м вперёд от тела
const DOWN_AIM_DROP := 0.08   # м вниз
# BUILD-23/24: оружие/якорь не подходят к вертикальной оси тела ближе этого
# радиуса — но и не дальше: оружие держится У груди, локти сгибаются.
const BODY_CLEAR_R := 0.31
# BUILD-23: тело — торс с предварительным доворотом + ноги с коленями.
const TORSO_TWIST_MAX := 0.7  # рад: максимум доворота торса относительно ног
const TORSO_TURN_SPEED := 10.0  # рад/с: торс доворачивается плавно (после рук)
const LEGS_TURN_SPEED := 7.0  # рад/с: затем ноги и всё тело следуют
const LEGS_STRAFE_MAX := 0.6  # рад: ноги отклоняются в сторону шага не дальше
const THIGH_LEN := 0.50
const SHIN_LEN := 0.48
const LEG_STRIDE := 0.26
const LEG_LIFT := 0.10
# BUILD-27: присед и прыжок.
const HEAD_Y := 1.62
const HEAD_Y_CROUCH := 1.24
const TORSO_Y := 1.02
const TORSO_Y_CROUCH := 0.80
const HIP_Y := 0.98
const HIP_Y_CROUCH := 0.60
const CROUCH_SPEED_MULT := 0.5
# Длительности анимаций ножа (общие для вида от первого лица и для
# «чужого» ножа — поэтому анимации совпадают у обоих игроков).
const KNIFE_QUICK_TIME := 0.24
const KNIFE_HEAVY_SWING := 0.26
const KNIFE_REMOTE_KICK := 0.18
# Коллизия оружия со стенами. Главный принцип: у стены ствол ПОДНИМАЕТСЯ
# ВВЕРХ (как в Ready or Not / Insurgency), а не едет игроку в лицо.
# Небольшая оттяжка назад (до 8 см) гасит начальный контакт, глубокая —
# только крайняя мера при упоре вплотную (предел WEAPON_MIN_Z).
const WEAPON_WALL_MARGIN := 0.02   # визуальный зазор до поверхности (м)
const WEAPON_SOFT_PULL := 0.08     # лёгкая оттяжка при первом контакте (м)
const WEAPON_MIN_Z := -0.20        # ближе этой точки к глазам оружие НЕ подтягивается (м)
const WEAPON_MAX_TILT := 1.52      # ~87° — предел подъёма ствола у стены
# --- Вариации реакции у стены (как в Ready or Not / Tarkov) ---
# Если нужного угла подъёма не хватает — оружие СКЛАДЫВАЕТСЯ к груди
# «в обе руки»; если игрок смотрит вверх — ствол опускается ВНИЗ.
const WEAPON_FOLD_TILT := 1.05     # нужный угол выше этого — складывание
const WEAPON_FOLD_EXIT := 1.0      # гистерезис: выход из складывания
const WEAPON_FOLD_POS := Vector3(-0.06, -0.24, -0.22)  # поза у груди (в системе головы)
const WEAPON_FOLD_PITCH := 0.45    # дуло чуть вверх в сложенной позе
const WEAPON_FOLD_ROLL := -0.40    # завал ствола в сложенной позе
const WEAPON_DOWN_PITCH := 0.25    # смотрим вверх сильнее — реакция «ствол вниз»
const WEAPON_DOWN_TILT := 0.55     # угол опускания ствола в реакции «вниз»
const WEAPON_DOWN_PULL := 0.17     # отвод при опускании (ствол смотрит почти вперёд)

var health: float = 100.0
var dead := false
var next_allowed_shot_ms := 0
## Текущий слот оружия: 0 — нож, 1 — пистолет, 2 — снайперка.
## Синхронизирован по сети (см. set_weapon) и проверяется сервером.
var current_weapon := 1
## Боезапас по слотам (патроны в магазине / запас). Сервер ведёт свой учёт
## и не засчитывает выстрел без патронов.
var ammo_mag := {}
var ammo_reserve := {}
## Момент завершения перезарядки (мс; 0 = не перезаряжается).
var reload_end_ms := 0
## Прицеливание снайперки (ПКМ).
var _ads := false
## Плавный вес прицеливания (для анимации оружия от первого лица).
var _ads_weight := 0.0
# Анимации ножа: 0 — нет, 1 — замах, 2 — тяжёлый удар, 3 — быстрый удар.
var _knife_phase := 0
var _knife_t := 0.0
# --- Состояние анимаций СОПЕРНИКА (приходит по сети) ---
## Прицеливается ли соперник (из пакета состояния, 20 Гц).
var _remote_ads := false
var _remote_ads_w := 0.0
## Перезарядка соперника: локальная оценка конца по данным из пакетов.
var _remote_reload_end_ms := 0
var _remote_reload_ms := 1
## Атака ножа соперника (событие play_melee).
var _remote_knife_phase := 0
var _remote_knife_t := 0.0
## Реакция оружия у стены: текущий угол (со знаком: + вверх, - вниз)
## и «складывание к груди» (0..1) — свои и соперника.
var _fp_tilt := 0.0
var _fp_fold := 0.0
var _fp_folded := false
var _remote_tilt := 0.0
var _remote_fold := 0.0
var _remote_folded := false
## BUILD-17: наклон/складывание, ПРИНЯТЫЕ от владельца по сети. Реакция
## оружия соперника на стены больше не пересчитывается локально (геометрия
## «чужих» нод отличается, и выходили другие углы) — поза берётся из пакета
## состояния владельца, поэтому оба игрока видят одно и то же.
var _remote_tilt_target := 0.0
var _remote_fold_target := 0.0
## Базовый рыск «чужой» снайперки (π — модель развёрнута в сцене):
## складывание докручивает рыск ОТ НЕГО, иначе модель переворачивается.
var _sniper_remote_yaw0 := 0.0
## BUILD-18: сочленённые руки (плечо→локоть→предплечье→кисть, двухзвенная IK).
## Первый кадр: корень рук от 1-го лица + списки оснасток [{upper, fore, hand}]
## для первого лица и для соперника. См. _setup_arms() / _update_fp_arms().
var _fp_arms_root: Node3D = null
var _fp_arm_nodes: Array = []
var _remote_arm_nodes: Array = []
# BUILD-23: торс + ноги.
var torso_node: Node3D = null
var legs_node: Node3D = null
var _legs_yaw := 0.0
var _torso_twist := 0.0
var _chest_mesh: MeshInstance3D = null
var _neck_mesh: MeshInstance3D = null
var _pelvis_mesh: MeshInstance3D = null
var _crouch_w := 0.0
var _air_w := 0.0
var _leg_phase := 0.0
var _remote_crouch := false
var _remote_grounded := true
var _fp_breath := 0.0      # BUILD-28: idle-дыхание владельца (шлётся в сеть)
var _remote_breath := 0.0  # BUILD-28: дыхание соперника из пакета
var dbg_crouch := false  # для автотестов (хедлесс без клавиатуры)

# BUILD-30: турель. Индекс занятой турели (-1 = пешком) и вес сидячей позы.
const TURRET_SEAT_HIP_Y := 0.95
const TURRET_SEAT_TORSO_Y := 0.98
const TURRET_SEAT_HEAD_Y := 1.55
var mounted_idx := -1
var _mounted_w := 0.0
## Текущий флаг перезарядки турели (для визуала ствольной группы):
## у владельца — из его копии турели, у соперника — из пакета состояния.
var turret_reload_now := false
@onready var _body_shape: CollisionShape3D = $BodyShape
@onready var _hitbox_shape: CollisionShape3D = $Hitbox/HitboxShape
var _leg_rig_r: Dictionary = {}
var _leg_rig_l: Dictionary = {}

var _net_timer := 0.0
var _target_pos := Vector3.ZERO
var _target_yaw := 0.0
var _target_pitch := 0.0
var _remote_moving := false
var _recoil_time := 0.0
var _remote_bob_w := 0.0
var _was_dead := false
# Процедурная анимация оружия от первого лица: отдача + покачивание при ходьбе.
var _fp_recoil := 0.0
var _bob_t := 0.0
var _bob_weight := 0.0
var _idle_t := 0.0
var _gun_base_pos := Vector3(0.22, -0.18, -0.45)
# Анимация «чужого» игрока: фаза покачивания + база оружия.
var _remote_bob_t := 0.0
var _remote_gun_base := Vector3(0.22, -0.1, -0.35)
var _remote_sniper_base := Vector3(0.22, -0.16, -0.2)
var _remote_knife_base := Vector3(0.22, -0.14, -0.3)
# Куда «поднимается» чужая снайперка в прицеле (к плечу/лицу).
const REMOTE_SNIPER_ADS_BASE := Vector3(0.02, -0.11, -0.14)
var _knife_base_pos := Vector3(0.0, -0.02, -0.28)

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var gun_anchor: Node3D = $Head/GunAnchor
@onready var muzzle: Marker3D = $Head/GunAnchor/Muzzle
@onready var remote_body: Node3D = $RemoteBody
@onready var _head_mesh: MeshInstance3D = $RemoteBody/HeadMesh
@onready var remote_gun: MeshInstance3D = $Head/RemoteGun
@onready var remote_muzzle: Marker3D = $Head/RemoteGun/RemoteMuzzle
# Оружие от первого лица (дети GunAnchor — на них действует покачивание/отдача).
@onready var gun_mesh: MeshInstance3D = $Head/GunAnchor/GunMesh
@onready var knife_fp: Node3D = $Head/GunAnchor/KnifeFP
@onready var sniper_fp: Node3D = $Head/GunAnchor/SniperFP
@onready var sniper_fp_muzzle: Marker3D = $Head/GunAnchor/SniperFP/SniperMuzzleFP
# «Чужое» оружие — что видит соперник.
@onready var knife_remote: Node3D = $Head/RemoteKnife
@onready var sniper_remote: Node3D = $Head/RemoteSniper
@onready var sniper_remote_muzzle: Marker3D = $Head/RemoteSniper/SniperMuzzleRemote


func _ready() -> void:
	var owner_id := str(name).to_int()
	set_multiplayer_authority(owner_id)
	_target_pos = position
	_target_yaw = rotation.y
	_gun_base_pos = gun_anchor.position
	_remote_gun_base = remote_gun.position
	_remote_sniper_base = sniper_remote.position
	_sniper_remote_yaw0 = sniper_remote.rotation.y
	_remote_knife_base = knife_remote.position
	_knife_base_pos = knife_fp.position
	for i in Game.WEAPONS.size():
		var w: Dictionary = Game.WEAPONS[i]
		ammo_mag[i] = int(w.get("magazine", -1))
		ammo_reserve[i] = int(w.get("reserve", 0))
	_setup_sniper_models()
	_setup_arms()
	_setup_body()
	_sync_weapon_views()
	if is_multiplayer_authority():
		camera.current = true
		remote_body.visible = false  # голова «изнутри» не видна
		_set_body_visible(true)      # BUILD-23: свои торс и ноги видны в FP
		# BUILD-26: свои грудь и шея скрыты — они висят прямо под камерой и
		# перекрывали бы обзор при взгляде вниз. Свои ноги и таз видны,
		# сопернику тело показано целиком (с грудью и шеей).
		if _chest_mesh != null:
			_chest_mesh.visible = false
		if _neck_mesh != null:
			_neck_mesh.visible = false
		remote_gun.visible = false
		knife_remote.visible = false
		sniper_remote.visible = false
		if not Game.is_headless():
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
		Game.weapon_changed.emit(_hud_weapon_label())
	else:
		camera.current = false
		remote_body.visible = true
		# Оружие от первого лица видно только самому владельцу — иначе у
		# соперника отображались бы два ствола одновременно.
		gun_anchor.visible = false
		_fp_arms_root.visible = false


func _setup_sniper_models() -> void:
	# Подставляем вашу 3Д-модель снайперки в оба слота (от 1-го лица и
	# «чужую»). Если файла нет — рисуем заглушку, чтобы игра работала.
	var sniper_scene: PackedScene = null
	if ResourceLoader.exists(SNIPER_SCENE_PATH):
		sniper_scene = load(SNIPER_SCENE_PATH)
	elif OS.is_debug_build():
		print("[WEAPON] модель %s не найдена — снайперка показана заглушкой" % SNIPER_SCENE_PATH)
	for wrapper in [sniper_fp, sniper_remote]:
		if sniper_scene != null:
			var model: Node3D = sniper_scene.instantiate()
			wrapper.add_child(model)
		else:
			var stub := MeshInstance3D.new()
			var box := BoxMesh.new()
			box.size = Vector3(0.06, 0.1, 1.4)
			stub.mesh = box
			stub.position = Vector3(0.0, 0.05, 1.2)
			wrapper.add_child(stub)


func _select_weapon(idx: int) -> void:
	# Слоты: 1 -> 0 (нож), 2 -> 1 (пистолет), 3 -> 2 (снайперка).
	if idx == current_weapon or dead or not Game.WEAPONS.has(idx):
		return
	current_weapon = idx
	# Смена оружия прерывает перезарядку, замах ножа и прицеливание.
	reload_end_ms = 0
	_knife_phase = 0
	_knife_t = 0.0
	_ads = false
	_sync_weapon_views()
	# Сообщаем серверу и сопернику, какое оружие у нас в руках.
	apply_weapon.rpc(idx)
	if OS.is_debug_build():
		print("[WEAPON] игрок %s взял %s" % [name, Game.weapon_label(idx)])
	if is_multiplayer_authority():
		Game.weapon_changed.emit(_hud_weapon_label())


@rpc("any_peer", "call_remote", "reliable")
func apply_weapon(idx: int) -> void:
	if multiplayer.get_remote_sender_id() != str(name).to_int():
		return  # сменить оружие можно только себе
	if not Game.WEAPONS.has(idx):
		return
	current_weapon = idx
	reload_end_ms = 0
	_knife_phase = 0
	_knife_t = 0.0
	_ads = false
	# Смена оружия прерывает все «чужие» анимации на нашей копии соперника.
	_remote_ads = false
	_remote_reload_end_ms = 0
	_remote_knife_phase = 0
	_remote_knife_t = 0.0
	_sync_weapon_views()


func _sync_weapon_views() -> void:
	# BUILD-30: в турели handheld-оружие спрятано (и у владельца в FP,
	# и у соперника на его теле).
	var seated := mounted_idx >= 0
	gun_anchor.visible = not seated
	if not seated:
		# Вид от первого лица: показываем только текущий слот.
		knife_fp.visible = current_weapon == 0
		gun_mesh.visible = current_weapon == 1
		sniper_fp.visible = current_weapon == 2
	# «Чужое» оружие — только если игрок жив (смерть прячет ниже в _process).
	if not dead and not is_multiplayer_authority():
		knife_remote.visible = current_weapon == 0 and not seated
		remote_gun.visible = current_weapon == 1 and not seated
		sniper_remote.visible = current_weapon == 2 and not seated


# ---------------------------------------------------------------- патроны и перезарядка

func _hud_weapon_label() -> String:
	var base := Game.weapon_label(current_weapon)
	var w: Dictionary = Game.WEAPONS[current_weapon]
	if int(w.get("magazine", -1)) < 0:
		return base  # у ножа патронов нет
	if reload_end_ms > Time.get_ticks_msec():
		return base + " — перезарядка…"
	return base + " — %d/%d" % [int(ammo_mag[current_weapon]), int(ammo_reserve[current_weapon])]


func _start_reload() -> void:
	if dead or reload_end_ms > 0 or _knife_phase != 0:
		return
	var w: Dictionary = Game.WEAPONS[current_weapon]
	if int(w.get("magazine", -1)) < 0:
		return  # нож не перезаряжается
	if int(ammo_mag[current_weapon]) >= int(w["magazine"]):
		return  # магазин полон
	if int(ammo_reserve[current_weapon]) <= 0:
		return  # нет запаса
	reload_end_ms = Time.get_ticks_msec() + int(w["reload_ms"])
	if not multiplayer.is_server():
		request_reload.rpc_id(1, current_weapon)
	if is_multiplayer_authority():
		Game.weapon_changed.emit(_hud_weapon_label())


@rpc("any_peer", "call_remote", "reliable")
func request_reload(weapon_idx: int) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender != str(name).to_int() or weapon_idx != current_weapon:
		return
	var w: Dictionary = Game.WEAPONS[weapon_idx]
	if int(w.get("magazine", -1)) < 0 or reload_end_ms > 0:
		return
	if int(ammo_mag[weapon_idx]) >= int(w["magazine"]) or int(ammo_reserve[weapon_idx]) <= 0:
		return
	reload_end_ms = Time.get_ticks_msec() + int(w["reload_ms"])


func _tick_reload() -> void:
	if reload_end_ms == 0:
		return
	if Time.get_ticks_msec() < reload_end_ms:
		return
	_finish_reload()


func _finish_reload() -> void:
	reload_end_ms = 0
	var w: Dictionary = Game.WEAPONS[current_weapon]
	if int(w.get("magazine", -1)) < 0:
		return
	var need := int(w["magazine"]) - int(ammo_mag[current_weapon])
	var take := mini(need, int(ammo_reserve[current_weapon]))
	ammo_mag[current_weapon] = int(ammo_mag[current_weapon]) + take
	ammo_reserve[current_weapon] = int(ammo_reserve[current_weapon]) - take
	if is_multiplayer_authority():
		Game.weapon_changed.emit(_hud_weapon_label())


# ---------------------------------------------------------------- турель (BUILD-30)

func _arena() -> Node:
	return get_tree().current_scene


func _arena_turret(idx: int) -> Node3D:
	var arena := _arena()
	if arena == null or idx < 0:
		return null
	var arr: Array = arena.turrets
	if idx >= arr.size():
		return null
	return arr[idx]


func _my_turret() -> Node3D:
	return _arena_turret(mounted_idx)


## Точка входа для клавиши F: сесть в ближайшую свободную / выйти из своей.
func _toggle_turret() -> void:
	if dead or not is_multiplayer_authority():
		return
	var arena := _arena()
	if arena == null:
		return
#	if mounted_idx >= 0:
#		if multiplayer.is_server():
#			arena.try_dismount_player(multiplayer.get_unique_id())
#		else:
#			arena.rpc_id(0, "request_dismount")
#		return
	var best := -1
	var best_d := 9999.0
	var arr: Array = arena.turrets
	for i in arr.size():
		var t: Node3D = arr[i]
		if t.is_occupied():
			continue
		var d: float = t.position.distance_to(global_position)
		if d < best_d:
			best_d = d
			best = i
	if best >= 0 and best_d <= float(arena.MOUNT_RANGE):
		if multiplayer.is_server():
			arena.try_mount_player(multiplayer.get_unique_id(), best)
		else:
			arena.rpc_id(0, "request_mount", best)


## Установка на сиденье (вызывается всем нодам: сервер — напрямую,
## клиенты — через _event_mount).
func _apply_mount_event(turret_idx: int) -> void:
	if turret_idx < 0:
		return
	var t := _arena_turret(turret_idx)
	if t == null:
		return
	mounted_idx = turret_idx
	turret_reload_now = false
	position = t.seat_world()
	rotation.y = t.rotation.y
	head.rotation.x = 0.0
	velocity = Vector3.ZERO
	_body_shape.disabled = true  # двигаемся мышами, а не ногами
	gun_anchor.visible = false
	if is_multiplayer_authority():
		Game.weapon_changed.emit(_turret_label())


## Сход с сиденья (сервер считает позицию выхода, событие уходит всем).
func _apply_dismount_event(pos: Vector3, yaw: float) -> void:
	mounted_idx = -1
	turret_reload_now = false
	position = pos
	rotation.y = yaw
	velocity = Vector3.ZERO
	head.rotation.x = 0.0
	_body_shape.disabled = false
	_sync_weapon_views()
	reset_net_targets()
	if is_multiplayer_authority():
		Game.weapon_changed.emit(_hud_weapon_label())


## Принудительный сброс посадки (смерть/респаун/дисконнект).
func _apply_unmount_cleanup() -> void:
	mounted_idx = -1
	turret_reload_now = false
	_body_shape.disabled = false
	_sync_weapon_views()


## Выстрел из турели (авторитет — только владелец). Локальная предсказательная
## копия: магазин/ствол на СВОЕЙ ноде турели; урон и результат — сервер.
func _turret_fire() -> void:
	if dead or mounted_idx < 0:
		return
	var t := _my_turret()
	if t == null:
		return
	var w: Dictionary = Game.TURRET
	var now := Time.get_ticks_msec()
	if now < next_allowed_shot_ms:
		return
	if now < t.reload_end_ms:
		return
	if t.mag <= 0:
		_turret_start_reload()  # пустой магазин — автоперезарядка
		return
	t.mag -= 1
	t.barrel = int(t.barrel) ^ 1  # чередование: левый, правый, левый…
	var barrel: int = int(t.barrel)
	next_allowed_shot_ms = now + int(w["cooldown_ms"])
	var muzzle: Vector3 = t.world_muzzle(barrel)
	# Локальный зажим направления — тот же, что на сервере, чтобы трассер
	# летел вдоль серверного луча (рыск ≤ 0.25, тангаж ≤ 0.15).
	var dir: Vector3 = _aim_dir()
	var t_yaw: float = float(t.aim_yaw())
	var dyaw: float = atan2(-dir.x, -dir.z)
	var dev: float = wrapf(dyaw - t_yaw, -PI, PI)
	var ny: float = t_yaw + clampf(dev, -0.25, 0.25)
	var pitch: float = clampf(asin(clampf(dir.y, -1.0, 1.0)), -0.15, 0.15)
	dir = Vector3(-sin(ny) * cos(pitch), sin(pitch), -cos(ny) * cos(pitch)).normalized()
	var end := _predict_hit_from(muzzle, dir, float(w["range"]))
	_spawn_tracer(muzzle, end)
	t.fire_kick(barrel)
	head.rotation.x -= 0.008  # лёгкая отдача камеры
	# Остальные ноды: трассер + отдача их стволов (стрелок свой RPC не получает).
	var arena := _arena()
	if arena != null:
		arena.rpc_id(0, "_turret_fx", mounted_idx, barrel, end)
	# Урон считает СЕРВЕР (свой луч из дула, серверный ствол, зажим угла).
	# Хост — напрямую, клиент — через обычный RPC выстрела (weapon_idx = 3).
	if multiplayer.is_server():
		if arena.has_method("handle_shoot_request"):
			arena.handle_shoot_request(multiplayer.get_unique_id(), muzzle, dir, Game.TURRET_IDX, 0)
	else:
		request_shoot.rpc_id(1, muzzle, dir, Game.TURRET_IDX, 0)
	Game.weapon_changed.emit(_turret_label())


## Перезарядка турели (R). Магазин 30, запас бесконечный.
func _turret_start_reload() -> void:
	if dead or mounted_idx < 0:
		return
	var t := _my_turret()
	if t == null:
		return
	var w: Dictionary = Game.TURRET
	if t.reload_end_ms > Time.get_ticks_msec() or t.mag >= int(w["magazine"]):
		return
	t.reload_end_ms = Time.get_ticks_msec() + int(w["reload_ms"])
	if not multiplayer.is_server():
		var arena := _arena()
		if arena != null:
			arena.rpc_id(0, "request_turret_reload")
	Game.weapon_changed.emit(_turret_label())


## Завершение перезарядки на СВОЕЙ копии турели (сервер ведёт свой таймер
## авторитетно в arena._process; хост — одно и то же).
func _turret_tick_reload() -> void:
	if mounted_idx < 0:
		return
	var t := _my_turret()
	if t == null:
		return
	if t.reload_end_ms > 0 and Time.get_ticks_msec() >= t.reload_end_ms:
		t.reload_end_ms = 0
		t.mag = int(Game.TURRET["magazine"])
		Game.weapon_changed.emit(_turret_label())


## Подпись боезапаса для HUD: «Турель — 23/30» / «Турель — перезарядка…».
func _turret_label() -> String:
	var t := _my_turret()
	var base := str(Game.TURRET["name"])
	if t == null:
		return base
	if t.reload_end_ms > Time.get_ticks_msec():
		return base + " — перезарядка…"
	return base + " — %d/%d" % [int(t.mag), int(Game.TURRET["magazine"])]


func _notification(what: int) -> void:
	# На одном ПК игроки переключаются между окнами по Alt+Tab.
	# Godot СБРАСЫВАЕТ захват мыши при потере фокуса окном — без этого
	# возврата игрок после возврата в окно не может целиться.
	if what == NOTIFICATION_APPLICATION_FOCUS_IN:
		if is_multiplayer_authority() and not dead \
				and multiplayer.multiplayer_peer != null \
				and not Game.is_headless():
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _unhandled_input(event: InputEvent) -> void:
	if multiplayer.multiplayer_peer == null:
		return
	if not is_multiplayer_authority() or dead:
		if OS.is_debug_build() and event.is_action_pressed("fire"):
			print("[SHOT] клик заблокирован (нода=%s, авторитет=%d, мой_id=%d, мёртв=%s)" % [name, get_multiplayer_authority(), multiplayer.get_unique_id(), str(dead)])
		return
	if event is InputEventMouseMotion:
		if Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
			return
		# В прицеле снайперки мышь «тяжелее» — точнее наводка.
		var sens := MOUSE_SENS * (0.45 if _ads else 1.0)
		rotate_y(-event.relative.x * sens)
		head.rotate_x(-event.relative.y * sens)
		head.rotation.x = clampf(head.rotation.x, -1.45, 1.45)
	elif event.is_action_pressed("fire"):
		_fire()
	elif event.is_action_pressed("interact"):
		# BUILD-30: F — сесть в ближайшую свободную турель / выйти из своей.
		_toggle_turret()


func _physics_process(delta: float) -> void:
	if multiplayer.multiplayer_peer == null:
		return
	_tick_reload()  # перезарядка: у сервера тикает для всех, у клиента — для себя
	if not is_multiplayer_authority():
		return
	if dead:
		velocity = Vector3.ZERO
		move_and_slide()
		return
	# BUILD-30: сидя в турели — движения нет: мышь вращает купол (теле),
	# ЛКМ — огонь (ствола чередуются), R — перезарядка, F — выход.
	if mounted_idx >= 0:
		velocity = Vector3.ZERO
		move_and_slide()
		if Input.is_action_just_pressed("interact"):
			_toggle_turret()
		elif Input.is_action_just_pressed("reload"):
			_turret_start_reload()
		if Input.is_action_pressed("fire"):
			_turret_fire()
		# Своя копия турели: завершение перезарядки + флаг для визуала ствольной.
		_turret_tick_reload()
		var t := _my_turret()
		turret_reload_now = t != null and t.reload_end_ms > Time.get_ticks_msec()
		# Сидячая поза: ПРАВОК — тут же (вход в ветку обходит обычный путь,
		# который вызывал бы _update_body_pose). Без этого тело оставалось бы
		# «по стойке смирно» в базе турели, а камера не опускалась в кресло.
		_update_body_pose(delta, false, Vector3.ZERO, false, true, 0.0, 0.0, _mounted_w)
		# Свои руки: кисти на хватах ствольной группы (После позы, чтобы
		# плечи уже были на сидящей высоте).
		_update_fp_arms()
		_net_timer += delta
		if _net_timer >= NET_INTERVAL and multiplayer.multiplayer_peer != null:
			_net_timer = 0.0
			send_state.rpc(global_position, rotation.y, head.rotation.x, true, false, false, false, _fp_tilt, _fp_fold, false, _fp_breath, mounted_idx, turret_reload_now)
		return
	# Прицеливание снайперки: ПКМ удерживается.
	_ads = current_weapon == 2 and Input.is_action_pressed("fire_alt")
	# Огонь и спец-действия по слотам.
	# Нож: ЛКМ — быстрый удар, ПКМ — сильный удар с замахом.
	# Снайперка: ПКМ занят прицеливанием. Пистолет: только ЛКМ.
	if current_weapon == 0:
		if Input.is_action_pressed("fire"):
			_fire()
		if Input.is_action_just_pressed("fire_alt"):
			_start_heavy_strike()
	else:
		if Input.is_action_pressed("fire"):
			_fire()
	if Input.is_action_just_pressed("reload"):
		_start_reload()
	# Переключение слотов оружия: 1 — нож, 2 — пистолет, 3 — снайперка.
	if Input.is_action_just_pressed("weapon_1"):
		_select_weapon(0)
	elif Input.is_action_just_pressed("weapon_2"):
		_select_weapon(1)
	elif Input.is_action_just_pressed("weapon_3"):
		_select_weapon(2)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	# BUILD-27: присед на Ctrl — медленнее и ниже.
	var want_crouch := dbg_crouch or Input.is_key_pressed(KEY_CTRL)
	var speed := SPEED * (0.45 if _ads else 1.0) * (CROUCH_SPEED_MULT if want_crouch else 1.0)
	var wish := (transform.basis * Vector3(input.x, 0.0, input.y)) * speed
	velocity.x = wish.x
	velocity.z = wish.z
	move_and_slide()
	_update_fp_gun(delta)
	# BUILD-23/27: своё тело в FP — торс доворачивается, ноги шагают,
	# присед и прыжок анимируются и уходят в сеть.
	_update_body_pose(delta, is_on_floor() and velocity.length() > 1.0, Vector3(velocity.x, 0.0, velocity.z), want_crouch, is_on_floor(), 0.0, _bob_weight, _mounted_w)

	_net_timer += delta
	if _net_timer >= NET_INTERVAL and multiplayer.multiplayer_peer != null:
		_net_timer = 0.0
		# В пакет состояния добавлены флаги прицела, перезарядки и СМЕЩЕНИЕ
		# оружия у стен (наклон/складывание) — соперник видит наши анимации
		# без отдельных событий (20 Гц, ненадёжный канал).
		# BUILD-30: + индекс занятой турели и её перезарядка (здесь пешком:
		# mounted_idx = -1, турели не заряжаем).
		send_state.rpc(global_position, rotation.y, head.rotation.x, is_on_floor(), velocity.length() > 1.0, _ads, reload_end_ms > Time.get_ticks_msec(), _fp_tilt, _fp_fold, want_crouch, _fp_breath, mounted_idx, false)


func _process(delta: float) -> void:
	# Визуал «чужого» игрока: интерполяция + процедурная анимация.
	if multiplayer.multiplayer_peer == null:
		return
	# BUILD-30: вес сидячей позы (плавная посадка/выход) — на всех нодах.
	_mounted_w = move_toward(_mounted_w, 1.0 if mounted_idx >= 0 else 0.0, delta * 6.0)
	if _was_dead != dead:
		_was_dead = dead
		if is_multiplayer_authority():
			gun_anchor.visible = not dead
			_fp_arms_root.visible = not dead
			_set_body_visible(not dead)
			if not dead:
				_fp_recoil = 0.0
				gun_anchor.position = _gun_base_pos
				gun_anchor.rotation = Vector3.ZERO
				_knife_phase = 0
				_knife_t = 0.0
				_ads = false
				_fp_tilt = 0.0
				_fp_fold = 0.0
				_fp_folded = false
				camera.fov = 80.0
		elif dead:
			# Смерть соперника: сбрасываем его сетевые анимации.
			_remote_knife_phase = 0
			_remote_knife_t = 0.0
			_remote_reload_end_ms = 0
			_remote_ads = false
			_remote_tilt = 0.0
			_remote_fold = 0.0
			_remote_folded = false
			_remote_tilt_target = 0.0
			_remote_fold_target = 0.0
	if is_multiplayer_authority():
		return
	if dead:
		remote_body.visible = false
		knife_remote.visible = false
		remote_gun.visible = false
		sniper_remote.visible = false
		_set_remote_arms_visible(false)
		_set_body_visible(false)
		return
	remote_body.visible = true
	_set_body_visible(true)
	_sync_weapon_views()
	var k := clampf(delta * 12.0, 0.0, 1.0)
	global_position = global_position.lerp(_target_pos, k)
	rotation.y = lerp_angle(rotation.y, _target_yaw, k)
	head.rotation.x = lerpf(head.rotation.x, _target_pitch, k)
	# Покачивание тела при ходьбе: фаза движется только пока игрок идёт
	# (как у вида от первого лица), а не от настенного времени.
	var bob_y := 0.0
	if _remote_moving:
		_remote_bob_t += delta * BOB_SPEED
		bob_y = absf(sin(_remote_bob_t)) * REMOTE_BOB_AMP
	# BUILD-27: поза соперника — присед/прыжок из пакета, покачивание на торсе.
	_update_body_pose(delta, _remote_moving, Vector3(_target_pos.x - global_position.x, 0.0, _target_pos.z - global_position.z), _remote_crouch, _remote_grounded, bob_y, _remote_bob_w, _mounted_w)
	# Отдача «чужого» оружия — те же параметры, что у оружия от первого лица.
	var r := 0.0
	if _recoil_time > 0.0:
		_recoil_time = maxf(_recoil_time - delta, 0.0)
		r = _recoil_time / RECOIL_TIME
	# BUILD-20: те же «сочные» добавки, что от первого лица: сглаженная отдача,
	# покачивание в такт шагам (фаза _remote_bob_t — как у владельца).
	_remote_bob_w = move_toward(_remote_bob_w, 1.0 if _remote_moving else 0.0, delta * 6.0)
	var rr := r * r * (3.0 - 2.0 * r)
	var sway_x := sin(_remote_bob_t) * WALK_SWAY_PITCH * _remote_bob_w
	var sway_z := sin(_remote_bob_t * 0.5) * WALK_SWAY_ROLL * _remote_bob_w
	# Перезарядка соперника: опускаем оружие по кривой, как у первого лица.
	var rdip := 0.0
	if _remote_reload_end_ms > Time.get_ticks_msec():
		var rp := clampf(1.0 - float(_remote_reload_end_ms - Time.get_ticks_msec()) / float(_remote_reload_ms), 0.0, 1.0)
		rdip = sin(rp * PI)
	# Поза прицеливания соперника (снайперка поднимается к плечу).
	_remote_ads_w = move_toward(_remote_ads_w, 1.0 if _remote_ads else 0.0, delta * 9.0)
	# Пистолет: покачивание + отдача + наклон при перезарядке.
	# BUILD-23: и у соперника оружие не проваливается в тело при взгляде вниз.
	var gate := _down_aim_amount(head.rotation.x)
	var hb_head := head.global_transform.basis
	var yf := -global_transform.basis.z
	remote_gun.position = _remote_gun_base + Vector3(-0.05 * rdip, bob_y - 0.12 * rdip, 0.0) + Vector3(0.0, RECOIL_PUSH.y, RECOIL_PUSH.z) * rr
	remote_gun.position += _body_clear_push(hb_head, global_transform.basis, remote_gun.position, yf, gate)
	# Снайперка: покачивание, откат при выстреле, подъём в прицеле,
	# наклон при перезарядке (рыск модели не трогаем — он задан в сцене).
	var sniper_base := _remote_sniper_base.lerp(REMOTE_SNIPER_ADS_BASE, _remote_ads_w)
	sniper_remote.position = sniper_base + Vector3(-0.05 * rdip, bob_y - 0.1 * rdip, 0.0) + Vector3(0.0, RECOIL_PUSH.y, RECOIL_PUSH.z * 2.0) * rr
	sniper_remote.position += _body_clear_push(hb_head, global_transform.basis, sniper_remote.position, yf, gate)
	# Нож соперника: та же машина фаз, что у вида от первого лица —
	# замах и удар видны одновременно с действиями владельца.
	if _remote_knife_phase != 0:
		_remote_knife_t += delta
		var wk: Dictionary = Game.WEAPONS[0]
		match _remote_knife_phase:
			1:
				if _remote_knife_t >= float(wk["windup_ms"]) / 1000.0:
					_remote_knife_phase = 2
					_remote_knife_t = 0.0
			2:
				if _remote_knife_t >= KNIFE_HEAVY_SWING:
					_remote_knife_phase = 0
					_remote_knife_t = 0.0
			3:
				if _remote_knife_t >= KNIFE_QUICK_TIME:
					_remote_knife_phase = 0
					_remote_knife_t = 0.0
	var kpose := _knife_pose(_remote_knife_phase, _remote_knife_t)
	knife_remote.position = _remote_knife_base + Vector3(0.0, bob_y, 0.0) + kpose[1] + Vector3(0.0, RECOIL_PUSH.y, RECOIL_PUSH.z * 0.6) * rr
	knife_remote.position += _body_clear_push(hb_head, global_transform.basis, knife_remote.position, yf, gate)
	# BUILD-28: idle-дыхание соперника — в той же фазе, что у владельца.
	remote_gun.position.y += _remote_breath
	sniper_remote.position.y += _remote_breath
	knife_remote.position.y += _remote_breath
	# BUILD-17: реакция «чужого» оружия на стены берётся ИЗ ПАКЕТА ВЛАДЕЛЬЦА
	# (_remote_tilt_target/_remote_fold_target), а не пересчитывается локально:
	# геометрия «чужих» нод отличается от вида от первого лица, и локальный
	# пересчёт давал другую реакцию (владелец складывает оружие ВБОК, а соперник
	# видел ПОДЪЁМ ВВЕРХ). Теперь поза оружия синхронизирована полностью.
	_remote_folded = _remote_fold_target > 0.5
	_remote_tilt = move_toward(_remote_tilt, _remote_tilt_target, delta * 12.0)
	_remote_fold = move_toward(_remote_fold, _remote_fold_target, delta * 8.0)
	var rf := _remote_fold
	# Рыск складывания — как у владельца: зависит от длины ствола оружия
	# (те же значения, что даёт _fp_tip_offset() для вида от первого лица).
	var r_reach := 0.56 if current_weapon == 0 else (0.84 if current_weapon == 2 else 0.35)
	var r_yaw := _fold_yaw(r_reach)
	match current_weapon:
		0:
			knife_remote.position = knife_remote.position.lerp(WEAPON_FOLD_POS, rf)
			knife_remote.rotation = kpose[0] + Vector3(RECOIL_ROT_X * 0.6 * rr + _remote_tilt * (1.0 - rf) + WEAPON_FOLD_PITCH * rf + sway_x, r_yaw * rf, WEAPON_FOLD_ROLL * rf + sway_z + RECOIL_ROT_Z * 0.6 * rr)
		2:
			sniper_remote.position = sniper_remote.position.lerp(WEAPON_FOLD_POS, rf)
			# Знак минуса: модель развёрнута на 180°, положительный угол ЕЁ опускает.
			# Рыск считаем ОТ базового разворота модели (_sniper_remote_yaw0),
			# иначе складывание сбросит разворот и снайперка перевернётся.
			sniper_remote.rotation.x = (0.5 * rdip - _remote_tilt) * (1.0 - rf) - WEAPON_FOLD_PITCH * rf + sway_x
			sniper_remote.rotation.y = _sniper_remote_yaw0 + r_yaw * rf - 0.35 * rdip
			sniper_remote.rotation.z = -WEAPON_FOLD_ROLL * rf - sway_z - RECOIL_ROT_Z * rr
		_:
			remote_gun.position = remote_gun.position.lerp(WEAPON_FOLD_POS, rf)
			remote_gun.rotation.x = (RECOIL_ROT_X * rr + 0.55 * rdip + _remote_tilt) * (1.0 - rf) + WEAPON_FOLD_PITCH * rf + sway_x
			remote_gun.rotation.y = r_yaw * rf - 0.35 * rdip
			remote_gun.rotation.z = (0.3 * rdip) * (1.0 - rf) + WEAPON_FOLD_ROLL * rf + sway_z + RECOIL_ROT_Z * rr
	# BUILD-15: кисти соперника — после всех преобразований оружия, чтобы они
	# точно лежали на рукоятке/цевье с учётом отдачи, наклона и складывания.
	_update_remote_arms()


# ---------------------------------------------------------------- сеть: состояние

@rpc("any_peer", "call_remote", "unreliable_ordered")
func send_state(pos: Vector3, yaw: float, pitch: float, grounded: bool, moving: bool, ads: bool, reloading: bool, tilt: float, fold: float, crouch: bool, breath: float, mounted: int, turret_reload: bool) -> void:
	var sender := multiplayer.get_remote_sender_id()
	if sender != str(name).to_int():
		return  # подмена: чужое состояние не принимаем
	_target_pos = pos
	_target_yaw = yaw
	_target_pitch = pitch
	_remote_moving = moving
	_remote_ads = ads
	# BUILD-27: присед и «в воздухе» — соперник проигрывает те же позы.
	_remote_grounded = grounded
	_remote_crouch = crouch
	# BUILD-28: idle-дыхание владельца — соперник дышит в той же фазе.
	_remote_breath = breath
	# BUILD-30: посадка в турель и её перезарядка — соперник ставит сидячую
	# позу, прячет оружие и опускает стволы турели.
	mounted_idx = mounted
	turret_reload_now = turret_reload
	# BUILD-17: смещение оружия у стен — из пакета владельца (синхронно).
	_remote_tilt_target = tilt
	_remote_fold_target = fold
	# Перезарядка: ловим старт по флагу и ведём локальный таймер анимации.
	var now := Time.get_ticks_msec()
	if reloading and _remote_reload_end_ms <= now:
		var w: Dictionary = Game.WEAPONS[current_weapon]
		if int(w.get("magazine", -1)) >= 0:
			_remote_reload_ms = maxi(1, int(w["reload_ms"]))
			_remote_reload_end_ms = now + _remote_reload_ms
	elif not reloading and _remote_reload_end_ms > now:
		_remote_reload_end_ms = 0  # прервана сменой оружия


func reset_net_targets() -> void:
	_target_pos = position
	_target_yaw = rotation.y
	_target_pitch = head.rotation.x
	_legs_yaw = rotation.y
	_torso_twist = 0.0


# ---------------------------------------------------------------- стрельба

# BUILD-21: сила выталкивания при взгляде вниз (0..1, смусстеп).
func _down_aim_amount(pitch: float) -> float:
	if pitch > -DOWN_AIM_START:
		return 0.0
	var d := clampf((-pitch - DOWN_AIM_START) / (DOWN_AIM_FULL - DOWN_AIM_START), 0.0, 1.0)
	return d * d * (3.0 - 2.0 * d)


# BUILD-23: точный вынос якоря оружия из тела. Считаем, где якорь оказывается
# по горизонтали (в системе рысканья), и если он подошёл к оси тела ближе
# BODY_CLEAR_R — довыносим СТРОГО горизонтально вперёд ровно настолько, чтобы
# встать на радиус BODY_CLEAR_R. Работает на любом тангаже, включая «ровно
# под тело» (+ чуть вниз для естественности). Возврат в системе головы.
func _body_clear_push(hb: Basis, yb: Basis, lo: Vector3, yaw_fwd: Vector3, gate: float) -> Vector3:
	if gate <= 0.001:
		return Vector3.ZERO
	# горизонтальное смещение якоря в системе РЫСКА тела (x — вбок, z — вперёд)
	var pf := yb.inverse() * (hb * lo)
	var rmin := sqrt(maxf(BODY_CLEAR_R * BODY_CLEAR_R - pf.x * pf.x, 0.0))
	var push := 0.0
	if pf.z > -rmin:
		push = pf.z + rmin
	var world_off := yaw_fwd * (push * gate) + Vector3(0.0, -DOWN_AIM_DROP * gate, 0.0)
	return hb.inverse() * world_off


func _update_fp_gun(delta: float) -> void:
	# BUILD-30: в турели handheld-оружия нет — анимация не запускается.
	if mounted_idx >= 0:
		return
	# Процедурная анимация оружия от первого лица:
	# лёгкое покачивание при ходьбе + отдача при выстреле.
	var moving := is_on_floor() and velocity.length() > 1.0
	_bob_weight = move_toward(_bob_weight, 1.0 if moving else 0.0, delta * 6.0)
	if moving:
		_bob_t += delta * BOB_SPEED
	var bob := Vector3(
		sin(_bob_t) * FP_BOB_AMP.x,
		absf(cos(_bob_t)) * FP_BOB_AMP.y,
		0.0
	) * _bob_weight
	_idle_t += delta
	# BUILD-28: idle-дыхание считается один раз и шлётся сопернику —
	# idle-анимация синхронна у обоих игроков.
	_fp_breath = sin(_idle_t * 2.1) * IDLE_BREATH_AMP * (1.0 - _bob_weight)
	_fp_recoil = maxf(_fp_recoil - delta / RECOIL_TIME, 0.0)
	var r := _fp_recoil
	# BUILD-20: отдача со сглаженной кривой — резкий кик, мягкий возврат.
	var rr := r * r * (3.0 - 2.0 * r)
	gun_anchor.position = _gun_base_pos + bob + Vector3(0.0, RECOIL_PUSH.y, RECOIL_PUSH.z) * rr \
		+ Vector3(0.0, _fp_breath, 0.0)
	# BUILD-20: покачивание в такт шагам + отдача с подъёмом и уводом вправо.
	gun_anchor.rotation.x = RECOIL_ROT_X * rr + sin(_bob_t) * WALK_SWAY_PITCH * _bob_weight
	gun_anchor.rotation.z = RECOIL_ROT_Z * rr + sin(_bob_t * 0.5) * WALK_SWAY_ROLL * _bob_weight
	# Анимация перезарядки: оружие плавно опускается и наклоняется,
	# затем возвращается (кривая sin — вниз-вверх за время перезарядки).
	var now_ms := Time.get_ticks_msec()
	var reload_dip := 0.0
	if reload_end_ms > now_ms:
		var wr: Dictionary = Game.WEAPONS[current_weapon]
		var dur := maxf(1.0, float(wr["reload_ms"]))
		var rp := clampf(1.0 - float(reload_end_ms - now_ms) / dur, 0.0, 1.0)
		var dip := sin(rp * PI)
		reload_dip = dip
		gun_anchor.rotation.x += 0.55 * dip
		gun_anchor.rotation.z += 0.3 * dip
		gun_anchor.position.y -= 0.14 * dip
		# BUILD-20: оружие уходит чуть вправо и разворачивается, как при
		# передёргивании магазина, — перезарядка читается сочнее.
		gun_anchor.position.x -= 0.05 * dip
	# Прицеливание снайперки: плавный зум камеры + оружие встаёт по центру.
	_ads_weight = move_toward(_ads_weight, 1.0 if _ads else 0.0, delta * 9.0)
	if _ads_weight > 0.0 and current_weapon == 2:
		gun_anchor.position.x = lerpf(gun_anchor.position.x, 0.0, _ads_weight)
		gun_anchor.position.y = lerpf(gun_anchor.position.y, -0.13, _ads_weight)
		gun_anchor.position.z = lerpf(gun_anchor.position.z, -0.36, _ads_weight)
	var target_fov := 80.0
	if _ads:
		target_fov = float(Game.WEAPONS[2].get("ads_fov", 22.0))
	camera.fov = lerpf(camera.fov, target_fov, clampf(delta * 10.0, 0.0, 1.0))
	# BUILD-23: при взгляде вниз (вплоть до «ровно под тело») оружие
	# выносится ПЕРЕД телом ровно на безопасный радиус (до настенных
	# проверок — стены главнее).
	gun_anchor.position += _body_clear_push(head.global_transform.basis, global_transform.basis, gun_anchor.position, -global_transform.basis.z, _down_aim_amount(head.rotation.x))
	# Оружие не проходит сквозь стены (считается после всех поз). Реакции:
	# ствол ВВЕРХ, ствол ВНИЗ (когда смотрим вверх) или СКЛАДЫВАНИЕ «в обе
	# руки» к груди, когда места совсем не хватает.
	var corr := _push_weapon_out_of_walls(head.global_transform, gun_anchor.position, _fp_tip_offset(), _fp_probe_radius(), head.rotation.x > WEAPON_DOWN_PITCH, _fp_folded)
	gun_anchor.position = corr[0]
	_fp_folded = corr[2] > 0.5
	_fp_tilt = move_toward(_fp_tilt, corr[1], delta * 12.0)
	_fp_fold = move_toward(_fp_fold, corr[2], delta * 8.0)
	var f := _fp_fold
	gun_anchor.position = gun_anchor.position.lerp(WEAPON_FOLD_POS, f)
	gun_anchor.rotation.x += _fp_tilt * (1.0 - f) + WEAPON_FOLD_PITCH * f
	gun_anchor.rotation.y = _fold_yaw(_fp_tip_offset().length()) * f - 0.35 * reload_dip
	gun_anchor.rotation.z += WEAPON_FOLD_ROLL * f
	if current_weapon == 0:
		_animate_knife(delta)  # до рук: кисть должна следить за клинком в том же кадре
	_update_fp_arms()


func _animate_knife(delta: float) -> void:
	# Анимации ножа от первого лица: быстрый косой удар (ЛКМ) и сильный
	# удар с замахом (ПКМ). Фаза 1 — замах, по его завершении наносится
	# урон (_deliver_heavy_strike) и начинается фаза 2 — рубящий мах.
	# Позы считает общая функция _knife_pose — те же цифры используются
	# для «чужого» ножа, поэтому анимации синхронны у обоих игроков.
	var w: Dictionary = Game.WEAPONS[0]
	match _knife_phase:
		1:  # замах
			_knife_t += delta
			if _knife_t >= float(w["windup_ms"]) / 1000.0:
				_deliver_heavy_strike()
				_knife_phase = 2
				_knife_t = 0.0
		2:  # тяжёлый мах
			_knife_t += delta
			if _knife_t >= KNIFE_HEAVY_SWING:
				_knife_phase = 0
				_knife_t = 0.0
		3:  # быстрый удар
			_knife_t += delta
			if _knife_t >= KNIFE_QUICK_TIME:
				_knife_phase = 0
				_knife_t = 0.0
	var pose := _knife_pose(_knife_phase, _knife_t)
	knife_fp.rotation = pose[0]
	knife_fp.position = _knife_base_pos + pose[1]


# Чистая поза ножа (поворот + смещение) для фазы и времени. Общая для
# вида от первого лица и «чужого» ножа — анимации полностью совпадают.
func _knife_pose(phase: int, t: float) -> Array:
	var rot := Vector3.ZERO
	var off := Vector3.ZERO
	var w: Dictionary = Game.WEAPONS[0]
	# BUILD-20: дуги замахов шире (~+20%) — удары читаются сочнее. Функция
	# общая для первого и «чужого» лица, поэтому синхронность сохранена.
	match phase:
		1:  # замах: нож уходит вверх-вправо, клинок отводится назад
			var p := clampf(t / (float(w["windup_ms"]) / 1000.0), 0.0, 1.0)
			var e := p * p
			rot = Vector3(1.25 * e, 0.0, 0.7 * e)
			off = Vector3(0.12, 0.16, 0.10) * e
		2:  # тяжёлый удар: резкий мах сверху вниз-вперёд, затем возврат
			var p := clampf(t / KNIFE_HEAVY_SWING, 0.0, 1.0)
			if p < 0.55:
				var q := p / 0.55
				var e := q * q
				rot = Vector3(lerpf(1.25, -1.0, e), 0.0, lerpf(0.7, -0.45, e))
				off = Vector3(lerpf(0.12, -0.07, e), lerpf(0.16, -0.18, e), lerpf(0.10, -0.40, e))
			else:
				var q := (p - 0.55) / 0.45
				rot = Vector3(lerpf(-1.0, 0.0, q), 0.0, lerpf(-0.45, 0.0, q))
				off = Vector3(lerpf(-0.07, 0.0, q), lerpf(-0.18, 0.0, q), lerpf(-0.40, 0.0, q))
		3:  # быстрый удар: косой срез справа-сверху влево-вниз
			var p := clampf(t / KNIFE_QUICK_TIME, 0.0, 1.0)
			if p < 0.28:
				var q := p / 0.28
				rot = Vector3(0.35 * q, 0.0, 0.85 * q)
				off = Vector3(0.10, 0.08, 0.02) * q
			elif p < 0.72:
				var q := (p - 0.28) / 0.44
				var e := 1.0 - (1.0 - q) * (1.0 - q)
				rot = Vector3(lerpf(0.35, -0.6, e), 0.0, lerpf(0.85, -1.1, e))
				off = Vector3(lerpf(0.10, -0.15, e), lerpf(0.08, -0.13, e), lerpf(0.02, -0.32, e))
			else:
				var q := (p - 0.72) / 0.28
				rot = Vector3(lerpf(-0.6, 0.0, q), 0.0, lerpf(-1.1, 0.0, q))
				off = Vector3(lerpf(-0.15, 0.0, q), lerpf(-0.13, 0.0, q), lerpf(-0.32, 0.0, q))
	return [rot, off]


# ---------------------------------------------------------------- коллизия оружия со стенами

# Точка «кончика» оружия в локальных координатах GunAnchor (для луча).
# У снайперки учтены смещение и масштаб обёртки модели (0.4, разворот на 180°).
func _fp_tip_offset() -> Vector3:
	match current_weapon:
		0:
			return Vector3(0.0, -0.01, -0.56)  # остриё клинка
		2:
			return Vector3(0.0, -0.036, -0.84)  # дуло снайперки
		_:
			return Vector3(0.0, 0.02, -0.35)   # дуло пистолета


# Половина ВЫСОТЫ модели оружия (м): три луча-щупа идут по оси ствола,
# смещённые вверх/вниз на эту величину — габариты должны быть честными,
# иначе мушка/прицел/нижняя грань дула будут цеплять стену.
func _fp_probe_radius() -> float:
	match current_weapon:
		0:
			return 0.04   # нож (высота ~8 см)
		2:
			return 0.11   # снайперка с прицелом
		_:
			return 0.08   # пистолет (высота 14 см)


# ---------------------------------------------------------------- руки (сочленённые)
# BUILD-18: руки с ПЛЕЧОМ, ЛОКТЁМ, ПРЕДПЛЕЧЬЕМ и КИСТЬЮ — двухзвенная инверсная
# кинематика, как в референсе gdquest-demos/godot-4-FPS-arms. Локоть сгибается,
# кисть лежит на рукоятке. Одна и та же оснастка у вида от первого лица
# и у соперника — руки выглядят одинаково с обеих сторон и повторяют все
# анимации оружия: покачивание, отдачу, удары ножом, перезарядку, прицел,
# подъём/опускание ствола и складывание у стены.
const ARM_SKIN_COLOR := Color(0.80, 0.63, 0.50)
const ARM_SLEEVE_COLOR := Color(0.20, 0.40, 0.78)
const UPPER_ARM_LEN := 0.44
const FOREARM_LEN := 0.42
const UPPER_ARM_THICK := 0.075
const FOREARM_THICK := 0.062
# Плечи от первого лица — за камерой и внизу (руки входят в кадр снизу-сбоку).
# BUILD-22: плечи от первого лица — в системе ТЕЛА (как у соперника), а не
# головы: раньше при взгляде вниз плечи «улетали» вверх-за спину, и руки
# вытягивались балками. Теперь плечи стоят на торсе, а локти сгибаются.
# Заданы В СИСТЕМЕ ТОРСА (узел Torso стоит на y=1.02 от корня).
# BUILD-26: x прижат к груди (0.24) — суставы не торчат «погонами».
const FP_SHOULDER_R := Vector3(0.24, 0.28, 0.02)
const FP_SHOULDER_L := Vector3(-0.24, 0.28, 0.02)
# Куда «смотрит» локоть (в системе головы): наружу и вниз, не прижат к телу.
const ARM_POLE_R := Vector3(1.3, -0.45, 0.25)
const ARM_POLE_L := Vector3(-1.3, -0.45, 0.25)
# BUILD-19/20: плечи соперника — НА ПОВЕРХНОСТИ тела (капсула радиусом 0.32)
# и в системе ТЕЛА (не головы!): при наклоне головы вверх/вниз плечи остаются
# на месте и руки не «торчат из спины». y=1.24 — плечевой пояс над торсом.
# Система ТОРСА (узел Torso на y=1.02): 0.22 + 1.02 = 1.24 от корня.
const REMOTE_SHOULDER_R := Vector3(0.24, 0.22, 0.02)
const REMOTE_SHOULDER_L := Vector3(-0.24, 0.22, 0.02)


func _setup_arms() -> void:
	var mat_skin := StandardMaterial3D.new()
	mat_skin.albedo_color = ARM_SKIN_COLOR
	var mat_sleeve := StandardMaterial3D.new()
	mat_sleeve.albedo_color = ARM_SLEEVE_COLOR
	_fp_arms_root = Node3D.new()
	_fp_arms_root.name = "FPArms"
	head.add_child(_fp_arms_root)
	for i in 2:
		var side: String = "R" if i == 0 else "L"
		_fp_arm_nodes.append(_build_arm_rig(_fp_arms_root, mat_skin, mat_sleeve, "FPArm" + side))
		_remote_arm_nodes.append(_build_arm_rig(head, mat_skin, mat_sleeve, "RemoteArm" + side))
	_set_remote_arms_visible(false)


# BUILD-23: тело вместо капсулы — торс (грудь на узле Torso, доворачивается
# к взгляду первым) и ноги с коленями на узле LegsYaw (следуют за направлением
# движения/телом). Видно и сопернику, и самому владельцу (смотреть вниз —
# видишь свои ноги и торс).
func _setup_body() -> void:
	var capsule: MeshInstance3D = get_node_or_null("RemoteBody/Body")
	if capsule != null:
		capsule.queue_free()
	var mat_pants := StandardMaterial3D.new()
	mat_pants.albedo_color = ARM_SLEEVE_COLOR
	var mat_shoe := StandardMaterial3D.new()
	mat_shoe.albedo_color = Color(0.15, 0.15, 0.18)
	legs_node = Node3D.new()
	legs_node.name = "LegsYaw"
	add_child(legs_node)
	torso_node = Node3D.new()
	torso_node.name = "Torso"
	torso_node.position = Vector3(0.0, 1.02, 0.0)
	add_child(torso_node)
	var pelvis := MeshInstance3D.new()
	pelvis.name = "Pelvis"
	var pm := BoxMesh.new()
	pm.size = Vector3(0.40, 0.26, 0.26)
	pelvis.mesh = pm
	pelvis.material_override = mat_pants
	pelvis.position = Vector3(0.0, 0.98, 0.0)
	legs_node.add_child(pelvis)
	_pelvis_mesh = pelvis
	var chest := MeshInstance3D.new()
	chest.name = "Chest"
	var cmesh := BoxMesh.new()
	# BUILD-24/25: грудь ниже и мельче — верх на 1.36, не перекрывает
	# камеру (1.62) даже при лёгком наклоне взгляда.
	cmesh.size = Vector3(0.50, 0.36, 0.24)
	chest.mesh = cmesh
	chest.material_override = mat_pants
	chest.position = Vector3(0.0, 0.16, 0.0)
	torso_node.add_child(chest)
	_chest_mesh = chest
	# шея: тонкая, в камеру не попадает, голова не «висит» в воздухе.
	var mat_skin := StandardMaterial3D.new()
	mat_skin.albedo_color = ARM_SKIN_COLOR
	var neck := MeshInstance3D.new()
	neck.name = "Neck"
	var nm := BoxMesh.new()
	nm.size = Vector3(0.14, 0.20, 0.14)
	neck.mesh = nm
	neck.material_override = mat_skin
	neck.position = Vector3(0.0, 0.42, 0.0)
	torso_node.add_child(neck)
	_neck_mesh = neck
	for i in 2:
		var side := "R" if i == 0 else "L"
		var rig := {}
		rig["thigh"] = _make_limb("Leg" + side + "Thigh", mat_pants, 0.13)
		rig["shin"] = _make_limb("Leg" + side + "Shin", mat_pants, 0.11)
		var foot := MeshInstance3D.new()
		foot.name = "Leg" + side + "Foot"
		var fm := BoxMesh.new()
		fm.size = Vector3(0.11, 0.08, 0.24)
		foot.mesh = fm
		foot.material_override = mat_shoe
		rig["foot"] = foot
		legs_node.add_child(rig["thigh"])
		legs_node.add_child(rig["shin"])
		legs_node.add_child(foot)
		if i == 0:
			_leg_rig_r = rig
		else:
			_leg_rig_l = rig
	_legs_yaw = rotation.y


func _set_body_visible(v: bool) -> void:
	if torso_node != null:
		torso_node.visible = v
	if legs_node != null:
		legs_node.visible = v


# BUILD-23: «сначала торс, потом всё тело». Торс доворачивается к взгляду не
# больше TORSO_TWIST_MAX; когда взгляда не хватает — ноги (и весь корпус)
# плавно поворачиваются следом. В движении ноги смотрят по направлению шага.
func _update_body_pose(delta: float, moving: bool, move_dir: Vector3, crouched: bool, grounded: bool, bob_y: float, walk_w: float, seat_w: float) -> void:
	if torso_node == null:
		return
	# BUILD-27: присед и прыжок — плавные веса (синхронно у обоих игроков).
	_crouch_w = move_toward(_crouch_w, 1.0 if crouched else 0.0, delta * 8.0)
	_air_w = move_toward(_air_w, 0.0 if grounded else 1.0, delta * 10.0)
	head.position.y = lerpf(HEAD_Y, HEAD_Y_CROUCH, _crouch_w)
	# BUILD-28: голова-меш (сфера) следует за высотой головы — в приседе
	# не остаётся парить на 1.62.
	if _head_mesh != null:
		_head_mesh.position.y = head.position.y
	torso_node.position.y = lerpf(TORSO_Y, TORSO_Y_CROUCH, _crouch_w) + bob_y
	torso_node.rotation.x = 0.18 * _crouch_w  # лёгкий наклон корпуса в приседе
	if _pelvis_mesh != null:
		_pelvis_mesh.position.y = lerpf(HIP_Y, HIP_Y_CROUCH, _crouch_w)
	# BUILD-30: сидячая поза в турели — торс ниже, голова у спинки, таз на
	# сиденье; ноги подвешены (см. _update_legs_rig). seat_w = 0..1 (синхрон:
	# флаг посадки едет в пакете состояния, все ноды проигрывают один вес).
	if seat_w > 0.0:
		head.position.y = lerpf(head.position.y, TURRET_SEAT_HEAD_Y, seat_w)
		torso_node.position.y = lerpf(torso_node.position.y, TURRET_SEAT_TORSO_Y, seat_w)
		torso_node.rotation.x = lerpf(torso_node.rotation.x, 0.04, seat_w)
		if _pelvis_mesh != null:
			_pelvis_mesh.position.y = lerpf(_pelvis_mesh.position.y, TURRET_SEAT_HIP_Y, seat_w)
	# Коллизии и хитбокс приседают вместе с телом. Сидя в турели тело не
	# двигается — коллизия выключена, хитбокс — по сидящей позе (всё ещё
	# можно убить: пуля бьёт по «сидячему» объёму).
	var cs := 1.0 - 0.25 * _crouch_w
	# Коллизия тела выключена, ПОКА ИГРОК СИДИТ (mounted_idx >= 0): в
	# переходных кадрах посадки ноги ещё внутри базы турели, и включённая
	# коллизия выталкивает тело наверх основания. При выходе игрок уже
	# телепортирован на точку выхода (вне базы) — коллизия возвращается.
	var seated := mounted_idx >= 0
	_body_shape.disabled = seated
	if seat_w > 0.5:
		# Сидя: короче (верх ~1.71 м — закрывает и голову на 1.55).
		_hitbox_shape.scale = Vector3(1.0, 0.80, 1.0)
		_hitbox_shape.position.y = 0.95
	else:
		_body_shape.scale = Vector3(1.0, cs, 1.0)
		_body_shape.position.y = 0.9 * cs
		_hitbox_shape.scale = Vector3(1.0, cs, 1.0)
		_hitbox_shape.position.y = 0.95 * cs
	var aim := rotation.y
	# BUILD-25: ноги НЕ крутятся по кругу от стрейфа — отклоняются в сторону
	# шага не дальше LEGS_STRAFE_MAX от взгляда. Поворот мыши: руки/оружие
	# сразу, торс плавно следом, ноги — в последнюю очередь.
	var target := aim
	if moving and move_dir.length_squared() > 0.01:
		var move_yaw := atan2(-move_dir.x, -move_dir.z)
		target = aim + clampf(wrapf(move_yaw - aim, -PI, PI), -LEGS_STRAFE_MAX, LEGS_STRAFE_MAX)
	var d := wrapf(target - _legs_yaw, -PI, PI)
	var step := LEGS_TURN_SPEED * delta
	_legs_yaw = wrapf(_legs_yaw + clampf(d, -step, step), -PI, PI)
	legs_node.rotation.y = _legs_yaw - aim
	# торс доворачивается к взгляду ПЛАВНО (своей угловой скоростью), в
	# пределах запаса относительно ног.
	var target_twist := clampf(wrapf(aim - _legs_yaw, -PI, PI), -TORSO_TWIST_MAX, TORSO_TWIST_MAX)
	_torso_twist = move_toward(_torso_twist, target_twist, TORSO_TURN_SPEED * delta)
	torso_node.rotation.y = _legs_yaw + _torso_twist - aim
	# BUILD-27: поворот на месте — ноги ПЕРЕСТАВЛЯЮТСЯ: фаза шага идёт, пока
	# корпус доворачивает (стопа видно, как игрок переминается при повороте).
	var turn := absf(wrapf(aim - _legs_yaw, -PI, PI))
	var step_w := clampf((turn - 0.25) / 0.5, 0.0, 1.0) * (1.0 - _air_w)
	if moving:
		_leg_phase += delta * BOB_SPEED
	elif step_w > 0.0:
		_leg_phase += delta * BOB_SPEED * (0.4 + 0.6 * step_w)
	var stride_w := maxf(walk_w, step_w * 0.7 if not moving else 0.0)
	# BUILD-30: сидя — таз на сиденье, стопы подвешены впереди (seat_w).
	var hip_y: float = lerpf(HIP_Y, HIP_Y_CROUCH, _crouch_w)
	_update_legs_rig(_leg_phase, stride_w, _air_w, lerpf(hip_y, TURRET_SEAT_HIP_Y, seat_w), seat_w)


# Ноги с коленями: процедурный шаг (фаза как у покачивания оружия), в покое —
# стойка. Колено решается той же двухзвенной ИК, что и локоть, полюс — вперёд.
func _update_legs_rig(phase: float, w: float, air_w: float, hip_y: float, seat_w: float) -> void:
	if legs_node == null:
		return
	var ltf := legs_node.global_transform
	for i in 2:
		var rig: Dictionary = _leg_rig_r if i == 0 else _leg_rig_l
		var sgn := 1.0 if i == 0 else -1.0
		var ph := phase + (0.0 if i == 0 else PI)
		# BUILD-27: в прыжке шаг замирает, ноги поджимаются (колени вперёд).
		var stride := sin(ph) * LEG_STRIDE * w * (1.0 - air_w)
		var lift := maxf(0.0, cos(ph)) * LEG_LIFT * w * (1.0 - air_w)
		var hip_w := ltf * Vector3(0.16 * sgn, hip_y, 0.0)
		var foot_local := Vector3(0.17 * sgn, 0.05 + lift + air_w * 0.30, -stride - air_w * 0.12)
		# BUILD-30: сидя — стопа висит впереди-внизу (колени согнуты вперёд).
		foot_local = foot_local.lerp(Vector3(0.17 * sgn, 0.30, -0.40), seat_w)
		var foot_w := ltf * foot_local
		var knee := _solve_elbow(hip_w, foot_w + Vector3(0.0, 0.06, 0.0), THIGH_LEN, SHIN_LEN, ltf.basis * Vector3(0.0, 0.2, -1.0))
		_place_limb(rig["thigh"], hip_w, knee)
		_place_limb(rig["shin"], knee, foot_w + Vector3(0.0, 0.04, 0.0))
		rig["foot"].global_transform = Transform3D(ltf.basis, foot_w)


# Одна рука: сегмент плеча, предплечье, кисть. Позиции сегментов пересчитываются
# каждый кадр между суставами (см. _place_limb).
func _build_arm_rig(parent: Node3D, mat_skin: StandardMaterial3D, mat_sleeve: StandardMaterial3D, node_name: String) -> Dictionary:
	var upper := _make_limb(node_name + "_Upper", mat_sleeve, UPPER_ARM_THICK)
	var fore := _make_limb(node_name + "_Fore", mat_sleeve, FOREARM_THICK)
	# BUILD-20: плечевой сустав — небольшой бокс, наполовину утопленный в тело:
	# рука визуально ЗАКРЕПЛЕНА на корпусе, а не начинается из воздуха.
	var shoulder := MeshInstance3D.new()
	shoulder.name = node_name + "_Shoulder"
	var shb := BoxMesh.new()
	shb.size = Vector3(0.12, 0.12, 0.12)  # BUILD-26: компактнее, не торчит
	shoulder.mesh = shb
	shoulder.material_override = mat_sleeve
	var hand := MeshInstance3D.new()
	hand.name = node_name + "_Hand"
	var hb := BoxMesh.new()
	hb.size = Vector3(0.06, 0.055, 0.11)
	hand.mesh = hb
	hand.material_override = mat_skin
	parent.add_child(shoulder)
	parent.add_child(upper)
	parent.add_child(fore)
	parent.add_child(hand)
	return {"shoulder": shoulder, "upper": upper, "fore": fore, "hand": hand}


func _make_limb(node_name: String, mat: StandardMaterial3D, thickness: float) -> MeshInstance3D:
	var seg := MeshInstance3D.new()
	seg.name = node_name
	var bm := BoxMesh.new()
	bm.size = Vector3(thickness, thickness, 0.3)
	seg.mesh = bm
	seg.material_override = mat
	return seg


func _set_arm_visible(arm: Dictionary, v: bool) -> void:
	arm["shoulder"].visible = v
	arm["upper"].visible = v
	arm["fore"].visible = v
	arm["hand"].visible = v


func _set_remote_arms_visible(v: bool) -> void:
	for arm in _remote_arm_nodes:
		_set_arm_visible(arm, v)


# Локоть двухзвенной руки: плечо→запястье при фиксированных длинах звеньев.
# pole_dir задаёт сторону, в которую сгибается локоть.
func _solve_elbow(shoulder: Vector3, wrist: Vector3, upper_len: float, fore_len: float, pole_dir: Vector3) -> Vector3:
	var to_wrist := wrist - shoulder
	var d := to_wrist.length()
	if d < 0.001:
		return shoulder + pole_dir.normalized() * upper_len * 0.5
	var dir := to_wrist / d
	var c := clampf(d, absf(upper_len - fore_len) + 0.01, upper_len + fore_len - 0.01)
	var cos_a := (upper_len * upper_len + c * c - fore_len * fore_len) / (2.0 * upper_len * c)
	var ang := acos(clampf(cos_a, -1.0, 1.0))
	# Перпендикуляр к линии плечо-запястье в сторону «полюса» (там будет локоть).
	var h := pole_dir - dir * dir.dot(pole_dir)
	if h.length_squared() < 0.0001:
		h = Vector3(0.0, -1.0, 0.0) - dir * dir.dot(Vector3(0.0, -1.0, 0.0))
	h = h.normalized()
	return shoulder + (dir * cos(ang) + h * sin(ang)) * upper_len


# Сегмент конечности: бокс, растянутый между двумя точками мира.
func _place_limb(seg: MeshInstance3D, a: Vector3, b: Vector3) -> void:
	seg.global_position = (a + b) * 0.5
	var d := a.distance_to(b)
	var bm: BoxMesh = seg.mesh
	var thick: float = bm.size.x
	bm.size = Vector3(thick, thick, maxf(d, 0.02))
	if d > 0.001:
		var dirv := (b - a) / d
		var up := Vector3.UP
		if absf(dirv.dot(up)) > 0.98:
			up = Vector3.FORWARD
		seg.look_at(b, up)


# Вся рука целиком: локоть по IK, запястье в 6 см от кисти (в сторону плеча),
# кисть совмещена с осями оружия. Делает все три сегмента видимыми.
func _place_arm_rig(arm: Dictionary, shoulder: Vector3, hand_pos: Vector3, hand_basis: Basis, pole: Vector3) -> void:
	arm["shoulder"].global_position = shoulder  # сустав закреплён на теле
	var wrist: Vector3 = hand_pos + (shoulder - hand_pos).normalized() * 0.06
	var elbow: Vector3 = _solve_elbow(shoulder, wrist, UPPER_ARM_LEN, FOREARM_LEN, pole)
	# BUILD-22: страховка — если ИК положил локоть внутрь капсулы тела,
	# выталкиваем его горизонтально наружу (на 4 см от поверхности).
	var rel := elbow - global_position
	if elbow.y > global_position.y + 0.15 and elbow.y < global_position.y + 1.65:
		var hdir := Vector2(rel.x, rel.z)
		var rl := hdir.length()
		if rl < 0.33:
			hdir = (hdir / rl) if rl > 1e-4 else Vector2(1.0, 0.0)
			elbow = global_position + Vector3(hdir.x * 0.33, rel.y, hdir.y * 0.33)
	_place_limb(arm["upper"], shoulder, elbow)
	_place_limb(arm["fore"], elbow, wrist)
	var hand: MeshInstance3D = arm["hand"]
	hand.global_transform = Transform3D(hand_basis, hand_pos)
	_set_arm_visible(arm, true)


# Руки от первого лица пересчитываются каждый кадр: кисти лежат на рукоятках
# и следуют за оружием, локти сгибаются. Вызывается ПОСЛЕ всех коррекций позы.
func _update_fp_arms() -> void:
	if _fp_arms_root == null or not _fp_arms_root.visible:
		return
	# BUILD-30: сидя в турели — обе кисти лежат на хватах ствольной группы
	# (правая — правый ствол, левая — левый). Плечи — на сидящем торсе.
	if mounted_idx >= 0:
		var t := _my_turret()
		if t == null:
			_fp_arms_root.visible = false
			return
		_fp_arms_root.visible = true
		var body_tf := torso_node.global_transform if torso_node != null else global_transform
		var pole_r: Vector3 = body_tf.basis * ARM_POLE_R
		var pole_l: Vector3 = body_tf.basis * ARM_POLE_L
		_place_arm_rig(_fp_arm_nodes[0], body_tf * FP_SHOULDER_R, t.world_grip(1), Basis.IDENTITY, pole_r)
		_place_arm_rig(_fp_arm_nodes[1], body_tf * FP_SHOULDER_L, t.world_grip(0), Basis.IDENTITY, pole_l)
		return
	# BUILD-22/23: плечи и полюса — в системе ТОРСА: при взгляде вниз плечи
	# не срываются, руки сгибаются в локтях; доворот торса виден и в плечах.
	var body_tf := torso_node.global_transform if torso_node != null else global_transform
	var sh_r: Vector3 = body_tf * FP_SHOULDER_R
	var sh_l: Vector3 = body_tf * FP_SHOULDER_L
	var pole_r: Vector3 = body_tf.basis * ARM_POLE_R
	var pole_l: Vector3 = body_tf.basis * ARM_POLE_L
	# BUILD-19: локоть реагирует на наклон оружия — поднял ствол, локоть ушёл
	# вниз-наружу (как в жизни). Без этого при отведении оружия от тела рука
	# выглядит «застывшей».
	pole_r.y -= _fp_tilt * 0.6
	pole_l.y -= _fp_tilt * 0.6
	# BUILD-22: при взгляде вниз поддерживающий (левый) локоть уходит ПЕРЕД
	# грудь, а не за бок-назад — иначе предплечье пересекает торс.
	var dp := _down_aim_amount(head.rotation.x)
	if dp > 0.0:
		# BUILD-23: оба локтя при взгляде вниз — вперёд-наружу-вниз, обнимают
		# грудь снаружи («ровно под тело» — руки не пересекают торс).
		pole_l = pole_l.lerp(body_tf.basis * Vector3(-0.9, -0.7, -1.0), dp)
		pole_r = pole_r.lerp(body_tf.basis * Vector3(0.9, -0.7, -1.0), dp)
	if current_weapon == 0:
		# Нож: правая рука на рукояти (движется вместе с клинком), левая скрыта.
		var ktf := knife_fp.global_transform
		_place_arm_rig(_fp_arm_nodes[0], sh_r, ktf * Vector3(0.0, -0.045, 0.13), ktf.basis.orthonormalized(), pole_r)
		_set_arm_visible(_fp_arm_nodes[1], false)
		return
	var gtf := gun_anchor.global_transform
	var grip_r := Vector3(0.0, -0.075, 0.14)
	var grip_l := Vector3(0.0, -0.10, 0.02)
	if current_weapon == 2:
		grip_r = Vector3(0.02, -0.085, 0.02)
		grip_l = Vector3(-0.02, -0.06, -0.30)
	var hb: Basis = gtf.basis.orthonormalized()
	_place_arm_rig(_fp_arm_nodes[0], sh_r, gtf * grip_r, hb, pole_r)
	_place_arm_rig(_fp_arm_nodes[1], sh_l, gtf * grip_l, hb, pole_l)


# Точки хвата СОПЕРНИКА в ЛОКАЛЬНЫХ координатах его оружия — масштаб и разворот
# модели учитываются автоматически. Возвращает [правая, левая, две_ли_руки].
func _remote_grip_offsets() -> Array:
	match current_weapon:
		0:  # нож — одна рука на рукояти (клинок смотрит в -Z модели)
			return [Vector3(0.0, -0.045, 0.12), Vector3.ZERO, false]
		2:  # снайперка: правая на рукоятке, левая на цевье (дуло в +Z модели)
			return [Vector3(0.0, -0.16, 0.5), Vector3(0.0, -0.10, 1.15), true]
	# пистолет: правая на рукоятке, левая поддерживает снизу
	return [Vector3(0.0, -0.085, 0.10), Vector3(0.0, -0.115, 0.0), true]


# Руки соперника: та же оснастка. Кисти на рукоятках его оружия, локти
# сгибаются от плеч. Наследуют отдачу, покачивание, удар ножом, наклон
# и складывание у стены. Вызывается в конце кадра отрисовки «чужого» игрока.
func _update_remote_arms() -> void:
	if _remote_arm_nodes.is_empty():
		return
	# BUILD-30: сидящий соперник — его кисти на хватах СВОЕЙ турели (оба ствола).
	if mounted_idx >= 0:
		var t := _arena_turret(mounted_idx)
		if t == null:
			_set_remote_arms_visible(false)
			return
		var body_tf := torso_node.global_transform if torso_node != null else global_transform
		var pole_r: Vector3 = body_tf.basis * ARM_POLE_R
		var pole_l: Vector3 = body_tf.basis * ARM_POLE_L
		_place_arm_rig(_remote_arm_nodes[0], body_tf * REMOTE_SHOULDER_R, t.world_grip(1), Basis.IDENTITY, pole_r)
		_place_arm_rig(_remote_arm_nodes[1], body_tf * REMOTE_SHOULDER_L, t.world_grip(0), Basis.IDENTITY, pole_l)
		return
	var weapon: Node3D = remote_gun
	match current_weapon:
		0:
			weapon = knife_remote
		2:
			weapon = sniper_remote
	if not weapon.visible:
		_set_remote_arms_visible(false)
		return
	# BUILD-20: плечи и «полюсы» локтей — в системе ТЕЛА (global_transform:
	# позиция + рыск, БЕЗ тангажа головы), иначе при взгляде вверх плечи
	# уезжали за спину и руки «торчали из спины».
	var body_tf := torso_node.global_transform if torso_node != null else global_transform
	var hb: Basis = weapon.global_transform.basis.orthonormalized()
	var offs: Array = _remote_grip_offsets()
	# Локоть реагирует на наклон оружия владельца (синхронно с его видом).
	var pole_r: Vector3 = body_tf.basis * ARM_POLE_R
	var pole_l: Vector3 = body_tf.basis * ARM_POLE_L
	pole_r.y -= _remote_tilt * 0.6
	pole_l.y -= _remote_tilt * 0.6
	# BUILD-22: поддерживающий (левый) локоть соперника при взгляде вниз —
	# ПЕРЕД грудью, чтобы предплечье не пересекало торс.
	var dp := _down_aim_amount(head.rotation.x)
	if dp > 0.0:
		pole_l = pole_l.lerp(body_tf.basis * Vector3(-0.9, -0.7, -1.0), dp)
		pole_r = pole_r.lerp(body_tf.basis * Vector3(0.9, -0.7, -1.0), dp)
	_place_arm_rig(_remote_arm_nodes[0], body_tf * REMOTE_SHOULDER_R, weapon.global_transform * offs[0], hb, pole_r)
	if bool(offs[2]):
		_place_arm_rig(_remote_arm_nodes[1], body_tf * REMOTE_SHOULDER_L, weapon.global_transform * offs[1], hb, pole_l)
	else:
		_set_arm_visible(_remote_arm_nodes[1], false)


# Оружие не должно проваливаться в стены, укрытия и модельки. Вдоль ствола
# пускаются ТРИ ЛУЧА по вертикальному габариту модели (верх / ось / низ) —
# так учитывается высота оружия: при подъёме ствола нижняя грань дула
# выдвигается ВПЕРЁД на radius*sin(θ), и именно она раньше цепляла стену.
# Лучи стартуют из-за спины якоря (из свободного места), поэтому расстояние
# измеряется честно даже в упоре.
# ВАРИАЦИИ РЕАКЦИИ: ствол ВВЕРХ (обычно), ствол ВНИЗ (когда игрок смотрит
# вверх), либо СКЛАДЫВАНИЕ «в обе руки» к груди, когда места совсем мало.
# Возвращает [позиция в системе головы, угол (со знаком), цель складывания 0/1].
func _push_weapon_out_of_walls(head_tf: Transform3D, weapon_pos: Vector3, tip_off: Vector3, radius: float, looking_up: bool, folded: bool) -> Array:
	var space := get_world_3d().direct_space_state
	if space == null:
		return [weapon_pos, 0.0, 0.0]
	var anchor_w: Vector3 = head_tf * weapon_pos
	var tip_w: Vector3 = head_tf * (weapon_pos + tip_off)
	var barrel := tip_w - anchor_w
	var reach := barrel.length()
	if reach < 0.01:
		return [weapon_pos, 0.0, 0.0]
	var dir := barrel / reach
	# Три «щупа» по высоте модели: верхняя кромка, осевая линия, нижняя грань.
	var d_min := INF
	for dy in [radius, 0.0, -radius]:
		var off: Vector3 = head_tf.basis * Vector3(0.0, dy, 0.0)
		var rq := PhysicsRayQueryParameters3D.new()
		rq.from = anchor_w + off - dir * 0.55
		rq.to = anchor_w + off + dir * (reach + 0.25)
		rq.collision_mask = 1
		rq.collide_with_bodies = true
		rq.collide_with_areas = false
		rq.hit_from_inside = true
		# BUILD-19: соперник — НЕ стена. Иначе в упор оружие «цепляется» за его
		# тело и складывается вбок на ровном месте (исключаем тела всех игроков).
		var excl: Array = [get_rid()]
		var scene := get_tree().current_scene
		var players_dict = scene.get("players") if scene != null else null
		if players_dict != null:
			for p in players_dict.values():
				if p != self:
					excl.append((p as Node3D).get_rid())
		rq.exclude = excl
		var hit := space.intersect_ray(rq)
		if hit.is_empty():
			continue
		var d: float = (Vector3(hit.position) - (anchor_w + off)).dot(dir)
		d_min = minf(d_min, d)
	if d_min >= reach + WEAPON_WALL_MARGIN:
		return [weapon_pos, 0.0, 0.0]  # оружие полностью помещается
	var avail := d_min - WEAPON_WALL_MARGIN
	var pos := weapon_pos
	# Начальный контакт гасим лёгкой, почти незаметной оттяжкой (до 8 см).
	var soft := clampf(reach - avail, 0.0, WEAPON_SOFT_PULL)
	if soft > 0.0:
		var new_z := minf(pos.z + soft, WEAPON_MIN_Z)
		avail += new_z - pos.z
		pos.z = new_z
		if avail >= reach:
			return [pos, 0.0, 0.0]
	# Игрок смотрит ВВЕРХ: задирать дуло ещё выше — бессмыслица, естественная
	# реакция — ОПУСТИТЬ ствол и чуть отвести оружие (отвод гарантирует, что
	# опущенный ствол не зацепит стену, т.к. смотрит он почти горизонтально).
	if looking_up:
		pos.z = minf(pos.z + WEAPON_DOWN_PULL, WEAPON_MIN_Z)
		return [pos, -WEAPON_DOWN_TILT, 0.0]
	# Подъём ствола с учётом высоты модели: при наклоне θ передняя нижняя
	# кромка выдвигается на reach*cos(θ) + radius*sin(θ). Решаем
	# R*cos(θ - φ) = avail, где R = √(reach² + radius²), φ = atan2(radius, reach).
	var big_r := sqrt(reach * reach + radius * radius)
	var phi := atan2(radius, reach)
	var tilt_req := phi + acos(clampf(avail / big_r, -1.0, 1.0))
	# Места совсем мало — оружие складывается к груди «в обе руки»
	# (гистерезис не даёт дёргаться на границе режимов).
	var fold_limit := WEAPON_FOLD_EXIT if folded else WEAPON_FOLD_TILT
	if tilt_req > fold_limit:
		return [pos, 0.0, 1.0]
	return [pos, tilt_req, 0.0]


# Рыск сложенного оружия: чем длиннее ствол, тем сильнее дуло уходит влево,
# чтобы оружие гарантированно помещалось даже в упоре к стене.
func _fold_yaw(reach: float) -> float:
	return clampf(acos(clampf(0.12 / maxf(reach, 0.1), 0.0, 1.0)), 0.9, 1.45)


func _fire() -> void:
	if dead:
		if OS.is_debug_build():
			print("[FIRE] отклонено: игрок мёртв (нода=%s)" % name)
		return
	# BUILD-30: в турели оружие в руках не стреляет — только ствольная группа.
	if mounted_idx >= 0:
		return
	var now := Time.get_ticks_msec()
	if reload_end_ms > now:
		return  # идёт перезарядка
	# BUILD-15: оружие смещено у стены (поднято/опущено/сложено вбок) —
	# выстрел ЗАБЛОКИРОВАН. Пуля полетела бы по смещённому стволу (вверх или
	# вбок), для игрока это выглядит как «выстрел не в ту сторону». Отойдите
	# от стены — и стрельба снова пойдёт в перекрестие.
	if _weapon_displaced():
		if OS.is_debug_build():
			print("[FIRE] отклонено: оружие смещено у стены — отойдите, чтобы выстрелить")
		return
	if current_weapon == 0:
		_fire_melee()
		return
	var w: Dictionary = Game.WEAPONS[current_weapon]
	if now < next_allowed_shot_ms:
		return
	if int(ammo_mag.get(current_weapon, 0)) <= 0:
		_start_reload()  # пустой магазин — автоматическая перезарядка
		return
	ammo_mag[current_weapon] = int(ammo_mag[current_weapon]) - 1
	next_allowed_shot_ms = now + int(w["cooldown_ms"])
	if OS.is_debug_build():
		print("[FIRE] выстрел (нода=%s, оружие=%s, патроны=%d/%d, прицел=по перекрестию)" % [name, str(w["name"]), int(ammo_mag[current_weapon]), int(ammo_reserve[current_weapon])])
	_local_shot_fx()
	_send_shot_request(0)
	Game.weapon_changed.emit(_hud_weapon_label())


# Быстрый удар ножом (ЛКМ).
func _fire_melee() -> void:
	if _weapon_displaced():
		return  # оружие сложено у стены — удар заблокирован (см. _fire)
	if _knife_phase != 0:
		return  # уже идёт замах или удар
	var now := Time.get_ticks_msec()
	if now < next_allowed_shot_ms:
		return
	var w: Dictionary = Game.WEAPONS[0]
	next_allowed_shot_ms = now + int(w["cooldown_ms"])
	_knife_phase = 3
	_knife_t = 0.0
	play_melee.rpc(0)  # соперник сразу видит удар
	_send_shot_request(0)


# Сильный удар ножом (ПКМ): сначала замах с задержкой, потом удар.
func _start_heavy_strike() -> void:
	if _knife_phase != 0 or reload_end_ms > Time.get_ticks_msec():
		return
	if _weapon_displaced():
		return  # оружие сложено у стены — удар заблокирован (см. _fire)
	var now := Time.get_ticks_msec()
	if now < next_allowed_shot_ms:
		return
	_knife_phase = 1
	_knife_t = 0.0
	play_melee.rpc(1)  # соперник видит замах одновременно с нами


# Событие удара ножом для соперника: запускает ту же машину фаз,
# что и анимация от первого лица — анимации полностью синхронны.
@rpc("any_peer", "call_remote", "reliable")
func play_melee(attack_type: int) -> void:
	if multiplayer.get_remote_sender_id() != str(name).to_int():
		return
	_recoil_time = KNIFE_REMOTE_KICK
	_remote_knife_phase = 1 if attack_type == 1 else 3
	_remote_knife_t = 0.0


# Вызывается из анимации, когда замах завершён: наносим урон.
func _deliver_heavy_strike() -> void:
	var w: Dictionary = Game.WEAPONS[0]
	next_allowed_shot_ms = Time.get_ticks_msec() + int(w["heavy_cooldown_ms"])
	head.rotation.x -= 0.02  # ощутимый «тычок» камеры
	_send_shot_request(1)


# Отправка выстрела/удара на сервер (атака 0 = обычная, 1 = тяжёлый удар).
# Визуал ножа сопернику уже ушёл событием play_melee в момент начала удара.
func _send_shot_request(attack_type: int) -> void:
	# Если оружие поднято/сложено у стены — стреляем НЕ в перекрестие,
	# а строго по направлению ствола (и точка вылета — дуло).
	var origin := _shot_origin()
	if multiplayer.is_server():
		# Хост валидирует свой выстрел напрямую.
		var arena := get_tree().current_scene
		if arena != null and arena.has_method("handle_shoot_request"):
			arena.handle_shoot_request(multiplayer.get_unique_id(), origin, _aim_dir(), current_weapon, attack_type)
		elif OS.is_debug_build():
			print("[FIRE] арена с handle_shoot_request не найдена!")
	else:
		request_shoot.rpc_id(1, origin, _aim_dir(), current_weapon, attack_type)


@rpc("any_peer", "call_remote", "reliable")
func request_shoot(origin: Vector3, dir: Vector3, weapon_idx: int, attack_type: int) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender != str(name).to_int():
		return  # стрелять можно только за себя
	var arena := get_tree().current_scene
	if arena != null and arena.has_method("handle_shoot_request"):
		arena.handle_shoot_request(sender, origin, dir, weapon_idx, attack_type)


func _local_shot_fx() -> void:
	_fp_recoil = 1.0  # запуск анимации отдачи оружия от первого лица
	var w: Dictionary = Game.WEAPONS[current_weapon]
	# Трассер летит из дула в ТОЧКУ ПОПАДАНИЯ прицела: луч считается из
	# центра камеры, поэтому след визуально сходится в перекрестии.
	# У ножа трассера нет — только анимация удара.
	var end := Vector3.ZERO
	if w["tracer"]:
		end = _predict_hit(float(w["range"]))
		_spawn_tracer(_fp_muzzle_pos(), end)
	head.rotation.x -= 0.012  # лёгкая отдача камеры
	announce_shot.rpc(end)


# Точка вылета трассера от первого лица — у каждого оружия своё дуло.
func _fp_muzzle_pos() -> Vector3:
	if current_weapon == 2:
		return sniper_fp_muzzle.global_position
	return muzzle.global_position


# «Чужое» дуло — из него соперник видит трассер нашего выстрела.
func _remote_muzzle_pos() -> Vector3:
	if current_weapon == 2:
		return sniper_remote_muzzle.global_position
	return remote_muzzle.global_position


# Локальное предсказание точки попадания (только для визуала трассера;
# урон по-прежнему считает сервер своим лучом).
func _predict_hit(weapon_range: float) -> Vector3:
	return _predict_hit_from(_shot_origin(), _aim_dir(), weapon_range)


# То же, но из произвольной точки/направления (BUILD-30: из дула турели).
func _predict_hit_from(origin: Vector3, dir: Vector3, weapon_range: float) -> Vector3:
	var far := origin + dir * weapon_range
	if get_tree() == null or get_tree().current_scene == null:
		return far
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(origin, far)
	query.collision_mask = 3  # мир + хитбоксы — как у сервера
	query.collide_with_areas = true
	query.collide_with_bodies = true
	query.exclude = [get_rid(), get_node("Hitbox").get_rid()]
	var hit := space.intersect_ray(query)
	if hit:
		return hit.position
	return far


@rpc("any_peer", "call_remote", "unreliable")
func announce_shot(end: Vector3) -> void:
	if multiplayer.get_remote_sender_id() != str(name).to_int():
		return
	_recoil_time = RECOIL_TIME
	# Трассер соперника: из дула «чужого» оружия в точку попадания —
	# видно, куда именно пришёлся выстрел (у ножа трассера нет).
	if Game.WEAPONS[current_weapon]["tracer"]:
		_spawn_tracer(_remote_muzzle_pos(), end)


func _spawn_tracer(from: Vector3, to: Vector3) -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	var tracer: Node3D = preload("res://scenes/fx/tracer.tscn").instantiate()
	scene.add_child(tracer)
	tracer.setup(from, to)


# Оружие сейчас смещено коллизией (поднято/опущено/сложено)?
func _weapon_displaced() -> bool:
	return absf(_fp_tilt) > 0.25 or _fp_fold > 0.3


# Откуда и куда летит пуля: ВСЕГДА из камеры в перекрестие. Если оружие
# смещено у стены (поднято/сложено), выстрел блокируется в _fire(), поэтому
# «выстрел по кривому стволу» невозможен в принципе — пуля всегда летит туда,
# куда смотрит игрок (см. BUILD-15).
func _shot_origin() -> Vector3:
	return camera.global_position


func _aim_dir() -> Vector3:
	return -camera.global_transform.basis.z


func get_head_world_position() -> Vector3:
	return head.global_position
