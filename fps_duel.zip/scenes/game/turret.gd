extends Node3D
## BUILD-30: турель — вращающаяся двухствольная установка. В неё может сесть
## ОДИН игрок (клавиша F рядом): он крутит турель мышью, стреляет ЛКМ
## (ствола бьют по очереди: левый, правый, левый…), перезаряжает R.
##
## СИНХРОНИЗАЦИЯ:
##  * угловое положение берёт из yaw сидящего игрока (у каждого игрока он
##    синхронизирован пакетом состояния 20 Гц) — узел Yaw плавно догоняет;
##  * очередь выстрелов/патроны/перезарядка авторитетны на СЕРВЕРЕ (переменные
##    mag/barrel/reload_end_ms/next_shot_ms имеют смысл только на ноду хоста;
##    у клиента это локальная предсказательная копия);
##  * отдача стволов и трассер — событие _turret_fx (от стреляющего ко всем
##    остальным, ненадёжный канал) + локальный эффект у самого стрелка.
##  * сидящую позу (опущенный торс, подвешенные ноги, руки на створах) ноды
##    строят из общего флажка mounted_idx — он едет в пакете состояния.

const MAG_SIZE := 30
const RELOAD_MS := 1600
const COOLDOWN_MS := 110
const YAW_SPEED := 10.0     # рад/с: плавность доворота купола
const KICK_DECAY := 7.0     # скорость затухания отдачи ствола

## Индекс в списке тurrets арены (0..1) — задаёт арена при создании.
var turret_idx := 0
## Peer id сидящего игрока (-1 = свободно).
var occupant_id := -1

## --- Авторитетное состояние (значимо на серверной копии) -------------------
var mag := MAG_SIZE
var barrel := 0              # 0 = левый ствол, 1 = правый (следующий выстрел)
var reload_end_ms := 0
var next_shot_ms := 0

## --- Счётчик для автотестов: сколько выстрел-событий получило ЭТА нода ------
var fx_seen := 0

var yaw_node: Node3D
var _barrels: Array[Node3D] = []
var _barrel_base: Array[Vector3] = []
var _muzzles: Array[Marker3D] = []
var _grips: Array[Marker3D] = []
var _kick := [0.0, 0.0]
var _reload_w := 0.0
var _yaw_target := 0.0
var _arena: Node = null


func _ready() -> void:
	_build_mesh()
	_arena = get_tree().current_scene


func is_occupied() -> bool:
	return occupant_id != -1


## Точка, где «сидит» игрок: его CharacterBody3D ставится сюда (ноги повиснут).
func seat_world() -> Vector3:
	return global_position + Vector3(0.0, 0.0, 0.12)


func world_muzzle(i: int) -> Vector3:
	return _muzzles[i].global_position


func world_grip(i: int) -> Vector3:
	return _grips[i].global_position


## Мировой рыск купола (корпус + доворот).
func aim_yaw() -> float:
	return wrapf(rotation.y + yaw_node.rotation.y, -PI, PI)


## Отдача ствола (вызывается всеми нодами при выстреле).
func fire_kick(i: int) -> void:
	_kick[i] = 1.0


func _process(delta: float) -> void:
	# Освобождаем сиденье, если игрок умер или вышел (нода удалена).
	if occupant_id != -1:
		var p: Node = _occupant()
		if p == null or p.dead:
			occupant_id = -1
	# Купол плавно догоняет направление взгляда сидящего.
	if occupant_id != -1:
		var p: Node = _occupant()
		if p != null:
			_yaw_target = p.rotation.y
	var d := wrapf(_yaw_target - aim_yaw(), -PI, PI)
	if absf(d) > 0.0005:
		yaw_node.rotation.y = wrapf(yaw_node.rotation.y + clampf(d, -YAW_SPEED * delta, YAW_SPEED * delta), -PI, PI)
	# Отдача: дуло откатывается назад и вверх, затем пружинит.
	for i in 2:
		_kick[i] = maxf(_kick[i] - delta * KICK_DECAY, 0.0)
		_barrels[i].position = _barrel_base[i] + Vector3(0.0, 0.0, 0.12 * _kick[i])
	# Перезарядка: стволы опускаются (состояние читается с игрока-сидящего:
	# на его авторитетной ноде — из его копии турели, на чужих — из пакета).
	var target := 0.0
	if occupant_id != -1:
		var p: Node = _occupant()
		if p != null and p.turret_reload_now:
			target = 1.0
	_reload_w = move_toward(_reload_w, target, delta * 5.0)
	for i in 2:
		_barrels[i].rotation.x = 0.16 * _kick[i] - 0.24 * _reload_w


func _occupant() -> Node:
	if _arena == null or not _arena.has_method("get_player_by_id"):
		return null
	return _arena.get_player_by_id(occupant_id)


# ---------------------------------------------------------------- геометрия

func _build_mesh() -> void:
	var mat_base := StandardMaterial3D.new()
	mat_base.albedo_color = Color(0.14, 0.15, 0.18)
	var mat_dome := StandardMaterial3D.new()
	mat_dome.albedo_color = Color(0.21, 0.23, 0.28)
	var mat_barrel := StandardMaterial3D.new()
	mat_barrel.albedo_color = Color(0.09, 0.10, 0.12)
	var mat_accent := StandardMaterial3D.new()
	mat_accent.albedo_color = Color(0.78, 0.47, 0.12)

	# Основание (статическое: пули в него попадают как в мир).
	var base := MeshInstance3D.new()
	base.name = "Base"
	var bm := CylinderMesh.new()
	bm.top_radius = 1.0
	bm.bottom_radius = 1.12
	bm.height = 0.28
	base.mesh = bm
	base.material_override = mat_base
	base.position = Vector3(0.0, 0.14, 0.0)
	add_child(base)
	var body := StaticBody3D.new()
	body.name = "Body"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var cshape := CollisionShape3D.new()
	var cs := CylinderShape3D.new()
	cs.radius = 1.0
	cs.height = 0.28
	cshape.shape = cs
	cshape.position = Vector3(0.0, 0.14, 0.0)
	body.add_child(cshape)

	# Цоколь.
	var pedestal := MeshInstance3D.new()
	pedestal.name = "Pedestal"
	var pm := CylinderMesh.new()
	pm.top_radius = 0.42
	pm.bottom_radius = 0.50
	pm.height = 0.44
	pedestal.mesh = pm
	pedestal.material_override = mat_dome
	pedestal.position = Vector3(0.0, 0.50, 0.0)
	add_child(pedestal)

	# Вращающийся купол. Стрельба вперёд = локальный -Z (как у игрока).
	yaw_node = Node3D.new()
	yaw_node.name = "Yaw"
	yaw_node.position = Vector3(0.0, 0.70, 0.0)
	add_child(yaw_node)

	var platform := MeshInstance3D.new()
	platform.name = "Platform"
	var ffm := BoxMesh.new()
	ffm.size = Vector3(1.15, 0.20, 0.72)
	platform.mesh = ffm
	platform.material_override = mat_dome
	# Сдвинуто чуть назад: таз сидит на платформе, а висящие ноги/стопы —
	# впереди её переднего края (меньше клиппинга ног по сиденью).
	platform.position = Vector3(0.0, 0.10, 0.14)
	yaw_node.add_child(platform)

	var back := MeshInstance3D.new()
	back.name = "Backrest"
	var bbm := BoxMesh.new()
	bbm.size = Vector3(1.00, 0.75, 0.18)
	back.mesh = bbm
	back.material_override = mat_base
	back.position = Vector3(0.0, 0.55, 0.42)
	yaw_node.add_child(back)

	var gunbody := MeshInstance3D.new()
	gunbody.name = "GunBody"
	var gbm := BoxMesh.new()
	gbm.size = Vector3(0.62, 0.30, 0.42)
	gunbody.mesh = gbm
	gunbody.material_override = mat_barrel
	gunbody.position = Vector3(0.0, 0.42, -0.18)
	yaw_node.add_child(gunbody)

	var stripe := MeshInstance3D.new()
	stripe.name = "Accent"
	var sm := BoxMesh.new()
	sm.size = Vector3(0.64, 0.06, 0.44)
	stripe.mesh = sm
	stripe.material_override = mat_accent
	stripe.position = Vector3(0.0, 0.42, -0.18)
	yaw_node.add_child(stripe)

	# Два ствола (левый x<0, правый x>0) с дульными маркерами и точками хвата.
	for i in 2:
		var side := "R" if i == 1 else "L"
		var b := Node3D.new()
		b.name = "Barrel" + side
		b.position = Vector3(0.17 * (1.0 if i == 1 else -1.0), 0.36, 0.02)
		yaw_node.add_child(b)
		var bm2 := MeshInstance3D.new()
		bm2.name = "Mesh"
		var box := BoxMesh.new()
		box.size = Vector3(0.10, 0.12, 1.05)
		bm2.mesh = box
		bm2.material_override = mat_barrel
		bm2.position = Vector3(0.0, 0.0, -0.42)
		b.add_child(bm2)
		var brake := MeshInstance3D.new()
		brake.name = "Brake"
		var cm := CylinderMesh.new()
		cm.top_radius = 0.075
		cm.bottom_radius = 0.075
		cm.height = 0.14
		brake.mesh = cm
		brake.material_override = mat_accent
		brake.rotation.x = PI / 2.0  # ось цилиндра вдоль ствола (Z)
		brake.position = Vector3(0.0, 0.0, -0.95)
		b.add_child(brake)
		var muzzle := Marker3D.new()
		muzzle.name = "Muzzle"
		muzzle.position = Vector3(0.0, 0.0, -1.02)
		b.add_child(muzzle)
		var grip := Marker3D.new()
		grip.name = "Grip"
		grip.position = Vector3(0.0, -0.05, 0.02)
		b.add_child(grip)
		_barrels.append(b)
		_barrel_base.append(b.position)
		_muzzles.append(muzzle)
		_grips.append(grip)
